import React from 'react';

const GuestLoginScreen: React.FC = () => {
  return (
    <div>
      <h1>Guest Login</h1>
      {/* Placeholder content */}
    </div>
  );
};

export default GuestLoginScreen;
