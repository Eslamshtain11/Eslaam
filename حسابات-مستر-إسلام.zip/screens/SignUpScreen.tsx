import React from 'react';

const SignUpScreen: React.FC = () => {
  return (
    <div>
      <h1>Sign Up</h1>
      {/* Placeholder content */}
    </div>
  );
};

export default SignUpScreen;
