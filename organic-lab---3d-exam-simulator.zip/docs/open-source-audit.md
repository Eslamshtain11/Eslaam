# Open-Source Component Audit & Architectural Attribution

### 1. PanMig/Chemistry-Lab
- **URL**: https://github.com/PanMig/Chemistry-Lab
- **License**: Apache 2.0
- **Reused Concept/Architecture**: Laboratory apparatus structure, modular first-person workbench interaction patterns, glassware container capacity, and separation stages.
- **Modifications**: Re-architected in pure Kotlin & Jetpack Compose declarative UI with custom 3D isometric physics and vector glassware engine strictly compliant with Egyptian practical chemistry examination protocol.

### 2. psy-zney/chemistryLAB
- **URL**: https://github.com/psy-zney/chemistryLAB
- **License**: MIT
- **Reused Concept/Architecture**: Deterministic reaction lookup architecture, vessel state modeling (temperature, contents, dissolved/precipitated state), chemical state transitions.
- **Modifications**: Replaced generic reactions with the exact deterministic qualitative analysis rules of "البفه الكسبانة".

### 3. 3Dmol.js & RDKit.js Principles
- **License**: BSD-3-Clause
- **Reused Concept**: Chemical 2D/3D structure representation, formula parsing, and functional group tagging for visual reference in the interactive scheme explorer.

### 4. Material 3 & Android Jetpack Components
- **License**: Apache 2.0
- **Usage**: Modern Material Design 3 tokens, Canvas 2D/3D drawing scopes, Coroutines & StateFlow state machines, custom spring physics and particle effects.
