package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.OrganicExamEngine
import com.example.engine.SchemeTreeCatalog
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ExamUiState(
    val examMode: ExamMode = ExamMode.STRICT_EXAM,
    val currentSample: ExamSample = OrganicExamEngine.generateRandomSample(allowMixture = false),
    val currentStepNode: SchemeStepNode = SchemeTreeCatalog.getNode(SchemeTreeCatalog.INITIAL_STEP_ID)!!,
    val activeEquipment: GlasswareType = GlasswareType.SPATULA,
    val currentReagents: List<ReagentType> = emptyList(),
    val isHeating: Boolean = false,
    val isShaking: Boolean = false,
    val selectedFraction: SampleFractionType = SampleFractionType.ORIGINAL,
    val separationState: Map<SampleFractionType, ChemicalCompound?> = emptyMap(),
    val performedTests: List<PerformedTestRecord> = emptyList(),
    val stepLogs: List<StudentStepLog> = emptyList(),
    val lastObservation: ObservationResult? = null,
    val isShelfDrawerOpen: Boolean = false,
    val isObservationStepDialogOpen: Boolean = false,
    val activeHint: String? = null,
    val hintLevel: Int = 0,
    val hintsUsedCount: Int = 0,
    val elapsedSeconds: Long = 0,
    val isExamFinished: Boolean = false,
    val gradingReport: ExamGradingReport? = null,
    val isTeacherDebugOpen: Boolean = false
)

class ExamViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(ExamUiState())
    val uiState: StateFlow<ExamUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null

    init {
        startSession(ExamMode.STRICT_EXAM)
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (!_uiState.value.isExamFinished) {
                    _uiState.update { it.copy(elapsedSeconds = it.elapsedSeconds + 1) }
                }
            }
        }
    }

    fun startSession(mode: ExamMode, specificSample: ExamSample? = null) {
        val sample = specificSample ?: OrganicExamEngine.generateRandomSample(allowMixture = (mode == ExamMode.STRICT_EXAM))
        val initialNode = SchemeTreeCatalog.getNode(SchemeTreeCatalog.INITIAL_STEP_ID)!!
        _uiState.value = ExamUiState(
            examMode = mode,
            currentSample = sample,
            currentStepNode = initialNode,
            activeEquipment = initialNode.suggestedEquipment,
            currentReagents = emptyList(),
            isHeating = false,
            isShaking = false,
            elapsedSeconds = 0,
            isExamFinished = false,
            gradingReport = null
        )
        startTimer()
    }

    fun setEquipment(equipment: GlasswareType) {
        _uiState.update { it.copy(activeEquipment = equipment) }
        calculateLiveObservation()
    }

    fun addReagent(reagent: ReagentType) {
        val currentList = _uiState.value.currentReagents.toMutableList()
        if (reagent !in currentList) {
            currentList.add(reagent)
            _uiState.update { it.copy(currentReagents = currentList) }
            calculateLiveObservation()
        }
    }

    fun removeReagent(reagent: ReagentType) {
        val currentList = _uiState.value.currentReagents.toMutableList()
        currentList.remove(reagent)
        _uiState.update { it.copy(currentReagents = currentList) }
        calculateLiveObservation()
    }

    fun toggleHeating() {
        val nextHeat = !_uiState.value.isHeating
        _uiState.update { it.copy(isHeating = nextHeat) }
        calculateLiveObservation()
    }

    fun shakeTube() {
        _uiState.update { it.copy(isShaking = true) }
        viewModelScope.launch {
            delay(1200)
            _uiState.update { it.copy(isShaking = false) }
            calculateLiveObservation()
        }
    }

    fun resetWorkbench() {
        _uiState.update {
            it.copy(
                currentReagents = emptyList(),
                isHeating = false,
                isShaking = false,
                lastObservation = null
            )
        }
    }

    fun toggleShelfDrawer() {
        _uiState.update { it.copy(isShelfDrawerOpen = !it.isShelfDrawerOpen) }
    }

    fun closeShelfDrawer() {
        _uiState.update { it.copy(isShelfDrawerOpen = false) }
    }

    fun openObservationStepDialog() {
        _uiState.update { it.copy(isObservationStepDialogOpen = true) }
    }

    fun closeObservationStepDialog() {
        _uiState.update { it.copy(isObservationStepDialogOpen = false) }
    }

    private fun calculateLiveObservation() {
        val state = _uiState.value
        val sample = state.currentSample
        val c1 = sample.component1

        // Dynamically compute visual changes on the bench
        val isHeated = state.isHeating
        val reagents = state.currentReagents

        val observation = when {
            // Flame on spatula with heating
            state.activeEquipment == GlasswareType.SPATULA && isHeated -> {
                when {
                    c1.isSugar || c1 == CompoundCatalog.TARTARIC_ACID || c1 == CompoundCatalog.CITRIC_ACID -> ObservationResult(
                        titleAr = "انصهار وتفحم مع انتفاخ ورائحة كراميل سكر محروق",
                        descriptionAr = "المادة تنصهر وتسود وتنتفخ مع تصاعد دخان ورائحة سكر محترق كراميل مميزة",
                        visualColorHex = 0xFF1C1917,
                        charring = true,
                        melting = true,
                        swelling = true,
                        hasFlame = true,
                        odor = OdorType.BURNT_SUGAR
                    )
                    c1.isAromatic -> ObservationResult(
                        titleAr = "اشتعال بلهب مدخن مصحوب بسناج أسود",
                        descriptionAr = "المادة تشتعل بلهب مصحوب بسناج ودخان كربوني أسود كثيف (أروماتي)",
                        visualColorHex = 0xFF292524,
                        hasFlame = true,
                        isSmokyFlame = true
                    )
                    c1.category == CompoundCategory.SODIUM_SALT || c1.category == CompoundCategory.AMMONIUM_SALT -> ObservationResult(
                        titleAr = "تطاير غازات وترك بقايا معدنية صلبة بيضاء",
                        descriptionAr = "ترك بقايا بيضاء لا تحترق، أو تصاعد غاز نشادر مميز",
                        visualColorHex = 0xFFF1F5F9,
                        hasFlame = true,
                        odor = OdorType.AMMONIA
                    )
                    else -> ObservationResult(
                        titleAr = "احتراق بلهب غير مدخن ونظيف",
                        descriptionAr = "المادة تحترق بهدوء ونظافة دون دخان أسود (أليفاتي)",
                        visualColorHex = 0xFF38BDF8,
                        hasFlame = true,
                        isSmokyFlame = false
                    )
                }
            }

            // Carbonate reaction (Acidity)
            reagents.contains(ReagentType.NA2CO3_SOL) || reagents.contains(ReagentType.NAHCO3_SOLID) -> {
                if (c1.isAcidic) {
                    ObservationResult(
                        titleAr = "فوران شديد وتصاعد فقاعات غاز CO2",
                        descriptionAr = "حدوث فوران نشط وتصاعد غاز ثاني أكسيد الكربون الذي يعكر ماء الجير الرائق",
                        visualColorHex = 0xFFE0F2FE,
                        gasBubbles = true
                    )
                } else {
                    ObservationResult(
                        titleAr = "عدم حدوث أي فوران",
                        descriptionAr = "المحلول يظل هادئاً دون تصاعد أي فقاعات غازية",
                        visualColorHex = 0xFFF8FAFC
                    )
                }
            }

            // Neutral FeCl3 reaction
            reagents.contains(ReagentType.NEUTRAL_FECL3) -> {
                when {
                    c1 == CompoundCatalog.SALICYLIC_ACID || c1 == CompoundCatalog.PHENOL -> ObservationResult(
                        titleAr = "تكون لون بنفسجي مكثف زاهي",
                        descriptionAr = "تكون معقد حديدي بنفسجي اللون يدل على مجموعة هيدروكسيل فينولية",
                        visualColorHex = 0xFF7E22CE
                    )
                    c1 == CompoundCatalog.RESORCINOL -> ObservationResult(
                        titleAr = "تكون لون أخضر داكن مزرق",
                        descriptionAr = "تكون لون أخضر داكن يثبت بإضافة خلات الصوديوم",
                        visualColorHex = 0xFF065F46
                    )
                    c1 == CompoundCatalog.BENZOIC_ACID || c1 == CompoundCatalog.PHTHALIC_ACID || c1 == CompoundCatalog.CINNAMIC_ACID -> ObservationResult(
                        titleAr = "تكون راسب برتقالي لحمي (Buff Precipitate)",
                        descriptionAr = "تكون راسب برتقالي لحمي مميز لأملاح الحديديك مع الأحماض الأروماتية",
                        visualColorHex = 0xFFD97706,
                        precipitate = PrecipitateColor.FLESHY_BUFF
                    )
                    else -> ObservationResult(
                        titleAr = "تغير طفيف للون الأصفر لكلوريد الحديديك",
                        descriptionAr = "لا يوجد تفاعل ملون مميز أو راسب",
                        visualColorHex = 0xFFFDE68A
                    )
                }
            }

            // CaCl2 test
            reagents.contains(ReagentType.CACL2_SOL) -> {
                when {
                    c1 == CompoundCatalog.OXALIC_ACID -> ObservationResult(
                        titleAr = "راسب أبيض فوري على البارد",
                        descriptionAr = "تكون راسب أبيض غير ذائب من أوكسالات الكالسيوم فورياً",
                        visualColorHex = 0xFFFFFFFF,
                        precipitate = PrecipitateColor.WHITE
                    )
                    c1 == CompoundCatalog.TARTARIC_ACID -> ObservationResult(
                        titleAr = "راسب أبيض يظهر بعد الخدش والتدفئة",
                        descriptionAr = "تكون راسب بلوري أبيض لطرطرات الكالسيوم بعد حك الأنبوبة وتدفئتها",
                        visualColorHex = 0xFFF8FAFC,
                        precipitate = PrecipitateColor.WHITE
                    )
                    c1 == CompoundCatalog.CITRIC_ACID && isHeated -> ObservationResult(
                        titleAr = "راسب أبيض بعد الغليان المستمر",
                        descriptionAr = "المحلول يتعكر ويتكون راسب أبيض لسترات الكالسيوم عند الغليان فقط",
                        visualColorHex = 0xFFFFFFFF,
                        precipitate = PrecipitateColor.WHITE
                    )
                    else -> ObservationResult(
                        titleAr = "محلول رائق لم يتكون راسب",
                        descriptionAr = "أملاح الكالسيوم ذائبة تماماً في الماء",
                        visualColorHex = 0xFFE2E8F0
                    )
                }
            }

            // Molisch Test
            reagents.contains(ReagentType.ALPHA_NAPHTHOL) && reagents.contains(ReagentType.CONC_H2SO4) -> {
                if (c1.isSugar) {
                    ObservationResult(
                        titleAr = "تكون حلقة بنفسجية على السطح الفاصل",
                        descriptionAr = "تكون حلقة بنفسجية محمرة واضحة عند السطح الفاصل بين السائلين",
                        visualColorHex = 0xFF86198F
                    )
                } else {
                    ObservationResult(
                        titleAr = "عدم تكون حلقة بنفسجية",
                        descriptionAr = "تعكر أصفر أو بني خفيف دون حلقة بنفسجية",
                        visualColorHex = 0xFF78350F
                    )
                }
            }

            // Barfoed Test
            reagents.contains(ReagentType.BARFOED_REAGENT) && isHeated -> {
                when {
                    c1 == CompoundCatalog.GLUCOSE || c1 == CompoundCatalog.FRUCTOSE -> ObservationResult(
                        titleAr = "تكون راسب أحمر طوبي سريع (2-3 دقائق)",
                        descriptionAr = "ترسب أكسيد النحاسوز الأحمر Cu2O في قاع الأنبوبة بسرعة تدل على سكر أحادي",
                        visualColorHex = 0xFFDC2626,
                        precipitate = PrecipitateColor.RED_COPPER
                    )
                    c1 == CompoundCatalog.SUCROSE -> ObservationResult(
                        titleAr = "راسب أحمر طوبي بطيء (بعد 8-10 دقائق غليان)",
                        descriptionAr = "لم يتكون راسب أحمر إلا بعد استمرار الغليان لفترة طويلة وتكسر الرابطة الجليكوسيدية",
                        visualColorHex = 0xFFEA580C,
                        precipitate = PrecipitateColor.RED_COPPER
                    )
                    else -> ObservationResult(
                        titleAr = "محلول أزرق لم يحدث اختزال",
                        descriptionAr = "المحلول يحتفظ بلونه الأزرق لكاشف بارافويد",
                        visualColorHex = 0xFF0284C7
                    )
                }
            }

            // Iodine Test
            reagents.contains(ReagentType.IODINE_SOL) -> {
                if (c1 == CompoundCatalog.STARCH) {
                    ObservationResult(
                        titleAr = "لون أزرق نيلي داكن فوري",
                        descriptionAr = "تكون لون أزرق نيلي كثيف يزول بالتسخين ويعود بالتبريد مميز للنشا",
                        visualColorHex = 0xFF1E1B4B
                    )
                } else {
                    ObservationResult(
                        titleAr = "لون اليود البني المعتاد",
                        descriptionAr = "لا يوجد تلون أزرق، لون اليود الطبيعي لم يتغير",
                        visualColorHex = 0xFFB45309
                    )
                }
            }

            // Azo Dye Test
            reagents.contains(ReagentType.DILUTE_HCL) && reagents.contains(ReagentType.NANO2_SOL) && reagents.contains(ReagentType.BETA_NAPHTHOL_NAOH) -> {
                if (c1.isAmine) {
                    ObservationResult(
                        titleAr = "تكون صبغة آزو برتقالية/حمراء زاهية تترسب فوراً",
                        descriptionAr = "تكون راسب أحمر برتقالي قرمزى مميز لازدواج الديازونيوم مع بيتا-نافثول",
                        visualColorHex = 0xFFC2410C,
                        precipitate = PrecipitateColor.ORANGE_RED_DYE
                    )
                } else {
                    ObservationResult(
                        titleAr = "لا تتكون صبغة آزو",
                        descriptionAr = "تعكر خفيف دون تكوين صبغة ملونة",
                        visualColorHex = 0xFFFEF3C7
                    )
                }
            }

            // Biuret & Urea test
            reagents.contains(ReagentType.NAOH_20) && reagents.contains(ReagentType.COPPER_SULFATE_SOL) -> {
                if (c1 == CompoundCatalog.UREA) {
                    ObservationResult(
                        titleAr = "تكون لون بنفسجي وردي مميز لاختبار البيوريت",
                        descriptionAr = "تكون معقد البيوريت الوردي البنفسجي مع أيونات النحاس في الوسط القلوي",
                        visualColorHex = 0xFFC026D3
                    )
                } else {
                    ObservationResult(
                        titleAr = "راسب أزرق شاحب لهيدروكسيد النحاس",
                        descriptionAr = "عدم تكون لون بنفسجي مميز للبيوريت",
                        visualColorHex = 0xFF38BDF8
                    )
                }
            }

            else -> null
        }

        _uiState.update { it.copy(lastObservation = observation) }
    }

    /**
     * Completes the current scheme step with the option chosen by the student.
     * Evaluates correctness, updates step history logs, and branches to next step.
     */
    fun chooseSchemeOption(option: SchemeDecisionOption) {
        val state = _uiState.value
        val currentNode = state.currentStepNode
        val sample = state.currentSample
        val c1 = sample.component1

        val isCorrect = option.isCorrectForCompound(c1)
        val errorDetails = if (isCorrect) "" else option.errorExplanationAr

        val stepLog = StudentStepLog(
            stepNode = currentNode,
            chosenOption = option,
            isCorrect = isCorrect,
            equipmentUsed = state.activeEquipment,
            reagentsUsed = state.currentReagents,
            wasHeated = state.isHeating,
            wasShaken = state.isShaking,
            actualObservation = state.lastObservation ?: ObservationResult(
                titleAr = "تم تسجيل المشاهدة",
                descriptionAr = option.descriptionAr
            ),
            errorDetailsAr = errorDetails
        )

        val updatedLogs = state.stepLogs + stepLog

        // Close dialog and reset workbench equipment for next step
        _uiState.update {
            it.copy(
                stepLogs = updatedLogs,
                isObservationStepDialogOpen = false
            )
        }

        // Branching to next step or finalizing exam report
        val nextStepId = option.nextStepId
        if (nextStepId != null) {
            val nextNode = SchemeTreeCatalog.getNode(nextStepId)
            if (nextNode != null) {
                _uiState.update {
                    it.copy(
                        currentStepNode = nextNode,
                        activeEquipment = nextNode.suggestedEquipment,
                        currentReagents = emptyList(),
                        isHeating = false,
                        isShaking = false,
                        lastObservation = null
                    )
                }
            } else {
                finalizeExam(updatedLogs, option.candidateCompounds.firstOrNull())
            }
        } else {
            // Reached terminal leaf
            val identified = option.candidateCompounds.firstOrNull() ?: c1
            finalizeExam(updatedLogs, identified)
        }
    }

    private fun finalizeExam(logs: List<StudentStepLog>, studentFinalComp: ChemicalCompound?) {
        val state = _uiState.value
        val sample = state.currentSample
        val actualComp = sample.component1

        val correctStepsCount = logs.count { it.isCorrect }
        val totalStepsCount = logs.size.coerceAtLeast(1)

        val isFinalCompMatch = studentFinalComp?.id == actualComp.id

        // Calculate score out of 10
        val stepScoreFraction = correctStepsCount.toFloat() / totalStepsCount.toFloat()
        val finalMatchBonus = if (isFinalCompMatch) 5.0f else 0.0f
        val stepsScore = stepScoreFraction * 5.0f
        val totalScore = (stepsScore + finalMatchBonus).coerceIn(0f, 10f)

        val mistakesList = mutableListOf<String>()
        val recommendationsList = mutableListOf<String>()

        logs.forEachIndexed { index, log ->
            if (!log.isCorrect) {
                mistakesList.add("الخطوة ${index + 1} (${log.stepNode.stepTitleAr}): اخترت [${log.chosenOption.textAr}] ولكن ${log.errorDetailsAr}")
            }
        }

        if (!isFinalCompMatch) {
            mistakesList.add("الاستنتاج النهائي: استنتجت أن المركب هو [${studentFinalComp?.nameAr ?: "غير محدد"}] بينما العينة المجهولة الفعلية كانت [${actualComp.nameAr} (${actualComp.formula})].")
            recommendationsList.add("راجع مسار السكيمة الخاص بـ (${actualComp.category.titleAr}) بدقة.")
        } else {
            recommendationsList.add("أحسنت! استنتاجك النهائي للمركب مطابق تماماً للسكيمة المعملية.")
        }

        val report = ExamGradingReport(
            totalScoreOutOf10 = (Math.round(totalScore * 10f) / 10f),
            component1Score = if (isFinalCompMatch) 5.0f else 0.0f,
            component2Score = 0f,
            separationScore = 0f,
            efficiencyScore = stepsScore,
            penaltyForHints = 0f,
            penaltyForInvalidTests = 0f,
            actualSample = sample,
            studentIdentifiedComp1 = studentFinalComp,
            studentIdentifiedComp2 = null,
            studentIdentifiedMixtureCategory = sample.mixtureCategory,
            performedTestsCount = logs.size,
            optimalTestsCount = 4,
            correctTestsPerformed = emptyList(),
            unnecessaryTests = emptyList(),
            missedCriticalTests = emptyList(),
            mistakesFeedbackAr = mistakesList,
            recommendationsAr = recommendationsList,
            elapsedTimeSeconds = state.elapsedSeconds,
            stepLogs = logs
        )

        _uiState.update {
            it.copy(
                isExamFinished = true,
                gradingReport = report
            )
        }
    }

    fun requestHint() {
        val currentLevel = (_uiState.value.hintLevel + 1).coerceAtMost(3)
        val currentNode = _uiState.value.currentStepNode
        val hintText = "تلميح للخطوة الحالية: ${currentNode.objectiveDescriptionAr} (المعدات المقترحة: ${currentNode.suggestedEquipment.titleAr})"
        _uiState.update {
            it.copy(
                activeHint = hintText,
                hintLevel = currentLevel,
                hintsUsedCount = it.hintsUsedCount + 1
            )
        }
    }

    fun dismissHint() {
        _uiState.update { it.copy(activeHint = null) }
    }

    fun toggleTeacherDebug() {
        _uiState.update { it.copy(isTeacherDebugOpen = !it.isTeacherDebugOpen) }
    }
}
