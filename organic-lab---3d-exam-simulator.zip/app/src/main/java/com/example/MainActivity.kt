package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.model.ExamMode
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LabExamScreen
import com.example.ui.screens.ReportScreen
import com.example.ui.screens.SchemeExplorerScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ExamViewModel

enum class AppScreen {
    HOME,
    LAB_EXAM,
    REPORT,
    SCHEME_EXPLORER
}

class MainActivity : ComponentActivity() {

    private val examViewModel: ExamViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val state by examViewModel.uiState.collectAsState()
                var currentScreen by remember { mutableStateOf(AppScreen.HOME) }

                // Automatically navigate to Report Screen when exam is finished
                LaunchedEffect(state.isExamFinished) {
                    if (state.isExamFinished && state.gradingReport != null) {
                        currentScreen = AppScreen.REPORT
                    }
                }

                AnimatedContent(
                    targetState = currentScreen,
                    label = "screen_navigation",
                    transitionSpec = {
                        fadeIn() togetherWith fadeOut()
                    }
                ) { screen ->
                    when (screen) {
                        AppScreen.HOME -> {
                            HomeScreen(
                                onStartExam = { mode ->
                                    examViewModel.startSession(mode)
                                    currentScreen = AppScreen.LAB_EXAM
                                },
                                onOpenSchemeExplorer = {
                                    currentScreen = AppScreen.SCHEME_EXPLORER
                                }
                            )
                        }

                        AppScreen.LAB_EXAM -> {
                            LabExamScreen(
                                state = state,
                                onSetEquipment = { examViewModel.setEquipment(it) },
                                onAddReagent = { examViewModel.addReagent(it) },
                                onRemoveReagent = { examViewModel.removeReagent(it) },
                                onToggleHeating = { examViewModel.toggleHeating() },
                                onShakeTube = { examViewModel.shakeTube() },
                                onResetWorkbench = { examViewModel.resetWorkbench() },
                                onToggleShelfDrawer = { examViewModel.toggleShelfDrawer() },
                                onOpenObservationDialog = { examViewModel.openObservationStepDialog() },
                                onCloseObservationDialog = { examViewModel.closeObservationStepDialog() },
                                onChooseSchemeOption = { examViewModel.chooseSchemeOption(it) },
                                onRequestHint = { examViewModel.requestHint() },
                                onDismissHint = { examViewModel.dismissHint() },
                                onToggleTeacherDebug = { examViewModel.toggleTeacherDebug() },
                                onNavigateBack = {
                                    currentScreen = AppScreen.HOME
                                }
                            )
                        }

                        AppScreen.REPORT -> {
                            state.gradingReport?.let { report ->
                                ReportScreen(
                                    report = report,
                                    onStartNewExam = {
                                        examViewModel.startSession(ExamMode.STRICT_EXAM)
                                        currentScreen = AppScreen.LAB_EXAM
                                    },
                                    onBackToHome = {
                                        currentScreen = AppScreen.HOME
                                    }
                                )
                            } ?: run {
                                currentScreen = AppScreen.HOME
                            }
                        }

                        AppScreen.SCHEME_EXPLORER -> {
                            SchemeExplorerScreen(
                                onNavigateBack = {
                                    currentScreen = AppScreen.HOME
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

