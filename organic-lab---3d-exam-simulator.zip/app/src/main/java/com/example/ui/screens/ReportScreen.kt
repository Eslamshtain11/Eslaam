package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExamGradingReport
import com.example.model.StudentStepLog
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportScreen(
    report: ExamGradingReport,
    onStartNewExam: () -> Unit,
    onBackToHome: () -> Unit
) {
    val passed = report.totalScoreOutOf10 >= 6.0f
    val minutes = report.elapsedTimeSeconds / 60
    val seconds = report.elapsedTimeSeconds % 60

    Scaffold(
        containerColor = SophisticatedBg,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "تقرير النتيجة والتصحيح المعملي 📋",
                        color = SophisticatedTextHigh,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SophisticatedBg)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
        ) {
            // 1. Score Header Card
            item {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = SophisticatedSurfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(8.dp, RoundedCornerShape(28.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    if (passed) listOf(
                                        SophisticatedSurfaceVariant,
                                        Color(0xFF283626),
                                        Color(0xFF384D35)
                                    )
                                    else listOf(
                                        SophisticatedSurfaceVariant,
                                        Color(0xFF3E2429),
                                        Color(0xFF56282E)
                                    )
                                )
                            )
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(100.dp),
                                color = if (passed) SophisticatedSageBg else SophisticatedCoralBg
                            ) {
                                Text(
                                    text = if (passed) "🎉 ممتاز! تم اجتياز الاختبار بنجاح" else "⚠️ راجع الخطوات الخاطئة والتصحيحات أدناه",
                                    color = if (passed) SophisticatedSageText else SophisticatedCoralText,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }
                            Text(
                                text = "${report.totalScoreOutOf10} / 10",
                                color = SophisticatedTextHigh,
                                fontSize = 42.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "زمن الامتحان: ${minutes} دقيقة و ${seconds} ثانية | ${report.stepLogs.size} خطوات منفذة",
                                color = SophisticatedTextMedium,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // 2. Final Compound Identification Result
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SophisticatedOutline, RoundedCornerShape(24.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🔬 استنتاج المركب النهائي:",
                                color = SophisticatedPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            val isMatch = report.studentIdentifiedComp1?.id == report.actualSample.component1.id
                            Surface(
                                shape = RoundedCornerShape(100.dp),
                                color = if (isMatch) SophisticatedSageBg else SophisticatedCoralBg
                            ) {
                                Text(
                                    text = if (isMatch) "المركب صحيح ✓" else "المركب خاطئ ✗",
                                    color = if (isMatch) SophisticatedSageText else SophisticatedCoralText,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(SophisticatedBg)
                                .border(1.dp, SophisticatedOutline, RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "العينة المجهولة الفعلية: ${report.actualSample.component1.nameAr} (${report.actualSample.component1.formula})",
                                color = SophisticatedTextHigh,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "المجموعة: ${report.actualSample.component1.category.titleAr} • ${report.actualSample.component1.physicalStateAr}",
                                color = SophisticatedTextMedium,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "استنتاجك النهائي: ${report.studentIdentifiedComp1?.nameAr ?: "غير محدد"}",
                                color = if (report.studentIdentifiedComp1?.id == report.actualSample.component1.id) SophisticatedSageBg else SophisticatedCoralBg,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // 3. Step-by-Step Diagnostic Breakdown (Every step with Correct/Wrong & Correction Reason)
            item {
                Text(
                    text = "📝 التصحيح التفصيلي لكل خطوة من خطوات المعمل:",
                    color = SophisticatedTextHigh,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            itemsIndexed(report.stepLogs) { index, log ->
                StepDiagnosticCard(stepIndex = index + 1, log = log)
            }

            // 4. Scheme Recommendations
            if (report.recommendationsAr.isNotEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SophisticatedOutline, RoundedCornerShape(24.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "💡 نصائح وتوصيات سكيمة البفه الكسبانة:",
                                color = SophisticatedSageBg,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            report.recommendationsAr.forEach { rec ->
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Text("•", color = SophisticatedSageBg, fontSize = 14.sp)
                                    Text(
                                        text = rec,
                                        color = SophisticatedTextHigh,
                                        fontSize = 12.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 5. Navigation Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onStartNewExam,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SophisticatedPrimaryContainer,
                            contentColor = SophisticatedOnPrimaryContainer
                        ),
                        shape = RoundedCornerShape(100.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("report_new_exam_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("بدء تجربة جديدة", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onBackToHome,
                        shape = RoundedCornerShape(100.dp),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = androidx.compose.ui.graphics.SolidColor(SophisticatedOutline)
                        ),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SophisticatedTextHigh),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("report_home_btn")
                    ) {
                        Text("الرئيسية", fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

@Composable
private fun StepDiagnosticCard(
    stepIndex: Int,
    log: StudentStepLog
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (log.isCorrect) SophisticatedSurface else Color(0xFF2A1C20)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (log.isCorrect) SophisticatedOutline else SophisticatedCoralBg.copy(alpha = 0.6f),
                RoundedCornerShape(20.dp)
            )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header: Step title & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (log.isCorrect) SophisticatedPrimaryContainer else SophisticatedCoralBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$stepIndex",
                            color = if (log.isCorrect) SophisticatedOnPrimaryContainer else SophisticatedCoralText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        text = log.stepNode.stepTitleAr,
                        color = SophisticatedTextHigh,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(100.dp),
                    color = if (log.isCorrect) SophisticatedSageBg else SophisticatedCoralBg
                ) {
                    Text(
                        text = if (log.isCorrect) "صحيحة ✓" else "خاطئة ✗",
                        color = if (log.isCorrect) SophisticatedSageText else SophisticatedCoralText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            // Equipment & Reagents Used
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SophisticatedBg,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "🛠️ الأدوات والكواشف المستخدمة:",
                        color = SophisticatedTextMuted,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "الأداة: ${log.equipmentUsed.titleAr} | الكواشف: ${if (log.reagentsUsed.isEmpty()) "بدون كواشف إضافية" else log.reagentsUsed.joinToString(", ") { it.nameAr }} ${if (log.wasHeated) "• (تم التسخين 🔥)" else ""}",
                        color = SophisticatedTextMedium,
                        fontSize = 11.sp
                    )
                }
            }

            // Chosen Option
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "اختيارك والمشاهدة المسجلة:",
                    color = SophisticatedTextMuted,
                    fontSize = 11.sp
                )
                Text(
                    text = log.chosenOption.textAr,
                    color = if (log.isCorrect) SophisticatedSageBg else SophisticatedCoralBg,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // If wrong: Explicit Correction & Chemical Reason
            if (!log.isCorrect) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF3B181E),
                    border = BorderStroke(1.dp, SophisticatedCoralBg),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.HelpOutline,
                                contentDescription = null,
                                tint = SophisticatedCoralBg,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "لماذا هذا الاختيار خاطئ؟ وما هو التصحيح؟",
                                color = SophisticatedCoralBg,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = log.errorDetailsAr,
                            color = SophisticatedTextHigh,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
