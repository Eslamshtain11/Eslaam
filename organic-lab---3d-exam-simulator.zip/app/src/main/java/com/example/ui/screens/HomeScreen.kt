package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExamMode
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onStartExam: (ExamMode) -> Unit,
    onOpenSchemeExplorer: () -> Unit
) {
    var showSafetyDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = SophisticatedBg,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(SophisticatedPrimaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Science,
                                contentDescription = null,
                                tint = SophisticatedPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "معمل الكيمياء العضوية 3D",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = SophisticatedTextHigh
                            )
                            Text(
                                text = "محاكي امتحان التحليل الكيفي العملي",
                                fontSize = 12.sp,
                                color = SophisticatedTextMuted
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showSafetyDialog = true },
                        modifier = Modifier
                            .testTag("safety_info_btn")
                            .clip(CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.HealthAndSafety,
                            contentDescription = "إرشادات السلامة",
                            tint = SophisticatedPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SophisticatedBg
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
        ) {
            // Sophisticated Hero Banner Card
            item {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = SophisticatedSurfaceVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(8.dp, RoundedCornerShape(28.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        SophisticatedSurfaceVariant,
                                        Color(0xFF282334),
                                        SophisticatedPrimaryContainer
                                    )
                                )
                            )
                            .padding(24.dp)
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(100.dp),
                                    color = SophisticatedPrimaryContainer
                                ) {
                                    Text(
                                        text = "وفقاً لمخطط: فريق البفه الكسبانة 🏆",
                                        color = SophisticatedOnPrimaryContainer,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(SophisticatedPrimaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = SophisticatedPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }

                            Text(
                                text = "المختبر الافتراضي التفاعلي ثلاثي الأبعاد",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = SophisticatedTextHigh,
                                lineHeight = 28.sp
                            )
                            Text(
                                text = "محاكاة فيزيائية واقعية كاملة لجميع خطوات وأفرع امتحان الكيمياء العضوية العملية: التسخين، الجير الصودي، 20% NaOH، الأحماض، الفينولات، السكريات، الأمينات، والأملاح وفصل المخاليط الستة.",
                                fontSize = 13.sp,
                                color = SophisticatedTextMedium,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
            }

            // Quick Stats Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(24.dp))
                            .background(SophisticatedSurface)
                            .border(1.dp, SophisticatedOutline, RoundedCornerShape(24.dp))
                            .padding(16.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(SophisticatedSageBg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "38",
                                        color = SophisticatedSageText,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "مركب عضوي",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = SophisticatedTextHigh
                                )
                            }
                            Text(
                                text = "شامل جميع العائلات",
                                fontSize = 11.sp,
                                color = SophisticatedSageBg
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(24.dp))
                            .background(SophisticatedSurface)
                            .border(1.dp, SophisticatedOutline, RoundedCornerShape(24.dp))
                            .padding(16.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(SophisticatedCoralBg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "24",
                                        color = SophisticatedCoralText,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "اختباراً كيميائياً",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = SophisticatedTextHigh
                                )
                            }
                            Text(
                                text = "تفاعلات دقيقة واقعية",
                                fontSize = 11.sp,
                                color = SophisticatedCoralBg
                            )
                        }
                    }
                }
            }

            // Mode 1: Strict Official Exam
            item {
                SophisticatedActionCard(
                    title = "بدء الامتحان الرسمي (Exam Mode)",
                    subtitle = "عينة مجهولة مخفية • توقيت • كشكول معملي • تقييم رسمي من 10 درجات",
                    tag = "موصى به للاختبار",
                    tagBg = SophisticatedCoralBg,
                    tagText = SophisticatedCoralText,
                    icon = Icons.Default.Quiz,
                    iconContainerBg = SophisticatedPrimaryContainer,
                    iconTint = SophisticatedPrimary,
                    testTag = "start_strict_exam_btn",
                    onClick = { onStartExam(ExamMode.STRICT_EXAM) }
                )
            }

            // Mode 2: Interactive Training Lab
            item {
                SophisticatedActionCard(
                    title = "وضع التدريب والشرح (Training Mode)",
                    subtitle = "تلميحات غير محدودة • كشف أسباب المشاهدات • تجارب حرة وتدريب على خطوات الفصل",
                    tag = "تدريب حر",
                    tagBg = SophisticatedSageBg,
                    tagText = SophisticatedSageText,
                    icon = Icons.Default.School,
                    iconContainerBg = Color(0xFF2E382D),
                    iconTint = SophisticatedSageBg,
                    testTag = "start_training_mode_btn",
                    onClick = { onStartExam(ExamMode.TRAINING) }
                )
            }

            // Mode 3: Interactive Scheme Explorer
            item {
                SophisticatedActionCard(
                    title = "موسوعة الأسكيمة التفاعلية (Scheme Explorer)",
                    subtitle = "تصفح تفاعلي كامل لجميع الـ 18 صفحة من سكيمة البفه الكسبانة مع الصيغ البنائية",
                    tag = "مرجع شامل",
                    tagBg = SophisticatedLavenderBg,
                    tagText = SophisticatedLavenderText,
                    icon = Icons.Default.AccountTree,
                    iconContainerBg = SophisticatedPrimaryContainer,
                    iconTint = SophisticatedPrimary,
                    testTag = "open_scheme_explorer_btn",
                    onClick = onOpenSchemeExplorer
                )
            }

            // Coverage Card with refined progress bar
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SophisticatedOutline, RoundedCornerShape(24.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "تغطية سكيمة الامتحان الكيفي",
                                color = SophisticatedTextHigh,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                shape = RoundedCornerShape(100.dp),
                                color = SophisticatedSageBg
                            ) {
                                Text(
                                    text = "100% مكتملة",
                                    color = SophisticatedSageText,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        LinearProgressIndicator(
                            progress = { 1.0f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = SophisticatedPrimary,
                            trackColor = SophisticatedOutline
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            StatChip(title = "مركبات", value = "38")
                            StatChip(title = "اختبارات", value = "24")
                            StatChip(title = "عائلات مخاليط", value = "6")
                            StatChip(title = "محاكاة ثلاثية", value = "3D")
                        }
                    }
                }
            }
        }
    }

    if (showSafetyDialog) {
        AlertDialog(
            onDismissRequest = { showSafetyDialog = false },
            containerColor = SophisticatedSurface,
            title = {
                Text(
                    text = "إرشادات السلامة في المعمل الافتراضي",
                    fontWeight = FontWeight.Bold,
                    color = SophisticatedTextHigh
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("1. التعامل بحرص مع الأحماض المركزة (H2SO4, HNO3) وعدم التسخين المباشر إلا في أنابيب مخصصة جافة.", color = SophisticatedTextMedium)
                    Text("2. إجراء اختبارات الرائحة بحركة تمويج خفيفة باليد دون استنشاق مباشر للأبخرة.", color = SophisticatedTextMedium)
                    Text("3. تفاعلات النيترة والآزو تتطلب تبريداً وإضافة تدريجية للأحماض والقواعد.", color = SophisticatedTextMedium)
                    Text("4. هذا المحاكي تعليمي دقيق مخصص لاجتياز الاختبارات العملية بجدارة.", color = SophisticatedTextMedium)
                }
            },
            confirmButton = {
                TextButton(onClick = { showSafetyDialog = false }) {
                    Text("فهمت ذلك", color = SophisticatedPrimary, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun SophisticatedActionCard(
    title: String,
    subtitle: String,
    tag: String,
    tagBg: Color,
    tagText: Color,
    icon: ImageVector,
    iconContainerBg: Color,
    iconTint: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(testTag)
            .border(1.dp, SophisticatedOutline, RoundedCornerShape(24.dp))
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(iconContainerBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = SophisticatedTextHigh
                    )
                }
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = SophisticatedTextMuted,
                    lineHeight = 16.sp
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = null,
                tint = SophisticatedTextMuted
            )
        }
    }
}

@Composable
private fun StatChip(title: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = SophisticatedPrimary
        )
        Text(
            text = title,
            fontSize = 11.sp,
            color = SophisticatedTextMuted
        )
    }
}
