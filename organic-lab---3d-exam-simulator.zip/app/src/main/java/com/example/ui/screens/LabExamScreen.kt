package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.lab3d.InteractiveLab3DCanvas
import com.example.ui.theme.*
import com.example.viewmodel.ExamUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LabExamScreen(
    state: ExamUiState,
    onSetEquipment: (GlasswareType) -> Unit,
    onAddReagent: (ReagentType) -> Unit,
    onRemoveReagent: (ReagentType) -> Unit,
    onToggleHeating: () -> Unit,
    onShakeTube: () -> Unit,
    onResetWorkbench: () -> Unit,
    onToggleShelfDrawer: () -> Unit,
    onOpenObservationDialog: () -> Unit,
    onCloseObservationDialog: () -> Unit,
    onChooseSchemeOption: (SchemeDecisionOption) -> Unit,
    onRequestHint: () -> Unit,
    onDismissHint: () -> Unit,
    onToggleTeacherDebug: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val minutes = state.elapsedSeconds / 60
    val seconds = state.elapsedSeconds % 60
    val timerStr = String.format("%02d:%02d", minutes, seconds)

    Scaffold(
        containerColor = SophisticatedBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "معمل الكيمياء العضوية 🧪",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = SophisticatedTextHigh
                            )
                            Surface(
                                shape = RoundedCornerShape(100.dp),
                                color = SophisticatedPrimaryContainer
                            ) {
                                Text(
                                    text = timerStr,
                                    fontSize = 12.sp,
                                    color = SophisticatedOnPrimaryContainer,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "العينة المجهولة #${state.currentSample.id.take(4)} | ${state.currentStepNode.stepTitleAr}",
                            fontSize = 11.sp,
                            color = SophisticatedTextMuted,
                            maxLines = 1
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("lab_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "رجوع",
                            tint = SophisticatedTextHigh
                        )
                    }
                },
                actions = {
                    // Teacher Debug Button
                    IconButton(
                        onClick = onToggleTeacherDebug,
                        modifier = Modifier.testTag("teacher_debug_toggle_btn")
                    ) {
                        Icon(
                            imageVector = if (state.isTeacherDebugOpen) Icons.Default.Visibility else Icons.Outlined.VisibilityOff,
                            contentDescription = "كشف هوية المجهول للمصحح",
                            tint = if (state.isTeacherDebugOpen) SophisticatedSageBg else SophisticatedTextMuted
                        )
                    }

                    // Hint Button
                    IconButton(
                        onClick = onRequestHint,
                        modifier = Modifier.testTag("request_hint_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = "تلميح للخطوة الحالية",
                            tint = if (state.hintsUsedCount > 0) SophisticatedPrimary else SophisticatedTextMedium
                        )
                    }

                    // Shelf Drawer Button
                    FilledTonalButton(
                        onClick = onToggleShelfDrawer,
                        shape = RoundedCornerShape(100.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = SophisticatedPrimaryContainer,
                            contentColor = SophisticatedOnPrimaryContainer
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("open_shelf_drawer_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Inventory2,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "دولاب الكواشف",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SophisticatedBg
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. Current Step Banner Card (Clear & Uncluttered Objective)
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SophisticatedSurfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SophisticatedOutline, RoundedCornerShape(20.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(SophisticatedPrimaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${state.stepLogs.size + 1}",
                            color = SophisticatedOnPrimaryContainer,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = state.currentStepNode.stepTitleAr,
                            color = SophisticatedPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = state.currentStepNode.objectiveDescriptionAr,
                            color = SophisticatedTextMedium,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            // 2. Realistic 3D Virtual Lab Workbench Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                InteractiveLab3DCanvas(
                    activeEquipment = state.activeEquipment,
                    currentReagents = state.currentReagents,
                    isHeating = state.isHeating,
                    onToggleHeating = onToggleHeating,
                    isShaking = state.isShaking,
                    onShake = onShakeTube,
                    lastObservation = state.lastObservation,
                    selectedFraction = state.selectedFraction,
                    onResetGlassware = onResetWorkbench
                )

                // Teacher Debug Overlay Banner
                if (state.isTeacherDebugOpen) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xEE2E382D),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(12.dp)
                            .border(1.dp, SophisticatedSageBg, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "🔒 وضع المصحح (Teacher Key):",
                                color = SophisticatedSageBg,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "العينة الفعلية: ${state.currentSample.component1.nameAr} (${state.currentSample.component1.formula})",
                                color = SophisticatedTextHigh,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "المجموعة: ${state.currentSample.component1.category.titleAr}",
                                color = SophisticatedTextMedium,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            // 3. Active Reagents & Tools on Workbench Shelf
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SophisticatedOutline, RoundedCornerShape(20.dp))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🔬 المحاليل والأدوات على بنش المعمل:",
                            color = SophisticatedTextHigh,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (state.currentReagents.isNotEmpty() || state.isHeating) {
                            TextButton(
                                onClick = onResetWorkbench,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CleaningServices,
                                    contentDescription = null,
                                    tint = SophisticatedCoralBg,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تفريغ وغسل الأنبوبة", color = SophisticatedCoralBg, fontSize = 11.sp)
                            }
                        }
                    }

                    if (state.currentReagents.isEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(SophisticatedSurfaceVariant)
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = SophisticatedPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "الأداة الحالية: [${state.activeEquipment.titleAr}]. افتح دولاب الكواشف لإضافة المحاليل المطلوبة.",
                                color = SophisticatedTextMedium,
                                fontSize = 11.sp
                            )
                        }
                    } else {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            items(state.currentReagents) { reagent ->
                                InputChip(
                                    selected = true,
                                    onClick = { onRemoveReagent(reagent) },
                                    label = { Text(reagent.nameAr, fontSize = 11.sp) },
                                    trailingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "إزالة من البنش",
                                            modifier = Modifier.size(14.dp)
                                        )
                                    },
                                    colors = InputChipDefaults.inputChipColors(
                                        selectedContainerColor = SophisticatedPrimaryContainer,
                                        selectedLabelColor = SophisticatedOnPrimaryContainer
                                    ),
                                    border = InputChipDefaults.inputChipBorder(
                                        enabled = true,
                                        selected = true,
                                        borderColor = SophisticatedPrimary
                                    )
                                )
                            }
                        }
                    }

                    // Live Observation Text if any
                    if (state.lastObservation != null) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0x33D0BCFF),
                            border = BorderStroke(1.dp, SophisticatedPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(if (state.lastObservation.visualColorHex != 0L) Color(state.lastObservation.visualColorHex) else SophisticatedPrimary)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = state.lastObservation.titleAr,
                                        color = SophisticatedTextHigh,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = state.lastObservation.descriptionAr,
                                        color = SophisticatedTextMedium,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    // Complete Step & Proceed Button
                    Button(
                        onClick = onOpenObservationDialog,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SophisticatedPrimaryContainer,
                            contentColor = SophisticatedOnPrimaryContainer
                        ),
                        shape = RoundedCornerShape(100.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("complete_step_btn")
                    ) {
                        Icon(imageVector = Icons.Default.AssignmentTurnedIn, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تم الانتهاء من التجربة وتسجيل المشاهدة 📝",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }

    // 4. Lab Shelf Side-Drawer (Comprehensive Equipment & Reagents Modal)
    if (state.isShelfDrawerOpen) {
        ModalBottomSheet(
            onDismissRequest = onToggleShelfDrawer,
            containerColor = SophisticatedSurfaceVariant,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            var selectedShelfTab by remember { mutableStateOf(0) }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "📦 دولاب الكواشف والأدوات المعملية",
                        color = SophisticatedTextHigh,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onToggleShelfDrawer) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق", tint = SophisticatedTextMuted)
                    }
                }

                TabRow(
                    selectedTabIndex = selectedShelfTab,
                    containerColor = SophisticatedSurface,
                    contentColor = SophisticatedPrimary
                ) {
                    Tab(
                        selected = selectedShelfTab == 0,
                        onClick = { selectedShelfTab = 0 },
                        text = { Text("الكواشف والمحاليل (25)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = selectedShelfTab == 1,
                        onClick = { selectedShelfTab = 1 },
                        text = { Text("المعدات والأدوات (9)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                    )
                }

                if (selectedShelfTab == 0) {
                    // Reagents List
                    LazyColumn(
                        modifier = Modifier.fillMaxHeight(0.65f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(ReagentType.values()) { reagent ->
                            val isOnBench = state.currentReagents.contains(reagent)
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isOnBench) SophisticatedPrimaryContainer.copy(alpha = 0.4f) else SophisticatedSurface
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (isOnBench) onRemoveReagent(reagent) else onAddReagent(reagent)
                                    }
                                    .border(1.dp, if (isOnBench) SophisticatedPrimary else SophisticatedOutline, RoundedCornerShape(16.dp))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(Color(reagent.colorHex)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (reagent.isSolid) "🧂" else "🧪",
                                            fontSize = 14.sp
                                        )
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = reagent.nameAr,
                                            color = SophisticatedTextHigh,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "${reagent.formula} • ${reagent.descriptionAr}",
                                            color = SophisticatedTextMuted,
                                            fontSize = 11.sp,
                                            maxLines = 1
                                        )
                                    }
                                    Button(
                                        onClick = {
                                            if (isOnBench) onRemoveReagent(reagent) else onAddReagent(reagent)
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isOnBench) SophisticatedCoralBg else SophisticatedPrimaryContainer,
                                            contentColor = if (isOnBench) SophisticatedCoralText else SophisticatedOnPrimaryContainer
                                        ),
                                        shape = RoundedCornerShape(100.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = if (isOnBench) "إزالة" else "إضافة للرف",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Equipment List
                    LazyColumn(
                        modifier = Modifier.fillMaxHeight(0.65f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(GlasswareType.values()) { eq ->
                            val isSelected = state.activeEquipment == eq
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) SophisticatedPrimaryContainer.copy(alpha = 0.4f) else SophisticatedSurface
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSetEquipment(eq) }
                                    .border(1.dp, if (isSelected) SophisticatedPrimary else SophisticatedOutline, RoundedCornerShape(16.dp))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        imageVector = when (eq) {
                                            GlasswareType.BUNSEN_BURNER -> Icons.Default.LocalFireDepartment
                                            GlasswareType.SPATULA -> Icons.Default.Handyman
                                            GlasswareType.FILTER_FUNNEL -> Icons.Default.FilterAlt
                                            else -> Icons.Default.Science
                                        },
                                        contentDescription = null,
                                        tint = if (isSelected) SophisticatedPrimary else SophisticatedTextMedium,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = eq.titleAr,
                                            color = SophisticatedTextHigh,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "${eq.titleEn} (سعة تقريبية: ${eq.capacityMl.toInt()} مل)",
                                            color = SophisticatedTextMuted,
                                            fontSize = 11.sp
                                        )
                                    }
                                    if (isSelected) {
                                        Surface(
                                            shape = RoundedCornerShape(100.dp),
                                            color = SophisticatedPrimary
                                        ) {
                                            Text(
                                                text = "نشطة على البنش ✓",
                                                color = SophisticatedOnPrimary,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    } else {
                                        OutlinedButton(
                                            onClick = { onSetEquipment(eq) },
                                            shape = RoundedCornerShape(100.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text("وضع على البنش", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 5. Scheme Decision Branching Modal Dialog
    if (state.isObservationStepDialogOpen) {
        val currentNode = state.currentStepNode

        AlertDialog(
            onDismissRequest = onCloseObservationDialog,
            containerColor = SophisticatedSurfaceVariant,
            shape = RoundedCornerShape(24.dp),
            title = {
                Column {
                    Text(
                        text = "تسجيل النتيجة والمتابعة في السكيمة 📜",
                        color = SophisticatedTextHigh,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = currentNode.questionPromptAr,
                        color = SophisticatedPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            },
            text = {
                LazyColumn(
                    modifier = Modifier.fillMaxHeight(0.6f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(currentNode.options) { option ->
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onChooseSchemeOption(option) }
                                .border(1.dp, SophisticatedOutline, RoundedCornerShape(18.dp))
                                .testTag("scheme_option_${option.optionId}")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(SophisticatedPrimaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.RadioButtonUnchecked,
                                        contentDescription = null,
                                        tint = SophisticatedOnPrimaryContainer,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = option.textAr,
                                        color = SophisticatedTextHigh,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = option.descriptionAr,
                                        color = SophisticatedTextMedium,
                                        fontSize = 11.sp,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = onCloseObservationDialog) {
                    Text("العودة للتجربة على البنش", color = SophisticatedTextMuted)
                }
            }
        )
    }

    // 6. Hint Dialog
    if (state.activeHint != null) {
        AlertDialog(
            onDismissRequest = onDismissHint,
            containerColor = SophisticatedSurfaceVariant,
            shape = RoundedCornerShape(24.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.Lightbulb, contentDescription = null, tint = SophisticatedPrimary)
                    Text("تلميح المعمل (${state.hintLevel}/3)", color = SophisticatedTextHigh, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text(text = state.activeHint, color = SophisticatedTextHigh, fontSize = 13.sp, lineHeight = 20.sp)
            },
            confirmButton = {
                Button(
                    onClick = onDismissHint,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SophisticatedPrimaryContainer,
                        contentColor = SophisticatedOnPrimaryContainer
                    ),
                    shape = RoundedCornerShape(100.dp)
                ) {
                    Text("فهمت ومتابعة", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
