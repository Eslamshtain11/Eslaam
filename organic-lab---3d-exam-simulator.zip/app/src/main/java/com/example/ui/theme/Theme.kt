package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

val SophisticatedDarkColorScheme = darkColorScheme(
    primary = SophisticatedPrimary,
    onPrimary = SophisticatedOnPrimary,
    primaryContainer = SophisticatedPrimaryContainer,
    onPrimaryContainer = SophisticatedOnPrimaryContainer,
    secondary = SophisticatedSageBg,
    onSecondary = SophisticatedSageText,
    secondaryContainer = Color(0xFF2E382D),
    onSecondaryContainer = SophisticatedSageBg,
    tertiary = SophisticatedCoralBg,
    onTertiary = SophisticatedCoralText,
    background = SophisticatedBg,
    onBackground = SophisticatedTextHigh,
    surface = SophisticatedSurface,
    onSurface = SophisticatedTextHigh,
    surfaceVariant = SophisticatedSurfaceVariant,
    onSurfaceVariant = SophisticatedTextMedium,
    outline = SophisticatedOutline,
    outlineVariant = SophisticatedOutlineVariant,
    error = SophisticatedCoralBg,
    onError = SophisticatedCoralText
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = SophisticatedDarkColorScheme,
            typography = Typography,
            content = content
        )
    }
}
