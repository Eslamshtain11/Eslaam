package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Design Theme Tokens
val SophisticatedBg = Color(0xFF1C1B1F)
val SophisticatedSurface = Color(0xFF2B2930)
val SophisticatedSurfaceVariant = Color(0xFF332D41)
val SophisticatedSurfaceHighlight = Color(0xFF36343B)

val SophisticatedPrimary = Color(0xFFD0BCFF)
val SophisticatedOnPrimary = Color(0xFF381E72)
val SophisticatedPrimaryContainer = Color(0xFF4F378B)
val SophisticatedOnPrimaryContainer = Color(0xFFEADDFF)

val SophisticatedOutline = Color(0xFF49454F)
val SophisticatedOutlineVariant = Color(0xFF49454F).copy(alpha = 0.5f)

val SophisticatedTextHigh = Color(0xFFE6E1E5)
val SophisticatedTextMedium = Color(0xFFCAC4D0)
val SophisticatedTextMuted = Color(0xFF938F99)

// Accent badges
val SophisticatedSageBg = Color(0xFFB4E3AC)
val SophisticatedSageText = Color(0xFF193718)

val SophisticatedCoralBg = Color(0xFFFFB4AB)
val SophisticatedCoralText = Color(0xFF690005)

val SophisticatedLavenderBg = Color(0xFFD0BCFF)
val SophisticatedLavenderText = Color(0xFF381E72)
