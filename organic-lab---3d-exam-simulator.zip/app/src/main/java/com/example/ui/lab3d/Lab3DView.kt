package com.example.ui.lab3d

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import kotlin.math.*
import kotlin.random.Random

enum class LabCameraMode(val titleAr: String) {
    BENCH_OVERVIEW("نظرة عامة على المعمل"),
    TUBE_CLOSEUP("أنبوبة الاختبار"),
    BURNER_HEAT("محطة التسخين"),
    FILTER_STATION("محطة الترشيح والفصل")
}

@Composable
fun InteractiveLab3DCanvas(
    modifier: Modifier = Modifier,
    activeEquipment: GlasswareType,
    currentReagents: List<ReagentType>,
    isHeating: Boolean,
    onToggleHeating: () -> Unit,
    isShaking: Boolean,
    onShake: () -> Unit,
    lastObservation: ObservationResult?,
    selectedFraction: SampleFractionType,
    onResetGlassware: () -> Unit
) {
    var cameraMode by remember { mutableStateOf(LabCameraMode.TUBE_CLOSEUP) }
    var tubeShakeOffset by remember { mutableStateOf(0f) }
    var manualTiltAngle by remember { mutableStateOf(0f) }

    // Shaking animation
    val shakeAnim = remember { Animatable(0f) }
    LaunchedEffect(isShaking) {
        if (isShaking) {
            for (i in 0..5) {
                shakeAnim.animateTo(12f, tween(50, easing = LinearEasing))
                shakeAnim.animateTo(-12f, tween(50, easing = LinearEasing))
            }
            shakeAnim.animateTo(0f, tween(80))
            onShake()
        }
    }

    // Flame & bubbling continuous infinite animation
    val infiniteTransition = rememberInfiniteTransition(label = "lab_physics")
    val flamePulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "flame"
    )
    val bubblePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 100f,
        animationSpec = infiniteRepeatable(tween(2500, easing = LinearEasing), RepeatMode.Restart),
        label = "bubbles"
    )
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF1C1B1F),
                        Color(0xFF2B2930),
                        Color(0xFF141316)
                    )
                )
            )
            .border(1.dp, Color(0xFF49454F), RoundedCornerShape(24.dp))
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        manualTiltAngle = (manualTiltAngle + dragAmount.x * 0.1f).coerceIn(-15f, 15f)
                    },
                    onDragEnd = {
                        manualTiltAngle = 0f
                    }
                )
            }
    ) {
        // Main 3D Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // 1. Draw 3D Lab Bench Table Top with Perspective
            drawLabBench(width, height)

            // 2. Draw Background Equipment & Shelf Elements
            drawBackgroundShelf(width, height)

            // 3. Draw Active Apparatus based on active equipment & camera mode
            when (activeEquipment) {
                GlasswareType.SPATULA, GlasswareType.WATCH_GLASS -> {
                    drawSpatulaHeatTest(
                        width = width,
                        height = height,
                        isHeating = isHeating,
                        flameScale = flamePulse,
                        obs = lastObservation,
                        bubblePhase = bubblePhase
                    )
                }
                GlasswareType.FILTER_FUNNEL -> {
                    drawFiltrationFunnelStation(
                        width = width,
                        height = height,
                        obs = lastObservation,
                        phase = bubblePhase
                    )
                }
                GlasswareType.BEAKER -> {
                    drawBeakerView(
                        width = width,
                        height = height,
                        reagents = currentReagents,
                        isHeating = isHeating,
                        flameScale = flamePulse,
                        obs = lastObservation,
                        glow = glowPulse,
                        bubblePhase = bubblePhase
                    )
                }
                else -> {
                    // Default 3D Test Tube & Bunsen Burner Setup
                    drawTestTubeStation(
                        width = width,
                        height = height,
                        shakeOffset = shakeAnim.value + manualTiltAngle,
                        isHeating = isHeating,
                        flameScale = flamePulse,
                        reagents = currentReagents,
                        obs = lastObservation,
                        glow = glowPulse,
                        bubblePhase = bubblePhase,
                        fraction = selectedFraction
                    )
                }
            }
        }

        // Floating Interactive Control Overlay
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Heat Toggle Button
            FilledTonalIconButton(
                onClick = onToggleHeating,
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = if (isHeating) Color(0xFFFFB4AB) else Color(0xFF332D41),
                    contentColor = if (isHeating) Color(0xFF690005) else Color(0xFFE6E1E5)
                ),
                modifier = Modifier.testTag("toggle_heat_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.LocalFireDepartment,
                    contentDescription = "تسخين بموقد بنزن"
                )
            }

            // Shake Button
            FilledTonalIconButton(
                onClick = { onShake() },
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = if (isShaking) Color(0xFFD0BCFF) else Color(0xFF332D41),
                    contentColor = if (isShaking) Color(0xFF381E72) else Color(0xFFE6E1E5)
                ),
                modifier = Modifier.testTag("shake_tube_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Vibration,
                    contentDescription = "رج الأنبوبة"
                )
            }

            // Reset Glassware Button
            FilledTonalIconButton(
                onClick = onResetGlassware,
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = Color(0xFF332D41),
                    contentColor = Color(0xFFCAC4D0)
                ),
                modifier = Modifier.testTag("reset_glassware_btn")
            ) {
                Icon(
                    imageVector = Icons.Outlined.CleaningServices,
                    contentDescription = "غسل وتفريغ الأنبوبة"
                )
            }
        }

        // Active Fraction & Condition Pill Banner
        Surface(
            color = Color(0xDD332D41),
            shape = RoundedCornerShape(100.dp),
            border = BorderStroke(1.dp, Color(0xFF49454F)),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isHeating) Color(0xFFFFB4AB) else Color(0xFFB4E3AC))
                )
                Text(
                    text = "${selectedFraction.titleAr} ${if (isHeating) "• جاري التسخين 🔥" else "• حرارة الغرفة ❄️"}",
                    color = Color(0xFFE6E1E5),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

// ----------------------------------------------------
// 3D Canvas Drawing Functions
// ----------------------------------------------------

private fun DrawScope.drawLabBench(width: Float, height: Float) {
    val benchTopY = height * 0.68f
    val benchBottomY = height

    // Bench Surface with 3D Depth
    val benchPath = Path().apply {
        moveTo(0f, benchTopY)
        lineTo(width, benchTopY)
        lineTo(width, benchBottomY)
        lineTo(0f, benchBottomY)
        close()
    }
    drawPath(
        path = benchPath,
        brush = Brush.verticalGradient(
            colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A)),
            startY = benchTopY,
            endY = benchBottomY
        )
    )

    // Bench highlight bevel line
    drawLine(
        color = Color(0xFF38BDF8).copy(alpha = 0.3f),
        start = Offset(0f, benchTopY),
        end = Offset(width, benchTopY),
        strokeWidth = 2.5f
    )

    // Grid lines for lab tile effect
    for (i in 1..4) {
        val x = width * (i / 5f)
        drawLine(
            color = Color(0xFF334155).copy(alpha = 0.25f),
            start = Offset(x, benchTopY),
            end = Offset(x - 30f, benchBottomY),
            strokeWidth = 1f
        )
    }
}

private fun DrawScope.drawBackgroundShelf(width: Float, height: Float) {
    val shelfY = height * 0.22f
    // Wooden/Steel Rack Shelf
    drawRoundRect(
        color = Color(0xFF1E293B).copy(alpha = 0.7f),
        topLeft = Offset(width * 0.05f, shelfY),
        size = Size(width * 0.9f, 10.dp.toPx()),
        cornerRadius = CornerRadius(4f, 4f)
    )
    // Small background decorative bottles
    for (i in 0..4) {
        val bx = width * 0.12f + i * (width * 0.18f)
        drawRoundRect(
            color = Color(0x3338BDF8),
            topLeft = Offset(bx, shelfY - 26.dp.toPx()),
            size = Size(16.dp.toPx(), 26.dp.toPx()),
            cornerRadius = CornerRadius(3f, 3f)
        )
        drawCircle(
            color = Color(0x44FFFFFF),
            center = Offset(bx + 8.dp.toPx(), shelfY - 28.dp.toPx()),
            radius = 4.dp.toPx()
        )
    }
}

private fun DrawScope.drawTestTubeStation(
    width: Float,
    height: Float,
    shakeOffset: Float,
    isHeating: Boolean,
    flameScale: Float,
    reagents: List<ReagentType>,
    obs: ObservationResult?,
    glow: Float,
    bubblePhase: Float,
    fraction: SampleFractionType
) {
    val centerX = width * 0.5f + shakeOffset
    val tubeTopY = height * 0.20f
    val tubeWidth = 52.dp.toPx()
    val tubeHeight = 170.dp.toPx()
    val tubeBottomY = tubeTopY + tubeHeight

    // 1. Draw Bunsen Burner underneath if heating or standard
    val burnerX = centerX
    val burnerY = height * 0.76f
    drawBunsenBurner(burnerX, burnerY, isHeating, flameScale)

    // 2. Tube Glass Drop Shadow
    drawOval(
        color = Color.Black.copy(alpha = 0.4f),
        topLeft = Offset(centerX - tubeWidth * 0.6f, height * 0.69f),
        size = Size(tubeWidth * 1.2f, 12.dp.toPx())
    )

    // 3. Liquid inside Tube
    val hasLiquid = reagents.isNotEmpty() || obs != null
    if (hasLiquid) {
        val liquidHeight = (tubeHeight * 0.55f).coerceAtMost(tubeHeight - 20f)
        val liquidTopY = tubeBottomY - liquidHeight

        // Liquid Color calculation
        val primaryColorHex = obs?.visualColorHex?.takeIf { it != 0L }
            ?: reagents.lastOrNull()?.colorHex
            ?: 0xFFE0F2FE

        val liquidColor = Color(primaryColorHex)

        val liquidPath = Path().apply {
            moveTo(centerX - tubeWidth * 0.44f, liquidTopY)
            lineTo(centerX + tubeWidth * 0.44f, liquidTopY)
            lineTo(centerX + tubeWidth * 0.44f, tubeBottomY - tubeWidth * 0.44f)
            arcTo(
                rect = androidx.compose.ui.geometry.Rect(
                    centerX - tubeWidth * 0.44f,
                    tubeBottomY - tubeWidth * 0.88f,
                    centerX + tubeWidth * 0.44f,
                    tubeBottomY
                ),
                startAngleDegrees = 0f,
                sweepAngleDegrees = 180f,
                forceMoveTo = false
            )
            close()
        }

        // Fill liquid
        drawPath(
            path = liquidPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    liquidColor.copy(alpha = 0.65f),
                    liquidColor.copy(alpha = 0.92f)
                ),
                startY = liquidTopY,
                endY = tubeBottomY
            )
        )

        // Meniscus on top of liquid
        drawOval(
            color = liquidColor.copy(alpha = 0.9f),
            topLeft = Offset(centerX - tubeWidth * 0.44f, liquidTopY - 4.dp.toPx()),
            size = Size(tubeWidth * 0.88f, 8.dp.toPx())
        )

        // Fluorescein Glow Effect
        if (obs?.fluoresceinGlow == true) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF10B981).copy(alpha = 0.8f * glow),
                        Color(0xFF10B981).copy(alpha = 0.3f * glow),
                        Color.Transparent
                    ),
                    center = Offset(centerX, liquidTopY + liquidHeight * 0.5f),
                    radius = tubeWidth * 1.5f
                ),
                center = Offset(centerX, liquidTopY + liquidHeight * 0.5f),
                radius = tubeWidth * 1.5f
            )
        }

        // Molisch Purple Ring Effect
        if (obs?.purpleRing == true) {
            val ringY = liquidTopY + liquidHeight * 0.45f
            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(
                        Color.Transparent,
                        Color(0xFF7C3AED),
                        Color(0xFF9333EA),
                        Color.Transparent
                    )
                ),
                topLeft = Offset(centerX - tubeWidth * 0.44f, ringY - 8.dp.toPx()),
                size = Size(tubeWidth * 0.88f, 16.dp.toPx()),
                cornerRadius = CornerRadius(4f, 4f)
            )
        }

        // Precipitate Crystals settling at bottom
        if (obs?.precipitate != null && obs.precipitate != PrecipitateColor.NONE) {
            val pColor = Color(obs.precipitate.colorHex)
            drawOval(
                color = pColor.copy(alpha = 0.95f),
                topLeft = Offset(centerX - tubeWidth * 0.38f, tubeBottomY - 14.dp.toPx()),
                size = Size(tubeWidth * 0.76f, 12.dp.toPx())
            )
            // Particle specks
            for (p in 0..12) {
                val px = centerX + (sin(p * 2.3f) * tubeWidth * 0.3f)
                val py = tubeBottomY - 6.dp.toPx() - (cos(p * 1.7f).absoluteValue * 18.dp.toPx())
                drawCircle(
                    color = pColor,
                    radius = 2.dp.toPx(),
                    center = Offset(px, py)
                )
            }
        }

        // Bubbles rising if effervescence/boiling/heating
        if (obs?.gasBubbles == true || isHeating) {
            for (b in 0..8) {
                val bProgress = ((bubblePhase + b * 15) % 100) / 100f
                val bx = centerX + (sin(b * 1.4f + bProgress * 6f) * tubeWidth * 0.28f)
                val by = tubeBottomY - (bProgress * liquidHeight)
                if (by >= liquidTopY) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.7f * (1f - bProgress)),
                        radius = (2f + (b % 3) * 1.5f).dp.toPx(),
                        center = Offset(bx, by)
                    )
                }
            }
        }
    }

    // 4. Glass Tube Outline & Highlights
    val tubeOuterPath = Path().apply {
        moveTo(centerX - tubeWidth * 0.5f, tubeTopY)
        lineTo(centerX - tubeWidth * 0.5f, tubeBottomY - tubeWidth * 0.5f)
        arcTo(
            rect = androidx.compose.ui.geometry.Rect(
                centerX - tubeWidth * 0.5f,
                tubeBottomY - tubeWidth,
                centerX + tubeWidth * 0.5f,
                tubeBottomY
            ),
            startAngleDegrees = 180f,
            sweepAngleDegrees = -180f,
            forceMoveTo = false
        )
        lineTo(centerX + tubeWidth * 0.5f, tubeTopY)
    }

    // Glass stroke
    drawPath(
        path = tubeOuterPath,
        color = Color(0xFF94A3B8).copy(alpha = 0.6f),
        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // Glass Rim on Top
    drawOval(
        color = Color(0xFFCBD5E1).copy(alpha = 0.8f),
        topLeft = Offset(centerX - tubeWidth * 0.55f, tubeTopY - 5.dp.toPx()),
        size = Size(tubeWidth * 1.1f, 10.dp.toPx()),
        style = Stroke(width = 2.5.dp.toPx())
    )

    // Glass Reflection streak on left
    drawLine(
        color = Color.White.copy(alpha = 0.45f),
        start = Offset(centerX - tubeWidth * 0.38f, tubeTopY + 15.dp.toPx()),
        end = Offset(centerX - tubeWidth * 0.38f, tubeBottomY - 20.dp.toPx()),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round
    )

    // 5. Smoke & Steam Plume on top
    if (isHeating || obs?.charring == true || obs?.isSmokyFlame == true) {
        val smokeColor = if (obs?.isSmokyFlame == true) Color(0x991E293B) else Color(0x66E2E8F0)
        for (s in 0..6) {
            val sProg = ((bubblePhase * 1.5f + s * 18) % 100) / 100f
            val sx = centerX + sin(s * 2.1f + sProg * 5f) * (20.dp.toPx() * sProg)
            val sy = tubeTopY - (sProg * 80.dp.toPx())
            drawCircle(
                color = smokeColor.copy(alpha = (1f - sProg) * 0.6f),
                radius = (6f + sProg * 14f).dp.toPx(),
                center = Offset(sx, sy)
            )
        }
    }
}

private fun DrawScope.drawBunsenBurner(
    x: Float,
    baseY: Float,
    isHeating: Boolean,
    flameScale: Float
) {
    val burnerWidth = 44.dp.toPx()
    val burnerHeight = 55.dp.toPx()
    val topY = baseY - burnerHeight

    // Burner Metallic Barrel
    drawRoundRect(
        brush = Brush.horizontalGradient(
            listOf(Color(0xFF475569), Color(0xFF94A3B8), Color(0xFF334155))
        ),
        topLeft = Offset(x - burnerWidth * 0.22f, topY),
        size = Size(burnerWidth * 0.44f, burnerHeight),
        cornerRadius = CornerRadius(2f, 2f)
    )

    // Burner Heavy Base
    drawOval(
        color = Color(0xFF1E293B),
        topLeft = Offset(x - burnerWidth * 0.6f, baseY - 6.dp.toPx()),
        size = Size(burnerWidth * 1.2f, 14.dp.toPx())
    )

    // Animated Flame
    if (isHeating) {
        val flameH = 48.dp.toPx() * flameScale
        val flameW = 20.dp.toPx() * flameScale

        // Outer Orange Flame
        val outerFlamePath = Path().apply {
            moveTo(x - flameW * 0.5f, topY)
            quadraticTo(x - flameW * 0.8f, topY - flameH * 0.5f, x, topY - flameH)
            quadraticTo(x + flameW * 0.8f, topY - flameH * 0.5f, x + flameW * 0.5f, topY)
            close()
        }
        drawPath(
            path = outerFlamePath,
            brush = Brush.verticalGradient(
                listOf(Color(0xFFEF4444), Color(0xFFF59E0B), Color(0xFF38BDF8))
            )
        )

        // Inner Blue Cone
        val innerConePath = Path().apply {
            moveTo(x - flameW * 0.25f, topY)
            quadraticTo(x - flameW * 0.4f, topY - flameH * 0.35f, x, topY - flameH * 0.6f)
            quadraticTo(x + flameW * 0.4f, topY - flameH * 0.35f, x + flameW * 0.25f, topY)
            close()
        }
        drawPath(
            path = innerConePath,
            color = Color(0xFF38BDF8).copy(alpha = 0.9f)
        )
    }
}

private fun DrawScope.drawSpatulaHeatTest(
    width: Float,
    height: Float,
    isHeating: Boolean,
    flameScale: Float,
    obs: ObservationResult?,
    bubblePhase: Float
) {
    val centerX = width * 0.5f
    val centerY = height * 0.45f

    // 1. Bunsen Burner below spatula
    drawBunsenBurner(centerX, height * 0.74f, isHeating, flameScale)

    // 2. Metal Spatula / Watch Glass Blade
    val spatulaW = 120.dp.toPx()
    val spatulaH = 16.dp.toPx()
    drawRoundRect(
        brush = Brush.horizontalGradient(
            listOf(Color(0xFF64748B), Color(0xFFCBD5E1), Color(0xFF475569))
        ),
        topLeft = Offset(centerX - spatulaW * 0.5f, centerY),
        size = Size(spatulaW, spatulaH),
        cornerRadius = CornerRadius(6f, 6f)
    )

    // 3. Chemical Sample on Spatula
    val solidColor = when {
        obs?.charring == true -> Color(0xFF0F172A)
        obs?.melting == true -> Color(0xFF78350F)
        else -> Color.White
    }

    val sampleRadius = if (obs?.swelling == true) 22.dp.toPx() else 14.dp.toPx()
    drawOval(
        color = solidColor,
        topLeft = Offset(centerX - sampleRadius, centerY - sampleRadius * 0.6f),
        size = Size(sampleRadius * 2f, sampleRadius * 1.2f)
    )

    // 4. Burning Flame on Spatula if hasFlame
    if (obs?.hasFlame == true || isHeating) {
        val flameH = (if (obs?.isSmokyFlame == true) 55f else 35f).dp.toPx() * flameScale
        val flameW = 28.dp.toPx()

        val sampleFlamePath = Path().apply {
            moveTo(centerX - flameW * 0.5f, centerY)
            quadraticTo(centerX - flameW, centerY - flameH * 0.5f, centerX, centerY - flameH)
            quadraticTo(centerX + flameW, centerY - flameH * 0.5f, centerX + flameW * 0.5f, centerY)
            close()
        }
        drawPath(
            path = sampleFlamePath,
            brush = Brush.verticalGradient(
                listOf(
                    if (obs?.isSmokyFlame == true) Color(0xFFEA580C) else Color(0xFF38BDF8),
                    Color(0xFFF59E0B)
                )
            )
        )

        // Smoke / Soot Plume
        val sootColor = if (obs?.isSmokyFlame == true) Color(0xCC0F172A) else Color(0x44E2E8F0)
        for (i in 0..7) {
            val prog = ((bubblePhase * 2f + i * 14) % 100) / 100f
            val sx = centerX + sin(i * 2.2f + prog * 4f) * (25.dp.toPx() * prog)
            val sy = (centerY - flameH) - (prog * 90.dp.toPx())
            drawCircle(
                color = sootColor.copy(alpha = (1f - prog) * 0.8f),
                radius = (8f + prog * 18f).dp.toPx(),
                center = Offset(sx, sy)
            )
        }
    }
}

private fun DrawScope.drawFiltrationFunnelStation(
    width: Float,
    height: Float,
    obs: ObservationResult?,
    phase: Float
) {
    val centerX = width * 0.5f
    val funnelTopY = height * 0.22f
    val funnelW = 100.dp.toPx()
    val funnelH = 75.dp.toPx()
    val stemH = 50.dp.toPx()

    // 1. Receiving Beaker below
    val beakerTopY = funnelTopY + funnelH + stemH - 10.dp.toPx()
    val beakerW = 85.dp.toPx()
    val beakerH = 90.dp.toPx()

    // Liquid in receiving beaker (Filtrate)
    drawRoundRect(
        color = Color(0xFF38BDF8).copy(alpha = 0.5f),
        topLeft = Offset(centerX - beakerW * 0.44f, beakerTopY + beakerH * 0.55f),
        size = Size(beakerW * 0.88f, beakerH * 0.4f),
        cornerRadius = CornerRadius(6f, 6f)
    )

    // Beaker Outline
    drawRoundRect(
        color = Color(0xFF94A3B8).copy(alpha = 0.7f),
        topLeft = Offset(centerX - beakerW * 0.5f, beakerTopY),
        size = Size(beakerW, beakerH),
        cornerRadius = CornerRadius(6f, 6f),
        style = Stroke(width = 2.5.dp.toPx())
    )

    // 2. Funnel Glass Cone & Stem
    val funnelPath = Path().apply {
        moveTo(centerX - funnelW * 0.5f, funnelTopY)
        lineTo(centerX + funnelW * 0.5f, funnelTopY)
        lineTo(centerX + 6.dp.toPx(), funnelTopY + funnelH)
        lineTo(centerX + 6.dp.toPx(), funnelTopY + funnelH + stemH)
        lineTo(centerX - 6.dp.toPx(), funnelTopY + funnelH + stemH)
        lineTo(centerX - 6.dp.toPx(), funnelTopY + funnelH)
        close()
    }
    drawPath(
        path = funnelPath,
        color = Color(0xFFE2E8F0).copy(alpha = 0.3f)
    )
    drawPath(
        path = funnelPath,
        color = Color(0xFF94A3B8).copy(alpha = 0.8f),
        style = Stroke(width = 2.5.dp.toPx())
    )

    // 3. Filter Paper inside Funnel (Conical cone with solid residue)
    val paperPath = Path().apply {
        moveTo(centerX - funnelW * 0.42f, funnelTopY + 8.dp.toPx())
        lineTo(centerX + funnelW * 0.42f, funnelTopY + 8.dp.toPx())
        lineTo(centerX, funnelTopY + funnelH - 4.dp.toPx())
        close()
    }
    drawPath(
        path = paperPath,
        color = Color.White.copy(alpha = 0.85f)
    )

    // Solid Residue on filter paper
    drawOval(
        color = Color(0xFFFDE047).copy(alpha = 0.95f),
        topLeft = Offset(centerX - 16.dp.toPx(), funnelTopY + 22.dp.toPx()),
        size = Size(32.dp.toPx(), 18.dp.toPx())
    )

    // 4. Dripping droplets into receiving beaker
    val dropProgress = (phase % 100) / 100f
    val dropY = (funnelTopY + funnelH + stemH) + (dropProgress * 45.dp.toPx())
    if (dropY < beakerTopY + beakerH * 0.6f) {
        drawCircle(
            color = Color(0xFF38BDF8),
            radius = 3.dp.toPx(),
            center = Offset(centerX, dropY)
        )
    }
}

private fun DrawScope.drawBeakerView(
    width: Float,
    height: Float,
    reagents: List<ReagentType>,
    isHeating: Boolean,
    flameScale: Float,
    obs: ObservationResult?,
    glow: Float,
    bubblePhase: Float
) {
    val centerX = width * 0.5f
    val beakerTopY = height * 0.30f
    val beakerW = 120.dp.toPx()
    val beakerH = 135.dp.toPx()
    val beakerBottomY = beakerTopY + beakerH

    if (isHeating) {
        drawBunsenBurner(centerX, height * 0.76f, true, flameScale)
    }

    val liquidH = beakerH * 0.55f
    val liquidY = beakerBottomY - liquidH
    val pColor = obs?.visualColorHex?.takeIf { it != 0L }
        ?: reagents.lastOrNull()?.colorHex
        ?: 0xFFE0F2FE
    val color = Color(pColor)

    // Beaker Liquid
    drawRoundRect(
        brush = Brush.verticalGradient(
            listOf(color.copy(alpha = 0.6f), color.copy(alpha = 0.92f)),
            startY = liquidY,
            endY = beakerBottomY
        ),
        topLeft = Offset(centerX - beakerW * 0.46f, liquidY),
        size = Size(beakerW * 0.92f, liquidH),
        cornerRadius = CornerRadius(8f, 8f)
    )

    // Fluorescein Glow in Beaker
    if (obs?.fluoresceinGlow == true) {
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFF10B981).copy(alpha = 0.85f * glow), Color.Transparent),
                center = Offset(centerX, liquidY + liquidH * 0.5f),
                radius = beakerW
            ),
            center = Offset(centerX, liquidY + liquidH * 0.5f),
            radius = beakerW
        )
    }

    // Beaker Outline
    drawRoundRect(
        color = Color(0xFF94A3B8).copy(alpha = 0.7f),
        topLeft = Offset(centerX - beakerW * 0.5f, beakerTopY),
        size = Size(beakerW, beakerH),
        cornerRadius = CornerRadius(8f, 8f),
        style = Stroke(width = 3.dp.toPx())
    )

    // Spout tick
    drawLine(
        color = Color(0xFF94A3B8),
        start = Offset(centerX - beakerW * 0.5f, beakerTopY),
        end = Offset(centerX - beakerW * 0.56f, beakerTopY - 6.dp.toPx()),
        strokeWidth = 3.dp.toPx()
    )
}
