package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChemicalCompound
import com.example.model.CompoundCatalog
import com.example.model.CompoundCategory
import com.example.model.MixtureCategory
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SchemeExplorerScreen(
    onNavigateBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf<CompoundCategory?>(null) }
    var selectedCompoundDetail by remember { mutableStateOf<ChemicalCompound?>(null) }
    var showMixtureFamiliesTab by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = SophisticatedBg,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "موسوعة سكيمة البفه الكسبانة 📜",
                        color = SophisticatedTextHigh,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("scheme_explorer_back_btn")
                    ) {
                        Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "رجوع", tint = SophisticatedTextHigh)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SophisticatedBg)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Search TextField
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("scheme_search_input"),
                placeholder = { Text("ابحث عن مركب، صيغة، كاشف، أو مشاهدة...", color = SophisticatedTextMuted, fontSize = 13.sp) },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = SophisticatedPrimary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "مسح", tint = SophisticatedTextMuted)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SophisticatedPrimary,
                    unfocusedBorderColor = SophisticatedOutline,
                    focusedContainerColor = SophisticatedSurface,
                    unfocusedContainerColor = SophisticatedSurface,
                    focusedTextColor = SophisticatedTextHigh,
                    unfocusedTextColor = SophisticatedTextHigh
                )
            )

            // Category Filter Chips
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedCategoryFilter == null && !showMixtureFamiliesTab,
                        onClick = {
                            selectedCategoryFilter = null
                            showMixtureFamiliesTab = false
                        },
                        shape = RoundedCornerShape(100.dp),
                        label = { Text("الكل (38)", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SophisticatedPrimaryContainer,
                            selectedLabelColor = SophisticatedOnPrimaryContainer,
                            containerColor = SophisticatedSurface,
                            labelColor = SophisticatedTextMedium
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedCategoryFilter == null && !showMixtureFamiliesTab,
                            borderColor = SophisticatedOutline,
                            selectedBorderColor = SophisticatedPrimary
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = showMixtureFamiliesTab,
                        onClick = {
                            showMixtureFamiliesTab = true
                            selectedCategoryFilter = null
                        },
                        shape = RoundedCornerShape(100.dp),
                        label = { Text("عائلات المخاليط (6)", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SophisticatedPrimaryContainer,
                            selectedLabelColor = SophisticatedOnPrimaryContainer,
                            containerColor = SophisticatedSurface,
                            labelColor = SophisticatedTextMedium
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = showMixtureFamiliesTab,
                            borderColor = SophisticatedOutline,
                            selectedBorderColor = SophisticatedPrimary
                        )
                    )
                }
                items(CompoundCategory.values()) { cat ->
                    FilterChip(
                        selected = selectedCategoryFilter == cat && !showMixtureFamiliesTab,
                        onClick = {
                            selectedCategoryFilter = cat
                            showMixtureFamiliesTab = false
                        },
                        shape = RoundedCornerShape(100.dp),
                        label = { Text(cat.titleAr, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SophisticatedPrimaryContainer,
                            selectedLabelColor = SophisticatedOnPrimaryContainer,
                            containerColor = SophisticatedSurface,
                            labelColor = SophisticatedTextMedium
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedCategoryFilter == cat && !showMixtureFamiliesTab,
                            borderColor = SophisticatedOutline,
                            selectedBorderColor = SophisticatedPrimary
                        )
                    )
                }
            }

            // Content List
            if (showMixtureFamiliesTab) {
                // Show the 6 standard mixture separation protocols
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(MixtureCategory.values().filter { it != MixtureCategory.SINGLE }) { mix ->
                        Card(
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, SophisticatedOutline, RoundedCornerShape(24.dp))
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = mix.titleAr,
                                        color = SophisticatedPrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(100.dp),
                                        color = SophisticatedPrimaryContainer
                                    ) {
                                        Text(
                                            text = mix.code,
                                            color = SophisticatedOnPrimaryContainer,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "🔬 بروتوكول الفصل والترشيح العملي:",
                                    color = SophisticatedTextMedium,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = mix.separationProtocolAr,
                                    color = SophisticatedTextHigh,
                                    fontSize = 13.sp,
                                    lineHeight = 19.sp
                                )
                            }
                        }
                    }
                }
            } else {
                // Filtered Compounds List
                val filtered = CompoundCatalog.allCompounds.filter { c ->
                    (selectedCategoryFilter == null || c.category == selectedCategoryFilter) &&
                            (searchQuery.isEmpty() ||
                                    c.nameAr.contains(searchQuery, ignoreCase = true) ||
                                    c.nameEn.contains(searchQuery, ignoreCase = true) ||
                                    c.formula.contains(searchQuery, ignoreCase = true) ||
                                    c.identificationPathAr.contains(searchQuery, ignoreCase = true))
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filtered) { compound ->
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedCompoundDetail = compound }
                                .border(1.dp, SophisticatedOutline, RoundedCornerShape(20.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(SophisticatedPrimaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = compound.formula.take(3),
                                        color = SophisticatedPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = compound.nameAr,
                                        color = SophisticatedTextHigh,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${compound.nameEn} • ${compound.formula}",
                                        color = SophisticatedTextMuted,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = "المسار: ${compound.identificationPathAr}",
                                        color = SophisticatedPrimary,
                                        fontSize = 11.sp,
                                        maxLines = 1
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ChevronLeft,
                                    contentDescription = null,
                                    tint = SophisticatedTextMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Compound Details Modal BottomSheet
    if (selectedCompoundDetail != null) {
        val c = selectedCompoundDetail!!
        ModalBottomSheet(
            onDismissRequest = { selectedCompoundDetail = null },
            containerColor = SophisticatedSurfaceVariant
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = c.nameAr,
                            color = SophisticatedTextHigh,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${c.nameEn} (${c.formula})",
                            color = SophisticatedPrimary,
                            fontSize = 13.sp
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(100.dp),
                        color = SophisticatedPrimaryContainer
                    ) {
                        Text(
                            text = c.category.titleAr,
                            color = SophisticatedOnPrimaryContainer,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                // Properties Card
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                    modifier = Modifier.border(1.dp, SophisticatedOutline, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "• الحالة الفيزيائية: ${c.physicalStateAr}", color = SophisticatedTextMedium, fontSize = 13.sp)
                        Text(text = "• الوزن الجزيئي التقريبي: ${c.molarMass} g/mol", color = SophisticatedTextMedium, fontSize = 13.sp)
                        Text(text = "• الرائحة المميزة: ${c.typicalOdor.titleAr}", color = SophisticatedTextMedium, fontSize = 13.sp)
                        Text(text = "• المسار السريع للكشف: ${c.identificationPathAr}", color = SophisticatedPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Button(
                    onClick = { selectedCompoundDetail = null },
                    colors = ButtonDefaults.buttonColors(containerColor = SophisticatedPrimaryContainer),
                    shape = RoundedCornerShape(100.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إغلاق", color = SophisticatedOnPrimaryContainer, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
