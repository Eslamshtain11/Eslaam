package com.example.engine

import com.example.model.*

object SchemeTreeCatalog {

    val INITIAL_STEP_ID = "STEP_FLAME_IGNITION"

    /**
     * Finds a scheme step node by its unique ID.
     */
    fun getNode(stepId: String): SchemeStepNode? {
        return allNodes[stepId]
    }

    private val allNodes: Map<String, SchemeStepNode> = listOf(
        // =========================================================================
        // 1. INITIAL FLAME & DRY HEAT TEST
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_FLAME_IGNITION",
            stepTitleAr = "الخطوة 1: اختبار اللهب والتسخين الجاف على الملعقة",
            stepTitleEn = "Step 1: Flame & Ignition Test",
            objectiveDescriptionAr = "ضع كمية صغيرة من المادة المجهولة على ملعقة سباتيولا أو زجاجة ساعة وقربها من موقد بنزن لملاحظة سلوك الاحتراق والدخان.",
            suggestedEquipment = GlasswareType.SPATULA,
            suggestedReagents = emptyList(),
            requiresHeating = true,
            questionPromptAr = "ما هي المشاهدة التي لاحظتها على لهب الاحتراق؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "FLAME_AROMATIC",
                    textAr = "احتراق بلهب مدخن وسناج أسود كثيف (أروماتي)",
                    descriptionAr = "المادة تشتعل بلهب مصحوب بسناج أسود ودخان كربوني كثيف يدل على نسبة كربون عالية (حلقة بنزين أروماتية).",
                    isCorrectForCompound = { it.isAromatic },
                    nextStepId = "STEP_ACIDITY_TEST_AROMATIC",
                    errorExplanationAr = "المركب الفعلي أليفاتي ولا يحتوي على حلقة أروماتية، لذا يحترق بلهب أزرق خافت ونظيف دون سناج أسود."
                ),
                SchemeDecisionOption(
                    optionId = "FLAME_ALIPHATIC",
                    textAr = "احتراق بلهب غير مدخن ونظيف وهادئ (أليفاتي)",
                    descriptionAr = "المادة تحترق بهدوء ونظافة دون سناج كربوني أسود يدل على مركب أليفاتي مفتوح السلسلة.",
                    isCorrectForCompound = { !it.isAromatic && !it.isSugar && it.category != CompoundCategory.SODIUM_SALT },
                    nextStepId = "STEP_ACIDITY_TEST_ALIPHATIC",
                    errorExplanationAr = "المركب الفعلي أروماتي أو يحتوي على سكريات/أملاح، وكان يجب أن يعطي لهباً مدخناً أو تفحماً ورائحة كراميل."
                ),
                SchemeDecisionOption(
                    optionId = "FLAME_SUGAR_CHARRING",
                    textAr = "انصهار وتفحم سريع مع انتفاخ ورائحة سكر محترق كراميل (سكريات)",
                    descriptionAr = "المادة تنصهر وتسود وتنتفخ مع تصاعد أبخرة ورائحة كراميل وسكر محروق مميزة تدل على كربوهيدرات أو أحماض هيدروكسيلية.",
                    isCorrectForCompound = { it.isSugar || it == CompoundCatalog.TARTARIC_ACID || it == CompoundCatalog.CITRIC_ACID },
                    nextStepId = "STEP_SUGARS_MOLISCH",
                    errorExplanationAr = "المركب الفعلي ليس من السكريات ولا يعطي تفحماً وانتفاخاً برائحة الكراميل."
                ),
                SchemeDecisionOption(
                    optionId = "FLAME_SPECIAL_SALTS",
                    textAr = "انصهار وتطاير غازات نفاذة (نشادر) أو ترك بقايا معدنية بيضاء (أملاح / يوريا)",
                    descriptionAr = "تصاعد غازات نشادر مميزة أو ترك راسب معدني أبيض لا يحترق يدل على أملاح صوديوم/أمونيوم أو يوريا.",
                    isCorrectForCompound = { it.category == CompoundCategory.SODIUM_SALT || it.category == CompoundCategory.AMMONIUM_SALT || it == CompoundCatalog.UREA },
                    nextStepId = "STEP_SPECIAL_SALTS_AND_UREA",
                    errorExplanationAr = "المركب الفعلي ليس ملحاً معدنياً أو يوريا ولا يترك بقايا غير عضوية أو غاز نشادر مباشر."
                )
            )
        ),

        // =========================================================================
        // 2. AROMATIC BRANCH: ACIDITY TEST
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_ACIDITY_TEST_AROMATIC",
            stepTitleAr = "الخطوة 2: اختبار الحموضة والفوران (بيكربونات/كربونات الصوديوم)",
            stepTitleEn = "Step 2: Carbonate Effervescence Test",
            objectiveDescriptionAr = "أحضر أنبوبة اختبار، ضع جزءاً من المادة وأضف محلول كربونات الصوديوم أو بلورات البيكربونات مع الرج لمراقبة فوران غاز CO2.",
            suggestedEquipment = GlasswareType.TEST_TUBE,
            suggestedReagents = listOf(ReagentType.NA2CO3_SOL, ReagentType.DISTILLED_WATER),
            requiresHeating = false,
            questionPromptAr = "هل حدث فوران وتصاعد لفقاعات غاز ثاني أكسيد الكربون؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "AROMATIC_ACID_EFFERVESCENCE",
                    textAr = "حدوث فوران شديد وتصاعد غاز CO2 (أحماض أروماتية)",
                    descriptionAr = "تفاعل حامضي قوي مع إطلاق غاز CO2 يعكر ماء الجير، مما يثبت وجود مجموعة كربوكسيل أروماتية (-COOH).",
                    isCorrectForCompound = { it.category == CompoundCategory.AROMATIC_ACID },
                    nextStepId = "STEP_AROMATIC_ACIDS_FECL3",
                    errorExplanationAr = "المركب الفعلي لا يحتوي على مجموعة كربوكسيلية حرة، لذا لا يحدث فوران مع الكربونات (قد يكون فينول أو أمين)."
                ),
                SchemeDecisionOption(
                    optionId = "AROMATIC_NO_EFFERVESCENCE",
                    textAr = "عدم حدوث فوران (مجموعة الفينولات أو الأمينات الأروماتية)",
                    descriptionAr = "المادة لا تتفاعل مع الكربونات، مما يستبعد الأحماض الكربوكسيلية ويشير للفينولات أو القواعد الأروماتية.",
                    isCorrectForCompound = { it.isPhenolic || it.isAmine },
                    nextStepId = "STEP_PHENOL_VS_AMINE",
                    errorExplanationAr = "المركب الفعلي حمض كربوكسيلي أروماتي قوي ويثير فوراناً واضحاً مع كربونات الصوديوم."
                )
            )
        ),

        // =========================================================================
        // 3. ALIPHATIC BRANCH: ACIDITY TEST
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_ACIDITY_TEST_ALIPHATIC",
            stepTitleAr = "الخطوة 2: اختبار الحموضة للأليفاتية (كربونات الصوديوم)",
            stepTitleEn = "Step 2: Aliphatic Acidity Test",
            objectiveDescriptionAr = "أحضر أنبوبة اختبار، أضف المادة المجهولة مع الماء ومحلول كربونات الصوديوم Na2CO3.",
            suggestedEquipment = GlasswareType.TEST_TUBE,
            suggestedReagents = listOf(ReagentType.NA2CO3_SOL, ReagentType.DISTILLED_WATER),
            requiresHeating = false,
            questionPromptAr = "هل حدث فوران وتصاعد غاز CO2 مع كربونات الصوديوم؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "ALIPHATIC_ACID_CONFIRMED",
                    textAr = "حدوث فوران وتصاعد غاز CO2 (أحماض أليفاتية)",
                    descriptionAr = "يدل على وجود مجموعة كربوكسيل أليفاتية (أوكساليك، طرطريك، ستريك، فورميك، خليك).",
                    isCorrectForCompound = { it.category == CompoundCategory.ALIPHATIC_ACID },
                    nextStepId = "STEP_ALIPHATIC_ACIDS_CACL2",
                    errorExplanationAr = "المركب الفعلي ليس حمضاً أليفاتياً كربوكسيلياً ولم يكن ليحدث فوراناً."
                ),
                SchemeDecisionOption(
                    optionId = "ALIPHATIC_NO_EFFERVESCENCE",
                    textAr = "عدم حدوث فوران (الانتقال للسكريات أو المركبات الخاصة)",
                    descriptionAr = "المادة لا تعطي تفاعل حامضي مع الكربونات.",
                    isCorrectForCompound = { it.category != CompoundCategory.ALIPHATIC_ACID },
                    nextStepId = "STEP_SUGARS_MOLISCH",
                    errorExplanationAr = "المركب الفعلي حمض أليفاتي قوي وكان يجب أن يتفاعل بفوران مع الكربونات."
                )
            )
        ),

        // =========================================================================
        // 4. ALIPHATIC ACIDS: CACL2 TIMING TEST
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_ALIPHATIC_ACIDS_CACL2",
            stepTitleAr = "الخطوة 3: اختبار كلوريد الكالسيوم (CaCl2) بالتوقيت والحرارة",
            stepTitleEn = "Step 3: Calcium Chloride Timing Test",
            objectiveDescriptionAr = "حضر محلولاً متعادلاً من الحمض باستخدام قطرات مخففة من هيدروكسيد الأمونيوم NH4OH، ثم أضف محلول كلوريد الكالسيوم CaCl2 وراقب توقيت تكون الراسب الأبيض على البارد، مع الخدش، أو بعد الغليان.",
            suggestedEquipment = GlasswareType.TEST_TUBE,
            suggestedReagents = listOf(ReagentType.AMMONIUM_HYDROXIDE, ReagentType.CACL2_SOL, ReagentType.DISTILLED_WATER),
            requiresHeating = true,
            questionPromptAr = "متى تشكل الراسب الأبيض لكلوريد الكالسيوم؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "CACL2_INSTANT_COLD",
                    textAr = "راسب أبيض فوري على البارد (أوكسالات الكالسيوم)",
                    descriptionAr = "يتكون راسب أبيض غير قابل للذوبان فوراً بمجرد إضافة CaCl2 دون الحاجة لتسخين أو خدش (حمض الأوكساليك).",
                    isCorrectForCompound = { it == CompoundCatalog.OXALIC_ACID },
                    nextStepId = "STEP_IDENTIFIED_OXALIC_ACID",
                    errorExplanationAr = "حمض الأوكساليك فقط هو الذي يرسب الكالسيوم فورياً على البارد. المركبات الأخرى تتطلب خدشاً أو غلياناً أو لا ترسب."
                ),
                SchemeDecisionOption(
                    optionId = "CACL2_SCRATCH_WARM",
                    textAr = "راسب أبيض يظهر بعد الخدش بساق زجاجية أو تدفئة خفيفة (طرطرات الكالسيوم)",
                    descriptionAr = "يتكون راسب بلوري أبيض بعد حك جدار الأنبوبة بساق زجاجية وتدفئة خفيفة (حمض الطرطريك).",
                    isCorrectForCompound = { it == CompoundCatalog.TARTARIC_ACID },
                    nextStepId = "STEP_IDENTIFIED_TARTARIC_ACID",
                    errorExplanationAr = "حمض الطرطريك يعطي راسباً بلورياً بعد الخدش والتسخين الهادئ، بينما الأوكساليك فوري والستريك يحتاج لغليان مستمر."
                ),
                SchemeDecisionOption(
                    optionId = "CACL2_BOILING_HOT",
                    textAr = "راسب أبيض لا يظهر إلا بعد الغليان المستمر لدقيقة (سترات الكالسيوم)",
                    descriptionAr = "المحلول يظل رائقاً على البارد، لكنه يتعكر ويتكون راسب أبيض ناصع عند الغليان ويختفي جزئياً بالتبريد (حمض الستريك).",
                    isCorrectForCompound = { it == CompoundCatalog.CITRIC_ACID },
                    nextStepId = "STEP_IDENTIFIED_CITRIC_ACID",
                    errorExplanationAr = "حمض الستريك يتميز بعدم الترسيب إلا على الساخن بالغليان؛ بينما الأوكساليك والطرطريك يرسبان قبله."
                ),
                SchemeDecisionOption(
                    optionId = "CACL2_NO_PPT",
                    textAr = "لم يتكون أي راسب أبيض حتى بعد الغليان (أحماض أليفاتية أخرى)",
                    descriptionAr = "أملاح الكالسيوم ذائبة تماماً في الماء، مما يشير إلى أحماض أحادية الكربوكسيل قصيرة السلسلة.",
                    isCorrectForCompound = { it.category == CompoundCategory.ALIPHATIC_ACID && it != CompoundCatalog.OXALIC_ACID && it != CompoundCatalog.TARTARIC_ACID && it != CompoundCatalog.CITRIC_ACID },
                    nextStepId = "STEP_SPECIAL_SALTS_AND_UREA",
                    errorExplanationAr = "المركب الفعلي يرسب الكالسيوم كأوكسالات أو طرطرات أو سترات."
                )
            )
        ),

        // =========================================================================
        // 5. AROMATIC ACIDS: NEUTRAL FECL3 TEST
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_AROMATIC_ACIDS_FECL3",
            stepTitleAr = "الخطوة 3: اختبار كلوريد الحديديك المتعادل (Neutral FeCl3)",
            stepTitleEn = "Step 3: Neutral Ferric Chloride Test",
            objectiveDescriptionAr = "حضر محلولاً متعادلاً من الحمض الأروماتي (بإضافة قطرات NH4OH والتسخين لطرد الأمونيا الزائدة حتى يصبح متعادلاً)، ثم أضف قطرات من كلوريد الحديديك المتعادل.",
            suggestedEquipment = GlasswareType.TEST_TUBE,
            suggestedReagents = listOf(ReagentType.AMMONIUM_HYDROXIDE, ReagentType.NEUTRAL_FECL3, ReagentType.DISTILLED_WATER),
            requiresHeating = true,
            questionPromptAr = "ما هو اللون أو الراسب المتكون مع كلوريد الحديديك؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "FECL3_VIOLET_SALICYLIC",
                    textAr = "لون بنفسجي مكثف مميز (مجموعة هيدروكسيل فينولية مع كربوكسيل)",
                    descriptionAr = "تكون معقد حديدي بنفسجي زاهي ثابت يدل فوراً على حمض الساليسيليك (Salicylic Acid).",
                    isCorrectForCompound = { it == CompoundCatalog.SALICYLIC_ACID },
                    nextStepId = "STEP_IDENTIFIED_SALICYLIC_ACID",
                    errorExplanationAr = "اللون البنفسجي مع كلوريد الحديديك خاص بالساليسيليك لاحتوائه على مجموعة OH فينولية مجاورة للكربوكسيل."
                ),
                SchemeDecisionOption(
                    optionId = "FECL3_BUFF_PPT",
                    textAr = "راسب برتقالي لحمي / بني باهت (Buff Precipitate)",
                    descriptionAr = "تكون راسب بنزوات أو فيثالات أو سينامات الحديديك، مما يستلزم اختبارات تأكيدية إضافية للتمييز بينها.",
                    isCorrectForCompound = { it == CompoundCatalog.BENZOIC_ACID || it == CompoundCatalog.PHTHALIC_ACID || it == CompoundCatalog.CINNAMIC_ACID },
                    nextStepId = "STEP_AROMATIC_ACID_CONFIRMATORY",
                    errorExplanationAr = "المركب الفعلي يعطي لوناً بنفسجياً (ساليسيليك) أو سلوكاً مختلفاً."
                )
            )
        ),

        // =========================================================================
        // 6. AROMATIC ACIDS CONFIRMATORY (FLUORESCEIN & BROMINE WATER)
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_AROMATIC_ACID_CONFIRMATORY",
            stepTitleAr = "الخطوة 4: التفرقة بين (بنزويك / فيثاليك / سيناميك) بالفلوروسين وماء البروم",
            stepTitleEn = "Step 4: Confirmatory Fluorescein & Unsaturation Tests",
            objectiveDescriptionAr = "أجرِ اختبار الفلوروسين: سخن المادة مع بلورات الريزورسينول وقطرات H2SO4 مركز ثم صب الناتج في بيكر يحتوي على محلول NaOH، أو أجرِ اختبار ماء البروم.",
            suggestedEquipment = GlasswareType.BEAKER,
            suggestedReagents = listOf(ReagentType.RESORCINOL_CRYSTALS, ReagentType.CONC_H2SO4, ReagentType.NAOH_20, ReagentType.BROMINE_WATER),
            requiresHeating = true,
            questionPromptAr = "ما هي النتيجة الإيجابية التي ظهرت؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "CONFIRM_FLUORESCEIN_GREEN",
                    textAr = "تألق وإشعاع فلوروسيني أخضر ساطع في القلوي (حمض الفيثاليك)",
                    descriptionAr = "تكون صبغة الفلوروسين ذات الإشعاع الأخضر الفوسفوري المميز يدل على حمض الفيثاليك أو أنهيدريد الفيثاليك.",
                    isCorrectForCompound = { it == CompoundCatalog.PHTHALIC_ACID },
                    nextStepId = "STEP_IDENTIFIED_PHTHALIC_ACID",
                    errorExplanationAr = "حمض الفيثاليك فقط هو الذي يعطي اختبار الفلوروسين الموجب مع الريزورسينول."
                ),
                SchemeDecisionOption(
                    optionId = "CONFIRM_BROMINE_DECOLORIZED",
                    textAr = "زوال لون ماء البروم البرتقالي فوراً دون تسخين (حمض السيناميك)",
                    descriptionAr = "تفاعل إضافة على الرابطة المزدوجة غير المشبعة (C=C) ينزع لون البروم ويدل على حمض السيناميك.",
                    isCorrectForCompound = { it == CompoundCatalog.CINNAMIC_ACID },
                    nextStepId = "STEP_IDENTIFIED_CINNAMIC_ACID",
                    errorExplanationAr = "حمض السيناميك فقط هو الحمض الأروماتي غير المشبع الذي ينزع لون ماء البروم."
                ),
                SchemeDecisionOption(
                    optionId = "CONFIRM_BENZOIC_NEGATIVE",
                    textAr = "سالب للفلوروسين وسالب لماء البروم (حمض البنزويك)",
                    descriptionAr = "لا يعطي إشعاع فلوروسيني ولا ينزع لون البروم، ويتبلور في صورة إبر لامعة عند التبريد (حمض البنزويك).",
                    isCorrectForCompound = { it == CompoundCatalog.BENZOIC_ACID },
                    nextStepId = "STEP_IDENTIFIED_BENZOIC_ACID",
                    errorExplanationAr = "المركب الفعلي يحتوي على رابطة مزدوجة (سيناميك) أو مجموعة داي كربوكسيلية (فيثاليك)."
                )
            )
        ),

        // =========================================================================
        // 7. PHENOL VS AMINE DIFFERENTIATION
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_PHENOL_VS_AMINE",
            stepTitleAr = "الخطوة 3: التفرقة بين الفينولات والأمينات بالذوبانية في (NaOH / HCl)",
            stepTitleEn = "Step 3: Phenols vs Amines Solubility & FeCl3",
            objectiveDescriptionAr = "اختبر ذوبان المادة في حمض هيدروكلوريك مخفف HCl وفي هيدروكسيد صوديوم NaOH 10%، ثم اختبر تفاعلها مع كلوريد الحديديك.",
            suggestedEquipment = GlasswareType.TEST_TUBE,
            suggestedReagents = listOf(ReagentType.NAOH_20, ReagentType.DILUTE_HCL, ReagentType.NEUTRAL_FECL3),
            requiresHeating = false,
            questionPromptAr = "كيف استجابت المادة المجهولة؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "PHENOL_FAMILY_DETECTED",
                    textAr = "تذوب في هيدروكسيد الصوديوم وتعطي ألواناً مع FeCl3 (مجموعة الفينولات)",
                    descriptionAr = "خاصية فينولية حمضية ضعيفة تسمح بالذوبان في القلويات القوية وتكوين معقدات ملونة مع الحديديك.",
                    isCorrectForCompound = { it.isPhenolic && !it.isAcidic },
                    nextStepId = "STEP_PHENOLS_SPECIFIC",
                    errorExplanationAr = "المركب الفعلي قاعدة أمينية أروماتية تذوب في الأحماض المخففة وتعطي اختبار صبغة الآزو."
                ),
                SchemeDecisionOption(
                    optionId = "AMINE_FAMILY_DETECTED",
                    textAr = "تذوب في حمض HCl المخفف وتعطي أملاح ديازونيوم (مجموعة الأمينات)",
                    descriptionAr = "قاعدة نيتروجينية عضوية تذوب في الأحماض المعدنية المخففة لتكوين أملاح كلوريد ذائبة.",
                    isCorrectForCompound = { it.isAmine },
                    nextStepId = "STEP_AMINES_AZO_DYE",
                    errorExplanationAr = "المركب الفعلي فينول حامضي يذوب في القواعد وليس أميناً قاعدياً."
                )
            )
        ),

        // =========================================================================
        // 8. PHENOLS SPECIFIC TESTS
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_PHENOLS_SPECIFIC",
            stepTitleAr = "الخطوة 4: التفرقة بين الفينولات (فينول / ريزورسينول / ألفا و بيتا نافثول)",
            stepTitleEn = "Step 4: Specific Phenolic Color Tests",
            objectiveDescriptionAr = "أضف قطرات من كلوريد الحديديك المتعادل، أو اختبر الذوبانية في الماء المغلي وتفاعل ماء البروم.",
            suggestedEquipment = GlasswareType.TEST_TUBE,
            suggestedReagents = listOf(ReagentType.NEUTRAL_FECL3, ReagentType.BROMINE_WATER, ReagentType.DISTILLED_WATER),
            requiresHeating = false,
            questionPromptAr = "ما هو اللون أو التفاعل النوعي المشاهد؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "PHENOL_VIOLET_COLOR",
                    textAr = "لون بنفسجي زاهي مع FeCl3 وراسب أبيض 2,4,6-ثلاثي بروموفينول (فينول)",
                    descriptionAr = "الفينول النقي السائل/الصلب ذو الرائحة الكربولية المميزة يعطي لون بنفسجي وراسب أبيض كثيف مع ماء البروم.",
                    isCorrectForCompound = { it == CompoundCatalog.PHENOL },
                    nextStepId = "STEP_IDENTIFIED_PHENOL",
                    errorExplanationAr = "المركب الفعلي يعطي لوناً أخضر داكناً (ريزورسينول) أو لا يعطي لوناً بنفسجياً مع FeCl3."
                ),
                SchemeDecisionOption(
                    optionId = "RESORCINOL_DARK_GREEN",
                    textAr = "لون أخضر داكن / بنفسجي مزرق مع FeCl3 يثبت بإضافة خلات صوديوم (ريزورسينول)",
                    descriptionAr = "الريزورسينول (ميتاداي هيدروكسي بنزين) يعطي تلون أخضر داكن مميز مع كلوريد الحديديك.",
                    isCorrectForCompound = { it == CompoundCatalog.RESORCINOL },
                    nextStepId = "STEP_IDENTIFIED_RESORCINOL",
                    errorExplanationAr = "الريزورسينول فقط هو الذي يعطي اللون الأخضر الداكن مع الحديديك ويذوب بسهولة بالغة في الماء."
                ),
                SchemeDecisionOption(
                    optionId = "BETA_NAPHTHOL_PALE_GREEN",
                    textAr = "شحيح الذوبان في الماء البارد، يعطي تعكراً أخضر خفيفاً ولا يعطي بنفسجي (بيتا-نافثول)",
                    descriptionAr = "بلورات بيضاء أو وردية خفيفة شحيحة الذوبان في الماء وتذوب في الصودا الكاوية وتتزاوج مع الديازونيوم.",
                    isCorrectForCompound = { it == CompoundCatalog.BETA_NAPHTHOL || it == CompoundCatalog.ALPHA_NAPHTHOL },
                    nextStepId = "STEP_IDENTIFIED_BETA_NAPHTHOL",
                    errorExplanationAr = "المركب الفعلي فينول أحادي أو ثنائي بسيط ذائب في الماء."
                )
            )
        ),

        // =========================================================================
        // 9. AMINES: AZO DYE TEST
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_AMINES_AZO_DYE",
            stepTitleAr = "الخطوة 4: اختبار صبغة الآزو (Azo Dye Diazotization & Coupling)",
            stepTitleEn = "Step 4: Azo Dye Coupling Test",
            objectiveDescriptionAr = "أذب المادة في حمض HCl مخفف، برد الأنبوبة في كأس ثلج حتى 0-5° مئوية، أضف قطرات من محلول نتريت الصوديوم NaNO2 لتكوين ملح الديازونيوم، ثم صب المحلول في بيكر يحتوي على محلول بيتا-نافثول في هيدروكسيد صوديوم.",
            suggestedEquipment = GlasswareType.BEAKER,
            suggestedReagents = listOf(ReagentType.DILUTE_HCL, ReagentType.NANO2_SOL, ReagentType.BETA_NAPHTHOL_NAOH),
            requiresHeating = false,
            questionPromptAr = "ما هو لون وتكوين صبغة الآزو المتكونة؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "AZO_RED_ORANGE_DYE",
                    textAr = "تكون راسب صبغة برتقالية / قرمزية زاهية فوراً (أمين أروماتي أولي)",
                    descriptionAr = "دليل قاطع على تكوين صبغة آزو آزورية متزاوجة، مما يثبت وجود أمين أروماتي أولي (أنيلين أو بارا-تولويدين أو ألفا-نافثيل أمين).",
                    isCorrectForCompound = { it.isAmine },
                    nextStepId = "STEP_AMINES_SPECIFIC_DIFFERENTIATION",
                    errorExplanationAr = "المركب الفعلي لا يحتوي على مجموعة أمين أروماتية أولية (-NH2) قادرة على تكوين ملح الديازونيوم المستقر."
                )
            )
        ),

        // =========================================================================
        // 10. AMINES SPECIFIC DIFFERENTIATION
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_AMINES_SPECIFIC_DIFFERENTIATION",
            stepTitleAr = "الخطوة 5: التمييز بين الأمينات (أنيلين سائل / بارا-تولويدين صلب / نافثيل أمين)",
            stepTitleEn = "Step 5: Specific Amine Differentiation",
            objectiveDescriptionAr = "لاحظ الحالة الفيزيائية (سائل زيتي بني داكن أم بلورات صلبة) وتفاعل ماء البروم / اللون مع FeCl3.",
            suggestedEquipment = GlasswareType.TEST_TUBE,
            suggestedReagents = listOf(ReagentType.BROMINE_WATER, ReagentType.NEUTRAL_FECL3),
            requiresHeating = false,
            questionPromptAr = "ما هي هوية الأمين المستنتجة بناءً على الحالة والخواص؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "AMINE_ANILINE",
                    textAr = "سائل زيتي بني مصفر ذو رائحة مميزة يعطي راسباً أبيض مع ماء البروم (أنيلين)",
                    descriptionAr = "الأنيلين سائل زيتي عطري مميز يكوّن 2,4,6-ثلاثي برومو أنيلين الأبيض مع ماء البروم.",
                    isCorrectForCompound = { it == CompoundCatalog.ANILINE },
                    nextStepId = "STEP_IDENTIFIED_ANILINE",
                    errorExplanationAr = "المركب الفعلي مادة صلبة بلورية (بارا-تولويدين أو نافثيل أمين) وليس سائل أنيلين."
                ),
                SchemeDecisionOption(
                    optionId = "AMINE_P_TOLUIDINE",
                    textAr = "مادة صلبة بلورية بيضاء/وردية ذات رائحة نفاذة شحيحة الذوبان في الماء (بارا-تولويدين)",
                    descriptionAr = "بارا تولويدين صلب بلوري ينصهر عند حوالي 44° مئوية ويعطي صبغة آزو برتقالية قوية.",
                    isCorrectForCompound = { it == CompoundCatalog.P_TOLUIDINE },
                    nextStepId = "STEP_IDENTIFIED_P_TOLUIDINE",
                    errorExplanationAr = "المركب الفعلي سائل (أنيلين) أو صلب بني داكن (ألفا نافثيل أمين)."
                ),
                SchemeDecisionOption(
                    optionId = "AMINE_NAPHTHYLAMINE",
                    textAr = "مادة صلبة ذات لون بني داكن/أرجواني تعطي تلوناً أزرق مع كلوريد الحديديك (ألفا-نافثيل أمين)",
                    descriptionAr = "ألفا نافثيل أمين مادة صلبة تتأكسد في الهواء وتعطي صبغة حمراء داكنة ولون أزرق بنفسجي مع FeCl3.",
                    isCorrectForCompound = { it == CompoundCatalog.ALPHA_NAPHTHYLAMINE || it == CompoundCatalog.BETA_NAPHTHYLAMINE },
                    nextStepId = "STEP_IDENTIFIED_ALPHA_NAPHTHYLAMINE",
                    errorExplanationAr = "المركب الفعلي أمين بنزيني بسيط (أنيلين أو تولويدين)."
                )
            )
        ),

        // =========================================================================
        // 11. SUGARS: MOLISCH TEST
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_SUGARS_MOLISCH",
            stepTitleAr = "الخطوة 2: اختبار مولش العام للسكريات (Molisch Test)",
            stepTitleEn = "Step 2: Molisch General Carbohydrate Test",
            objectiveDescriptionAr = "أذب جزءاً من المادة في قليل من الماء في أنبوبة اختبار، أضف 2-3 قطرات من كاشف ألفا-نافثول ورج جيداً، ثم اسكب بحرص شديد على جدار الأنبوبة المائل 1 مل من حمض الكبريتيك المركز Conc. H2SO4 لتكوين طبقة سفلية.",
            suggestedEquipment = GlasswareType.TEST_TUBE,
            suggestedReagents = listOf(ReagentType.ALPHA_NAPHTHOL, ReagentType.CONC_H2SO4, ReagentType.DISTILLED_WATER),
            requiresHeating = false,
            questionPromptAr = "ما هي المشاهدة المتكونة عند السطح الفاصل بين الطبقتين؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "MOLISCH_VIOLET_RING",
                    textAr = "تكون حلقة بنفسجية محمرة واضحة عند السطح الفاصل (مركب كربوهيدراتي/سكر)",
                    descriptionAr = "دليل قاطع على نزع الماء من جزيء السكر بواسطة الحمض المركز لتكوين الفورفورال الذي يتكثف مع ألفا-نافثول معطياً الحلقة البنفسجية.",
                    isCorrectForCompound = { it.isSugar },
                    nextStepId = "STEP_SUGARS_BARFOED",
                    errorExplanationAr = "المركب الفعلي ليس من السكريات ولا يعطي حلقة مولش البنفسجية عند السطح الفاصل."
                ),
                SchemeDecisionOption(
                    optionId = "MOLISCH_NEGATIVE",
                    textAr = "عدم تكون حلقة بنفسجية (الانتقال لليوريا والأملاح والمركبات الخاصة)",
                    descriptionAr = "المادة لا تحتوي على روابط كربوهيدراتية.",
                    isCorrectForCompound = { !it.isSugar },
                    nextStepId = "STEP_SPECIAL_SALTS_AND_UREA",
                    errorExplanationAr = "المركب الفعلي سكر كربوهيدراتي حقيقي ويعطي حلقة بنفسجية ممتازة مع كاشف مولش."
                )
            )
        ),

        // =========================================================================
        // 12. SUGARS: BARFOED & IODINE TEST
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_SUGARS_BARFOED",
            stepTitleAr = "الخطوة 3: التمييز بين السكريات بكاشف بارافويد واليود (Monosaccharide vs Disaccharide vs Starch)",
            stepTitleEn = "Step 3: Barfoed & Iodine Tests",
            objectiveDescriptionAr = "ضع محلول السكر مع كاشف بارافويد (خلات النحاس في وسط حمضي ضعيف) في حمام مائي مغلي وراقب توقيت ظهور الراسب الأحمر الطوبي من Cu2O، واختبر نقطة من محلول اليود.",
            suggestedEquipment = GlasswareType.WATER_BATH,
            suggestedReagents = listOf(ReagentType.BARFOED_REAGENT, ReagentType.IODINE_SOL, ReagentType.DISTILLED_WATER),
            requiresHeating = true,
            questionPromptAr = "ما هي نتيجة اختبار بارافويد واليود؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "BARFOED_FAST_MONO",
                    textAr = "راسب أحمر طوبي سريع خلال 2-3 دقائق من الغليان (سكر أحادي: جلوكوز / فركتوز)",
                    descriptionAr = "السكريات الأحادية تختزل كاشف بارافويد في الوسط الحامضي الضعيف بسرعة فائقة (2-3 دقائق).",
                    isCorrectForCompound = { it == CompoundCatalog.GLUCOSE || it == CompoundCatalog.FRUCTOSE },
                    nextStepId = "STEP_SUGARS_RAPID_FURFURAL",
                    errorExplanationAr = "السكريات الأحادية فقط هي التي تختزل بارافويد في غضون 2-3 دقائق؛ السكريات الثنائية تحتاج 8-10 دقائق."
                ),
                SchemeDecisionOption(
                    optionId = "BARFOED_SLOW_DI",
                    textAr = "راسب أحمر طوبي يتكون ببطء بعد 8-10 دقائق غليان مستمر (سكر ثنائي: سكروز / مالتوز)",
                    descriptionAr = "السكريات الثنائية لا تختزل بارافويد إلا بعد تحللها المائي بالحرارة والحمض بعد 8-10 دقائق (سكروز).",
                    isCorrectForCompound = { it == CompoundCatalog.SUCROSE || it == CompoundCatalog.MALTOSE || it == CompoundCatalog.LACTOSE },
                    nextStepId = "STEP_IDENTIFIED_SUCROSE",
                    errorExplanationAr = "المركب الفعلي سكر أحادي يختزل بارافويد خلال 2-3 دقائق فقط أو نشا عديد التسكر."
                ),
                SchemeDecisionOption(
                    optionId = "IODINE_BLUE_STARCH",
                    textAr = "تكون لون أزرق نيلي داكن فوري مع محلول اليود يزول بالتسخين ويعود بالتبريد (النشا)",
                    descriptionAr = "تكون مركب إدماج أزرق بين اليود وحلزون الأميلوز يثبت بشكل قاطع وجود النشا (Starch).",
                    isCorrectForCompound = { it == CompoundCatalog.STARCH },
                    nextStepId = "STEP_IDENTIFIED_STARCH",
                    errorExplanationAr = "اللون الأزرق الداكن مع اليود خاص بالنشا فقط ولا تعطيه السكريات البسيطة الذائبة."
                )
            )
        ),

        // =========================================================================
        // 13. SUGARS: RAPID FURFURAL TEST (GLUCOSE VS FRUCTOSE)
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_SUGARS_RAPID_FURFURAL",
            stepTitleAr = "الخطوة 4: التمييز بين الألدوز والكيتوز باختبار الفورفورال السريع (جلوكوز vs فركتوز)",
            stepTitleEn = "Step 4: Rapid Furfural / Seliwanoff Test",
            objectiveDescriptionAr = "أضف كاشف ألفا-نافثول وحمض HCl المركز واغلِ لمدة دقيقة واحدة بالضبط في حمام مائي.",
            suggestedEquipment = GlasswareType.BOILING_TUBE,
            suggestedReagents = listOf(ReagentType.ALPHA_NAPHTHOL, ReagentType.CONC_HCL, ReagentType.DISTILLED_WATER),
            requiresHeating = true,
            questionPromptAr = "متى ظهر اللون الأحمر الأرجواني في اختبار الفورفورال؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "FURFURAL_FAST_KETOSE",
                    textAr = "لون أحمر أرجواني فوري وساطع خلال 30 ثانية (سكر كيتوزي: فركتوز)",
                    descriptionAr = "الفركتوز (كيتوهكسوز) ينزع ماءه بسرعة مكوناً هيدروكسي ميثيل فورفورال الذي يعطي لوناً أحمر خلال ثوانٍ معدودة.",
                    isCorrectForCompound = { it == CompoundCatalog.FRUCTOSE },
                    nextStepId = "STEP_IDENTIFIED_FRUCTOSE",
                    errorExplanationAr = "الفركتوز فقط هو الذي يتفاعل خلال 30 ثانية؛ الجلوكوز (ألدوزي) يتطلب وقتاً أطول بكثير."
                ),
                SchemeDecisionOption(
                    optionId = "FURFURAL_SLOW_ALDOSE",
                    textAr = "لا يظهر اللون الأحمر إلا بعد غليان مستمر لعدة دقائق (سكر ألدوزي: جلوكوز)",
                    descriptionAr = "الجلوكوز (ألدوهكسوز) أبطأ بكثير في نزع الماء ولا يتلون بسرعة.",
                    isCorrectForCompound = { it == CompoundCatalog.GLUCOSE },
                    nextStepId = "STEP_IDENTIFIED_GLUCOSE",
                    errorExplanationAr = "المركب الفعلي كيتوزي (فركتوز) ويعطي اللون فوراً."
                )
            )
        ),

        // =========================================================================
        // 14. SPECIAL SALTS & UREA
        // =========================================================================
        SchemeStepNode(
            stepId = "STEP_SPECIAL_SALTS_AND_UREA",
            stepTitleAr = "الخطوة 3: الكشف عن اليوريا وأملاح الأمونيوم والصوديوم",
            stepTitleEn = "Step 3: Urea Decomposition & Salt Residues",
            objectiveDescriptionAr = "سخن كمية جافة من المادة في أنبوبة اختبار جافة حتى تنصهر وتتصلب مع تصاعد غاز النشادر، ثم برد وأضف 20% NaOH وقطرة واحدة من كبريتات النحاس CuSO4 (اختبار البيوريت)، أو اختبر القلوية بعد الحرق على زجاجة الساعة.",
            suggestedEquipment = GlasswareType.TEST_TUBE,
            suggestedReagents = listOf(ReagentType.NAOH_20, ReagentType.COPPER_SULFATE_SOL, ReagentType.SODA_LIME),
            requiresHeating = true,
            questionPromptAr = "ما هي المشاهدة الناتجة عن اختبار البيوريت أو التسخين؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "UREA_BIURET_VIOLET",
                    textAr = "تكون لون بنفسجي وردي مميز لاختبار البيوريت (اليوريا)",
                    descriptionAr = "تفكك اليوريا بالحرارة ينتج البيوريت (Biuret) الذي يعطي معقداً بنفسجياً وردياً مع أيونات النحاس في الوسط القلوي.",
                    isCorrectForCompound = { it == CompoundCatalog.UREA },
                    nextStepId = "STEP_IDENTIFIED_UREA",
                    errorExplanationAr = "اختبار البيوريت واللون البنفسجي الوردي هو الكشف النوعي القاطع لليوريا."
                ),
                SchemeDecisionOption(
                    optionId = "SODIUM_METALLIC_RESIDUE",
                    textAr = "ترك بقايا معدنية بيضاء من كربونات الصوديوم تذوب في الماء وتزرق عباد الشمس (ملح صوديومي)",
                    descriptionAr = "احتراق الشق العضوي وترك Na2CO3 غير العضوي القلوي يؤكد وجود ملح صوديومي لحمض عضوي.",
                    isCorrectForCompound = { it.category == CompoundCategory.SODIUM_SALT },
                    nextStepId = "STEP_IDENTIFIED_SODIUM_SALT",
                    errorExplanationAr = "المركب الفعلي ليس ملحاً صوديومياً ولا يترك كربونات صوديوم غير عضوية بعد الاحتراق."
                ),
                SchemeDecisionOption(
                    optionId = "AMMONIUM_SALT_AMMONIA",
                    textAr = "تصاعد غاز النشادر مع NaOH على البارد دون تفكك حراري (ملح أمونيوم)",
                    descriptionAr = "تفاعل الإحلال مع هيدروكسيد الصوديوم يطلق غاز النشادر النفاذ على البارد.",
                    isCorrectForCompound = { it.category == CompoundCategory.AMMONIUM_SALT },
                    nextStepId = "STEP_IDENTIFIED_AMMONIUM_SALT",
                    errorExplanationAr = "أملاح الأمونيوم فقط هي التي تطلق النشادر بمجرد إضافة هيدروكسيد الصوديوم على البارد دون تسخين."
                )
            )
        ),

        // =========================================================================
        // 15. TERMINAL IDENTIFICATION STEPS
        // =========================================================================
        createTerminalNode("STEP_IDENTIFIED_OXALIC_ACID", "تأكيد حمض الأوكساليك (Oxalic Acid)", CompoundCatalog.OXALIC_ACID),
        createTerminalNode("STEP_IDENTIFIED_TARTARIC_ACID", "تأكيد حمض الطرطريك (Tartaric Acid)", CompoundCatalog.TARTARIC_ACID),
        createTerminalNode("STEP_IDENTIFIED_CITRIC_ACID", "تأكيد حمض الستريك (Citric Acid)", CompoundCatalog.CITRIC_ACID),
        createTerminalNode("STEP_IDENTIFIED_BENZOIC_ACID", "تأكيد حمض البنزويك (Benzoic Acid)", CompoundCatalog.BENZOIC_ACID),
        createTerminalNode("STEP_IDENTIFIED_SALICYLIC_ACID", "تأكيد حمض الساليسيليك (Salicylic Acid)", CompoundCatalog.SALICYLIC_ACID),
        createTerminalNode("STEP_IDENTIFIED_PHTHALIC_ACID", "تأكيد حمض الفيثاليك (Phthalic Acid)", CompoundCatalog.PHTHALIC_ACID),
        createTerminalNode("STEP_IDENTIFIED_CINNAMIC_ACID", "تأكيد حمض السيناميك (Cinnamic Acid)", CompoundCatalog.CINNAMIC_ACID),
        createTerminalNode("STEP_IDENTIFIED_PHENOL", "تأكيد الفينول (Phenol)", CompoundCatalog.PHENOL),
        createTerminalNode("STEP_IDENTIFIED_RESORCINOL", "تأكيد الريزورسينول (Resorcinol)", CompoundCatalog.RESORCINOL),
        createTerminalNode("STEP_IDENTIFIED_BETA_NAPHTHOL", "تأكيد بيتا-نافثول (Beta-Naphthol)", CompoundCatalog.BETA_NAPHTHOL),
        createTerminalNode("STEP_IDENTIFIED_ANILINE", "تأكيد الأنيلين (Aniline)", CompoundCatalog.ANILINE),
        createTerminalNode("STEP_IDENTIFIED_P_TOLUIDINE", "تأكيد بارا-تولويدين (p-Toluidine)", CompoundCatalog.P_TOLUIDINE),
        createTerminalNode("STEP_IDENTIFIED_ALPHA_NAPHTHYLAMINE", "تأكيد ألفا-نافثيل أمين (alpha-Naphthylamine)", CompoundCatalog.ALPHA_NAPHTHYLAMINE),
        createTerminalNode("STEP_IDENTIFIED_GLUCOSE", "تأكيد الجلوكوز (D-Glucose)", CompoundCatalog.GLUCOSE),
        createTerminalNode("STEP_IDENTIFIED_FRUCTOSE", "تأكيد الفركتوز (D-Fructose)", CompoundCatalog.FRUCTOSE),
        createTerminalNode("STEP_IDENTIFIED_SUCROSE", "تأكيد السكروز (Sucrose)", CompoundCatalog.SUCROSE),
        createTerminalNode("STEP_IDENTIFIED_STARCH", "تأكيد النشا (Starch)", CompoundCatalog.STARCH),
        createTerminalNode("STEP_IDENTIFIED_UREA", "تأكيد اليوريا (Urea)", CompoundCatalog.UREA),
        createTerminalNode("STEP_IDENTIFIED_SODIUM_SALT", "تأكيد ملح الصوديوم (Sodium Salt)", CompoundCatalog.SODIUM_OXALATE),
        createTerminalNode("STEP_IDENTIFIED_AMMONIUM_SALT", "تأكيد ملح الأمونيوم (Ammonium Salt)", CompoundCatalog.AMMONIUM_OXALATE)
    ).associateBy { it.stepId }

    private fun createTerminalNode(stepId: String, titleAr: String, compound: ChemicalCompound): SchemeStepNode {
        return SchemeStepNode(
            stepId = stepId,
            stepTitleAr = "الاستنتاج النهائي: $titleAr",
            stepTitleEn = "Terminal Identification: ${compound.nameEn}",
            objectiveDescriptionAr = "وصلت إلى نهاية مسار السكيمة العملية. تحقق من هوية المركب النهائية المستنتجة لتسجيل النتيجة في التقرير النهائي.",
            suggestedEquipment = GlasswareType.TEST_TUBE,
            suggestedReagents = emptyList(),
            requiresHeating = false,
            questionPromptAr = "هل تؤكد استنتاج هوية المركب بأنه [${compound.nameAr} (${compound.formula})]؟",
            options = listOf(
                SchemeDecisionOption(
                    optionId = "CONFIRM_${compound.id}",
                    textAr = "نعم، هوية المركب هي: ${compound.nameAr} (${compound.formula})",
                    descriptionAr = "تأكيد النتيجة النهائية ومطابقتها مع سكيمة البفه الكسبانة.",
                    isCorrectForCompound = { it.id == compound.id || (it.category == compound.category && it.isSalt) },
                    nextStepId = null, // Reached the end!
                    candidateCompounds = listOf(compound),
                    errorExplanationAr = "المركب الفعلي يختلف عن هذا الاختيار النهائي."
                )
            )
        )
    }
}
