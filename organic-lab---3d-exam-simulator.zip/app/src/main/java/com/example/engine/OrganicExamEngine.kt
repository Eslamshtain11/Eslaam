package com.example.engine

import com.example.model.*
import kotlin.random.Random

object OrganicExamEngine {

    /**
     * Creates a new random exam sample according to the requested mode or pool.
     */
    fun generateRandomSample(allowMixture: Boolean = true): ExamSample {
        val useMixture = allowMixture && Random.nextFloat() > 0.45f
        if (!useMixture) {
            val comp = CompoundCatalog.frequentExamPool.random()
            return ExamSample(
                id = java.util.UUID.randomUUID().toString(),
                mixtureCategory = MixtureCategory.SINGLE,
                component1 = comp,
                component2 = null
            )
        }

        // Pick a valid mixture category from the 6 official families
        val category = listOf(
            MixtureCategory.A_PLUS_A,
            MixtureCategory.A_PLUS_B,
            MixtureCategory.A_PLUS_PH,
            MixtureCategory.B_PLUS_PH,
            MixtureCategory.A_PLUS_N,
            MixtureCategory.N_PLUS_N
        ).random()

        val (c1, c2) = when (category) {
            MixtureCategory.A_PLUS_A -> {
                val aliphatic = listOf(CompoundCatalog.OXALIC_ACID, CompoundCatalog.TARTARIC_ACID, CompoundCatalog.CITRIC_ACID).random()
                val aromatic = listOf(CompoundCatalog.BENZOIC_ACID, CompoundCatalog.SALICYLIC_ACID, CompoundCatalog.PHTHALIC_ACID, CompoundCatalog.CINNAMIC_ACID).random()
                Pair(aliphatic, aromatic)
            }
            MixtureCategory.A_PLUS_B -> {
                val acid = listOf(CompoundCatalog.BENZOIC_ACID, CompoundCatalog.OXALIC_ACID, CompoundCatalog.SALICYLIC_ACID, CompoundCatalog.TARTARIC_ACID).random()
                val base = listOf(CompoundCatalog.ANILINE, CompoundCatalog.P_TOLUIDINE, CompoundCatalog.ALPHA_NAPHTHYLAMINE, CompoundCatalog.BETA_NAPHTHYLAMINE).random()
                Pair(acid, base)
            }
            MixtureCategory.A_PLUS_PH -> {
                val acid = listOf(CompoundCatalog.BENZOIC_ACID, CompoundCatalog.PHTHALIC_ACID, CompoundCatalog.SALICYLIC_ACID, CompoundCatalog.OXALIC_ACID).random()
                val phenol = listOf(CompoundCatalog.RESORCINOL, CompoundCatalog.PHENOL, CompoundCatalog.ALPHA_NAPHTHOL, CompoundCatalog.BETA_NAPHTHOL).random()
                Pair(acid, phenol)
            }
            MixtureCategory.B_PLUS_PH -> {
                val base = listOf(CompoundCatalog.ANILINE, CompoundCatalog.P_TOLUIDINE, CompoundCatalog.ALPHA_NAPHTHYLAMINE).random()
                val phenol = listOf(CompoundCatalog.PHENOL, CompoundCatalog.RESORCINOL, CompoundCatalog.BETA_NAPHTHOL).random()
                Pair(base, phenol)
            }
            MixtureCategory.A_PLUS_N -> {
                val acid = listOf(CompoundCatalog.BENZOIC_ACID, CompoundCatalog.SALICYLIC_ACID, CompoundCatalog.OXALIC_ACID, CompoundCatalog.TARTARIC_ACID).random()
                val sugarOrNeutral = listOf(CompoundCatalog.GLUCOSE, CompoundCatalog.SUCROSE, CompoundCatalog.UREA, CompoundCatalog.STARCH).random()
                Pair(acid, sugarOrNeutral)
            }
            MixtureCategory.N_PLUS_N -> {
                val s1 = listOf(CompoundCatalog.GLUCOSE, CompoundCatalog.FRUCTOSE, CompoundCatalog.SUCROSE).random()
                val s2 = listOf(CompoundCatalog.STARCH, CompoundCatalog.UREA).random()
                Pair(s1, s2)
            }
            else -> Pair(CompoundCatalog.BENZOIC_ACID, CompoundCatalog.GLUCOSE)
        }

        return ExamSample(
            id = java.util.UUID.randomUUID().toString(),
            mixtureCategory = category,
            component1 = c1,
            component2 = c2
        )
    }

    /**
     * Executes any qualitative analysis test deterministically on the provided fraction of the sample.
     */
    fun performTest(
        sample: ExamSample,
        fraction: SampleFractionType,
        testId: TestId,
        separationState: Map<SampleFractionType, ChemicalCompound?> = emptyMap()
    ): ObservationResult {
        // Resolve the active compound for this fraction
        val targetCompound = when (fraction) {
            SampleFractionType.ORIGINAL -> null // whole sample/mixture
            SampleFractionType.RESIDUE,
            SampleFractionType.FILTRATE,
            SampleFractionType.FRACTION_A,
            SampleFractionType.FRACTION_B -> separationState[fraction] ?: sample.component1
        }

        if (targetCompound != null) {
            return evaluateSingleCompound(targetCompound, testId)
        }

        // Whole sample evaluation (mixture or single)
        if (!sample.isMixture) {
            return evaluateSingleCompound(sample.component1, testId)
        }

        return evaluateMixture(sample, testId)
    }

    private fun evaluateMixture(sample: ExamSample, testId: TestId): ObservationResult {
        val c1 = sample.component1
        val c2 = sample.component2 ?: return evaluateSingleCompound(c1, testId)

        return when (testId) {
            TestId.HEAT_TEST -> {
                val hasSugar = c1.isSugar || c2.isSugar
                val hasAromatic = c1.isAromatic || c2.isAromatic
                when {
                    hasSugar -> ObservationResult(
                        titleAr = "إنصهار وتفحم مع انتفاخ ورائحة سكر محروق",
                        descriptionAr = "المادة تنصهر وتسود وتنتفخ مع تصاعد دخان ورائحة سكر محترق مميزة (كراميل)",
                        visualColorHex = 0xFF1E293B,
                        charring = true,
                        melting = true,
                        swelling = true,
                        hasFlame = true,
                        isSmokyFlame = hasAromatic,
                        odor = OdorType.BURNT_SUGAR,
                        conclusionClueAr = "دليل على وجود سكريات أو أحماض هيدروكسيلية في الخليط"
                    )
                    hasAromatic -> ObservationResult(
                        titleAr = "إحتراق مع لهب مدخن",
                        descriptionAr = "المادة تشتعل بلهب مصحوب بسناج ودخان أسود كثيف",
                        visualColorHex = 0xFF334155,
                        hasFlame = true,
                        isSmokyFlame = true,
                        conclusionClueAr = "دليل على وجود مركب أروماتي في الخليط"
                    )
                    else -> ObservationResult(
                        titleAr = "إحتراق بدون لهب مدخن",
                        descriptionAr = "المادة تحترق بهدوء بلهب أزرق خافت دون دخان أسود",
                        visualColorHex = 0xFF64748B,
                        hasFlame = true,
                        isSmokyFlame = false,
                        conclusionClueAr = "دليل على الطبيعة الأليفاتية للمركبات"
                    )
                }
            }
            TestId.SODA_LIME_TEST -> {
                val hasUreaOrAmmonium = (c1 == CompoundCatalog.UREA || c2 == CompoundCatalog.UREA || c1.category == CompoundCategory.AMMONIUM_SALT || c2.category == CompoundCategory.AMMONIUM_SALT)
                val hasAmine = c1.isAmine || c2.isAmine
                val hasPhenol = c1.isPhenolic || c2.isPhenolic
                val hasAromaticAcid = (c1.category == CompoundCategory.AROMATIC_ACID || c2.category == CompoundCategory.AROMATIC_ACID)

                when {
                    hasUreaOrAmmonium -> ObservationResult(
                        titleAr = "تصاعد غاز النشادر (Ammonia)",
                        descriptionAr = "تصاعد غاز ذو رائحة نشادر نفاذة تزرق ورقة عباد الشمس الحمراء المبللة",
                        gasBubbles = true,
                        odor = OdorType.AMMONIA,
                        conclusionClueAr = "دليل على أملاح أمونيوم أو يوريا أو أميدات"
                    )
                    hasAmine -> ObservationResult(
                        titleAr = "تصاعد رائحة أمينات أروماتية",
                        descriptionAr = "تصاعد رائحة مميزة تشبه رائحة الأنيلين والأسماك",
                        odor = OdorType.AROMATIC_AMINE,
                        conclusionClueAr = "دليل على وجود أمينات أروماتية"
                    )
                    hasPhenol -> ObservationResult(
                        titleAr = "تصاعد رائحة الفينول (Carbolic)",
                        descriptionAr = "تصاعد أبخرة ذات رائحة فينولية مطهرة مميزة",
                        odor = OdorType.PHENOL,
                        conclusionClueAr = "دليل على وجود فينولات أو أحماض فينولية"
                    )
                    hasAromaticAcid -> ObservationResult(
                        titleAr = "تصاعد رائحة البنزين العطرية",
                        descriptionAr = "تصاعد رائحة البنزين العطرية المميزة نتيجة نزع مجموعة الكربوكسيل",
                        odor = OdorType.BENZENE,
                        conclusionClueAr = "دليل على وجود أحماض أروماتية أو أملاحها"
                    )
                    else -> ObservationResult(
                        titleAr = "رائحة سكر محترق خفيفة",
                        descriptionAr = "تصاعد رائحة كراميلية محترقة",
                        odor = OdorType.BURNT_SUGAR
                    )
                }
            }
            TestId.ACIDITY_TEST -> {
                val hasAcid = c1.isAcidic || c2.isAcidic || c1 == CompoundCatalog.UREA // urea salts / acids
                if (hasAcid) {
                    ObservationResult(
                        titleAr = "فوران وتصاعد غاز ثاني أكسيد الكربون CO₂",
                        descriptionAr = "حدوث فوران نشط مع تصاعد فقاعات غاز CO₂ بكثافة",
                        gasBubbles = true,
                        conclusionClueAr = "دليل قاطع على وجود حمض كربوكسيلي في الخليط (+Ve)"
                    )
                } else {
                    ObservationResult(
                        titleAr = "سالب - لا يحدث فوران",
                        descriptionAr = "المحلول يظل هادئاً دون تصاعد أي فقاعات غازية",
                        gasBubbles = false,
                        conclusionClueAr = "الخليط لا يحتوي على أحماض كربوكسيلية حرة"
                    )
                }
            }
            TestId.MOLISCH_TEST -> {
                val hasSugar = c1.isSugar || c2.isSugar
                if (hasSugar) {
                    ObservationResult(
                        titleAr = "تكون حلقة حمراء بنفسجية على السطح الفاصل",
                        descriptionAr = "ظهور حلقة بنفسجية غنية عند تلاقي الطبقتين، وتنتشر بالرج لتلون الأنبوبة بالكامل",
                        purpleRing = true,
                        visualColorHex = 0xFF7C3AED,
                        conclusionClueAr = "دليل قاطع على وجود كربوهيدرات/سكريات في الخليط (+Ve Molisch)"
                    )
                } else {
                    ObservationResult(
                        titleAr = "سالب - لا تتكون حلقة بنفسجية",
                        descriptionAr = "عدم ظهور أي حلقة ملونة بين الطبقتين",
                        purpleRing = false,
                        conclusionClueAr = "الخليط خالٍ من السكريات والكربوهيدرات"
                    )
                }
            }
            TestId.NITRATION_TEST -> {
                val hasAromatic = c1.isAromatic || c2.isAromatic
                if (hasAromatic) {
                    ObservationResult(
                        titleAr = "ظهور لون أصفر/برتقالي مع قطرات زيتية وراسب",
                        descriptionAr = "تكون مشتقات النيترو بلون أصفر برتقالي وظهور راسب عند الصب في الماء",
                        visualColorHex = 0xFFF59E0B,
                        precipitate = PrecipitateColor.YELLOW,
                        oilyDroplets = true,
                        conclusionClueAr = "إيجابي للمركبات الأروماتية (+Ve Aromatic)"
                    )
                } else {
                    ObservationResult(
                        titleAr = "سالب - محلول شفاف عديم اللون",
                        descriptionAr = "لم يتكون أي راسب أو لون أصفر أو زيت عند الصب في الماء",
                        visualColorHex = 0xFFF8FAFC,
                        conclusionClueAr = "سالب - المركبات أليفاتية"
                    )
                }
            }
            // Separation Actions
            TestId.SEPARATE_WATER -> {
                when (sample.mixtureCategory) {
                    MixtureCategory.A_PLUS_A -> ObservationResult(
                        titleAr = "فصل ناجح بالماء والترشيح",
                        descriptionAr = "ذاب الحمض الأليفاتي (${c1.nameAr}) في الماء، بينما ترسب الحمض الأروماتي (${c2.nameAr}) على ورقة الترشيح كراسب صلب",
                        conclusionClueAr = "الراسب: حمض أروماتي | الراشح: حمض أليفاتي"
                    )
                    MixtureCategory.N_PLUS_N -> ObservationResult(
                        titleAr = "فصل ناجح بالماء والترشيح",
                        descriptionAr = "ذاب السكر الذائب في الماء ونفذ في الراشح، بينما تجمع النشا غير الذائب على ورقة الترشيح",
                        conclusionClueAr = "الراسب: نشا | الراشح: سكر أحادي أو ثنائي ذائب"
                    )
                    else -> ObservationResult(
                        titleAr = "ذوبان جزئي بالماء",
                        descriptionAr = "تمت إضافة الماء والترشيح، يوصى باستخدام الكاشف النوعي للفصل المناسب لهذه الفئة"
                    )
                }
            }
            TestId.SEPARATE_NA2CO3 -> {
                when (sample.mixtureCategory) {
                    MixtureCategory.A_PLUS_B -> ObservationResult(
                        titleAr = "فصل ناجح بكربونات الصوديوم Na₂CO₃",
                        descriptionAr = "ذاب الحمض متفاعلاً ومكوناً ملح الصوديوم في الراشح، وترسبت القاعدة العضوية (${c2.nameAr}) على ورقة الترشيح",
                        conclusionClueAr = "الراسب: قاعدة عضوية (تذوب في HCl) | الراشح: ملح حمض (يرسب بـ Conc HCl)"
                    )
                    MixtureCategory.A_PLUS_PH -> ObservationResult(
                        titleAr = "فصل ناجح بكربونات الصوديوم Na₂CO₃",
                        descriptionAr = "ذاب الحمض مكوناً ملح الصوديوم في الراشح، بينما بقي الفينول كراسب على ورقة الترشيح",
                        conclusionClueAr = "الراسب: فينول (يكشف بـ FeCl₃) | الراشح: ملح حمض كربوكسيلي"
                    )
                    MixtureCategory.A_PLUS_N -> ObservationResult(
                        titleAr = "فصل ناجح بكربونات الصوديوم Na₂CO₃",
                        descriptionAr = "ذاب الحمض في الراشح، وتجمع المركب المتعادل / السكر في الراسب على ورقة الترشيح",
                        conclusionClueAr = "الراسب: سكر / مركب متعادل | الراشح: ملح حمض"
                    )
                    else -> ObservationResult(
                        titleAr = "تفاعل مع كربونات الصوديوم",
                        descriptionAr = "تمت معاملة الخليط بكربونات الصوديوم وفصل الراشح والراسب"
                    )
                }
            }
            TestId.SEPARATE_NAOH5 -> {
                if (sample.mixtureCategory == MixtureCategory.B_PLUS_PH) {
                    ObservationResult(
                        titleAr = "فصل ناجح بـ 5% هيدروكسيد صوديوم",
                        descriptionAr = "ذاب الفينول مكوناً فينات الصوديوم في الراشح، بينما ترسبت القاعدة العضوية كراسب صلب على ورقة الترشيح",
                        conclusionClueAr = "الراسب: قاعدة عضوية | الراشح: فينولات صوديوم (يعاد ترسيبها بـ HCl)"
                    )
                } else {
                    ObservationResult(
                        titleAr = "معالجة بـ 5% NaOH",
                        descriptionAr = "تمت إذابة المكونات القابلة للتفاعل مع الصودا الكاوية وترشيح الخليط"
                    )
                }
            }
            TestId.REPRECIPITATE_ACID -> {
                ObservationResult(
                    titleAr = "إعادة ترسيب وظهور راسب أبيض ناصع",
                    descriptionAr = "عند إضافة حمض الهيدروكلوريك المركز Conc. HCl إلى الراشح، تعاد ترسيب الحمض الأروماتي / الفينول كراسب أبيض كثيف",
                    precipitate = PrecipitateColor.WHITE,
                    conclusionClueAr = "تم عزل المركب العضوي النقي بنجاح ويمكن الآن إجراء الاختبارات التأكيدية عليه"
                )
            }
            else -> evaluateSingleCompound(c1, testId)
        }
    }

    private fun evaluateSingleCompound(compound: ChemicalCompound, testId: TestId): ObservationResult {
        return when (testId) {
            TestId.HEAT_TEST -> evaluateHeatTest(compound)
            TestId.SODA_LIME_TEST -> evaluateSodaLimeTest(compound)
            TestId.NAOH_20_TEST -> evaluateNaOH20Test(compound)
            TestId.CONC_H2SO4_TEST -> evaluateConcH2SO4Test(compound)
            TestId.NITRATION_TEST -> evaluateNitrationTest(compound)
            TestId.ACIDITY_TEST -> evaluateAcidityTest(compound)
            TestId.SOLUBILITY_REPRECIPITATION -> evaluateSolubilityTest(compound)
            TestId.NEUTRAL_FECL3_TEST -> evaluateFeCl3Test(compound)
            TestId.CACL2_TEST -> evaluateCaCl2Test(compound)
            TestId.FLUORESCEIN_TEST -> evaluateFluoresceinTest(compound)
            TestId.UNSATURATION_TEST -> evaluateUnsaturationTest(compound)
            TestId.BOILING_WATER_TEST -> evaluateBoilingWaterTest(compound)
            TestId.MOLISCH_TEST -> evaluateMolischTest(compound)
            TestId.BARFOED_TEST -> evaluateBarfoedTest(compound)
            TestId.FEHLING_TEST -> evaluateFehlingTest(compound)
            TestId.RAPID_FURFURAL_TEST -> evaluateRapidFurfuralTest(compound)
            TestId.IODINE_TEST -> evaluateIodineTest(compound)
            TestId.AZO_DYE_TEST -> evaluateAzoDyeTest(compound)
            TestId.METALLIC_RESIDUE_TEST -> evaluateMetallicResidueTest(compound)
            TestId.BIURET_UREA_TEST -> evaluateBiuretTest(compound)
            TestId.SEPARATE_WATER,
            TestId.SEPARATE_NA2CO3,
            TestId.SEPARATE_NAOH5,
            TestId.REPRECIPITATE_ACID -> ObservationResult(
                titleAr = "عينة نقية",
                descriptionAr = "المادة نقية وغير مختلطة، يمكن إجراء الاختبارات النوعية مباشرة عليها"
            )
        }
    }

    // 1. Heat Test (إختبار الحرارة)
    private fun evaluateHeatTest(compound: ChemicalCompound): ObservationResult {
        return when {
            compound == CompoundCatalog.UREA -> ObservationResult(
                titleAr = "إنصهار وتحول لراسب أبيض وتصاعد نشادر",
                descriptionAr = "تتحول اليوريا بالحرارة إلى راسب أبيض من البيوريت (مش أسود) مع تصاعد غاز النشادر",
                melting = true,
                gasBubbles = true,
                odor = OdorType.AMMONIA,
                conclusionClueAr = "خاص باليوريا (التحول لأبيض وتصاعد نشادر)"
            )
            compound.isSugar -> ObservationResult(
                titleAr = "إنصهار وأسوداد وانتفاخ ثم تفحم مع رائحة السكر المحروق",
                descriptionAr = "تذوب المادة وتنتفخ بشدة وتتفحم متحولة لكتلة كربونية سوداء مع رائحة كراميل محروق نفاذة",
                melting = true,
                swelling = true,
                charring = true,
                visualColorHex = 0xFF0F172A,
                odor = OdorType.BURNT_SUGAR,
                conclusionClueAr = "دليل قاطع على السكريات (كربوهيدرات)"
            )
            compound == CompoundCatalog.STARCH || compound == CompoundCatalog.TARTARIC_ACID || compound == CompoundCatalog.CITRIC_ACID ||
            compound == CompoundCatalog.SODIUM_TARTRATE || compound == CompoundCatalog.SODIUM_CITRATE ||
            compound == CompoundCatalog.AMMONIUM_TARTRATE || compound == CompoundCatalog.AMMONIUM_CITRATE -> ObservationResult(
                titleAr = "تفحم بدون إنصهار مع رائحة السكر المحروق",
                descriptionAr = "تتفحم المادة مباشرة دون أن تنصهر مع انبعاث رائحة السكر المحروق",
                charring = true,
                melting = false,
                visualColorHex = 0xFF1E293B,
                odor = OdorType.BURNT_SUGAR,
                conclusionClueAr = "دليل على نشا أو حمض طرطريك أو حمض ستريك أو أملاحهم"
            )
            compound.isSalt -> ObservationResult(
                titleAr = "بقايا معدنية رمادية/بيضاء",
                descriptionAr = "المادة تترك بقايا رمادية غير قابلة للاحتراق الكامل",
                charring = false,
                visualColorHex = 0xFF94A3B8,
                conclusionClueAr = "دليل على أملاح لمركبات عضوية أو أملاح أحماض"
            )
            compound.isAromatic || compound == CompoundCatalog.CHLORAL_HYDRATE -> ObservationResult(
                titleAr = "إحتراق مع لهب مدخن",
                descriptionAr = "المادة تشتعل مصحوبة بدخان أسود وسناج كثيف",
                hasFlame = true,
                isSmokyFlame = true,
                visualColorHex = 0xFF334155,
                conclusionClueAr = "مركبات أروماتية أو هيدرات الكلورال"
            )
            else -> ObservationResult(
                titleAr = "إحتراق بدون لهب مدخن",
                descriptionAr = "المادة تحترق بهدوء بلهب نظيف غير مدخن",
                hasFlame = true,
                isSmokyFlame = false,
                visualColorHex = 0xFF64748B,
                conclusionClueAr = "مركبات أليفاتية"
            )
        }
    }

    // 2. Soda Lime Test (التسخين مع الجير الصودي)
    private fun evaluateSodaLimeTest(compound: ChemicalCompound): ObservationResult {
        return when {
            compound == CompoundCatalog.CHLORAL_HYDRATE -> ObservationResult(
                titleAr = "تصاعد رائحة الكلوروفورم",
                descriptionAr = "تصاعد رائحة الكلوروفورم المميزة الشبيهة برائحة التخدير",
                odor = OdorType.CHLOROFORM,
                conclusionClueAr = "هيدرات الكلورال"
            )
            compound == CompoundCatalog.UREA || compound.category == CompoundCategory.AMMONIUM_SALT -> ObservationResult(
                titleAr = "تصاعد رائحة النشادر النفاذة",
                descriptionAr = "تصاعد غاز النشادر النفاذ بكثافة الذي يزرق ورقة عباد الشمس الحمراء المبللة",
                gasBubbles = true,
                odor = OdorType.AMMONIA,
                conclusionClueAr = "أملاح أمونيوم، أميدات، يوريا"
            )
            compound.isPhenolic || compound == CompoundCatalog.SALICYLIC_ACID || compound == CompoundCatalog.SODIUM_SALICYLATE -> ObservationResult(
                titleAr = "تصاعد رائحة الفينول المميزة",
                descriptionAr = "تصاعد أبخرة ذات رائحة الفينول النفاذة (الكربوليك)",
                odor = OdorType.PHENOL,
                conclusionClueAr = "أحماض فينولية أو فينيل استر لأحماض كربوكسيلية"
            )
            compound.isSugar || compound == CompoundCatalog.TARTARIC_ACID || compound == CompoundCatalog.CITRIC_ACID ||
            compound == CompoundCatalog.SODIUM_TARTRATE || compound == CompoundCatalog.SODIUM_CITRATE -> ObservationResult(
                titleAr = "تصاعد رائحة السكر المحترق",
                descriptionAr = "تصاعد رائحة كراميلية مميزة",
                odor = OdorType.BURNT_SUGAR,
                conclusionClueAr = "سكريات أو بعض الأحماض الهيدروكسيلية الأليفاتية وأملاحهم"
            )
            compound.isAmine -> ObservationResult(
                titleAr = "تصاعد رائحة أمينات أروماتية",
                descriptionAr = "تصاعد رائحة أمينية سمكية قوية",
                odor = OdorType.AROMATIC_AMINE,
                conclusionClueAr = "أملاح أمينات، أنيليدات، أحماض أمينية أروماتية"
            )
            compound.isAromatic -> ObservationResult(
                titleAr = "تصاعد رائحة البنزين العطرية",
                descriptionAr = "تصاعد رائحة البنزين المميزة نتيجة نزع الكربوكسيل",
                odor = OdorType.BENZENE,
                conclusionClueAr = "أحماض أروماتية أو أملاحها"
            )
            else -> ObservationResult(
                titleAr = "بدون رائحة مميزة واضحة",
                descriptionAr = "لا تنبعث روائح نوعية قاطعة",
                odor = OdorType.NONE
            )
        }
    }

    // 3. NaOH 20% Treatment (المعالجة بهيدروكسيد الصوديوم 20%)
    private fun evaluateNaOH20Test(compound: ChemicalCompound): ObservationResult {
        return when {
            compound.category == CompoundCategory.AMMONIUM_SALT -> ObservationResult(
                titleAr = "تصاعد رائحة النشادر على البارد",
                descriptionAr = "انبعاث رائحة غاز النشادر فوراً بمجرد إضافة القلوي على البارد دون الحاجة لتسخين",
                gasBubbles = true,
                odor = OdorType.AMMONIA,
                conclusionClueAr = "ملح أمونيومي لحمض"
            )
            compound == CompoundCatalog.UREA -> ObservationResult(
                titleAr = "تصاعد رائحة النشادر بالتسخين",
                descriptionAr = "تصاعد رائحة غاز النشادر فقط عند تسخين الأنبوبة",
                gasBubbles = true,
                odor = OdorType.AMMONIA,
                conclusionClueAr = "أميدات، إيميدات، نيترات، يوريا"
            )
            compound == CompoundCatalog.CHLORAL_HYDRATE -> ObservationResult(
                titleAr = "ظهور كلوروفورم على هيئة زيت",
                descriptionAr = "تكون طبقة زيتية منفصلة من الكلوروفورم برائحتها المميزة",
                oilyDroplets = true,
                odor = OdorType.CHLOROFORM,
                conclusionClueAr = "كلورال أو هيدرات كلورال"
            )
            compound == CompoundCatalog.CATECHOL || compound == CompoundCatalog.HYDROQUINONE || compound == CompoundCatalog.PYROGALLOL -> ObservationResult(
                titleAr = "عند تركها لفترة يصبح لونها داكناً",
                descriptionAr = "يتأكسد المحلول القلوي بالهواء ويتحول من اللون الفاتح إلى لون بني داكن/أسود",
                visualColorHex = 0xFF451A03,
                conclusionClueAr = "بعض الفينولات متعددة الهيدروكسيل، بنزوكينون، أمينوفينول"
            )
            compound.isSugar -> ObservationResult(
                titleAr = "يتحول اللون من أصفر إلى بني بالتسخين",
                descriptionAr = "تتلون الأنبوبة باللون الأصفر ثم تتحول إلى اللون البني المحروق مع التسخين (كرملة)",
                visualColorHex = 0xFF78350F,
                conclusionClueAr = "سكريات"
            )
            compound.isAmine -> ObservationResult(
                titleAr = "قطرات زيتية أو راسب",
                descriptionAr = "ظهور قطرات زيتية طافية أو راسب على البارد",
                oilyDroplets = true,
                conclusionClueAr = "أملاح أمينات أروماتية أو أليفاتية"
            )
            (compound.isAromatic && compound.isAcidic) || (compound.isPhenolic && !compound.waterSoluble) -> ObservationResult(
                titleAr = "تذوب المادة على البارد ولكن لا تذوب في الماء",
                descriptionAr = "تذوب البلورات تماماً في محلول 20% NaOH على البارد مكونة ملح الصوديوم الذائب",
                visualColorHex = 0xFFF8FAFC,
                conclusionClueAr = "بعض الأحماض الأروماتية أو فينولات لا تذوب في الماء"
            )
            else -> ObservationResult(
                titleAr = "محلول رائق دون تغير ملحوظ",
                descriptionAr = "ذوبان عادي دون تفاعل لوني مميز"
            )
        }
    }

    // 4. Concentrated H2SO4 Test (المعالجة بحمض الكبريتيك المركز)
    private fun evaluateConcH2SO4Test(compound: ChemicalCompound): ObservationResult {
        return when {
            compound.isSugar || compound == CompoundCatalog.TARTARIC_ACID || compound == CompoundCatalog.SODIUM_TARTRATE || compound == CompoundCatalog.AMMONIUM_TARTRATE -> ObservationResult(
                titleAr = "تفحم سريع مع فوران (تصاعد CO, CO₂)",
                descriptionAr = "اسوداد فوري وتفحم شديد مع فوران وتصاعد غازات CO و CO₂",
                charring = true,
                gasBubbles = true,
                visualColorHex = 0xFF0F172A,
                conclusionClueAr = "سكريات أو لاكتات أو طرطرات (فوران مع اسوداد = طرطريك)"
            )
            compound == CompoundCatalog.CITRIC_ACID || compound == CompoundCatalog.SODIUM_CITRATE || compound == CompoundCatalog.AMMONIUM_CITRATE -> ObservationResult(
                titleAr = "تصاعد CO, CO₂ بدون تفحم ويصبح الخليط لونه أصفر",
                descriptionAr = "فوران وتصاعد غازات دون اسوداد أو تفحم مع تحول لون السائل إلى اللون الأصفر",
                gasBubbles = true,
                charring = false,
                visualColorHex = 0xFFFACC15,
                conclusionClueAr = "حمض الستريك وأملاحه (فوران ولون أصفر = ستريك)"
            )
            compound == CompoundCatalog.OXALIC_ACID || compound == CompoundCatalog.SODIUM_OXALATE || compound == CompoundCatalog.AMMONIUM_OXALATE -> ObservationResult(
                titleAr = "تصاعد CO, CO₂ ولكن بدون إسوداد وبدون تفحم",
                descriptionAr = "فوران نشط وتصاعد غازات أول وثاني أكسيد الكربون مع بقاء المحلول رائقاً دون أي اسوداد",
                gasBubbles = true,
                charring = false,
                visualColorHex = 0xFFF8FAFC,
                conclusionClueAr = "أوكسالات (فوران بدون اسوداد = أوكسالات)"
            )
            compound.isPhenolic -> ObservationResult(
                titleAr = "أبخرة سوداء ولكن بدون فوران",
                descriptionAr = "تصاعد أبخرة داكنة وسوداء دون حدوث فوران غازي",
                charring = true,
                gasBubbles = false,
                visualColorHex = 0xFF1E293B,
                conclusionClueAr = "فينولات"
            )
            compound.isAcidic -> ObservationResult(
                titleAr = "تصاعد أبخرة ذات رائحة خانقة ولكن بدون فوران وبدون اسوداد",
                descriptionAr = "تصاعد أبخرة حامضية بيضاء نفاذة برائحة خانقة دون تفحم المحلول",
                gasBubbles = false,
                charring = false,
                odor = OdorType.PUNGENT_ACID,
                conclusionClueAr = "أحماض كربوكسيلية وأملاحها"
            )
            else -> ObservationResult(
                titleAr = "لا يحدث تغير نوعي",
                descriptionAr = "عدم حدوث تفحم أو فوران واضح"
            )
        }
    }

    // 5. Nitration Test (اختبار النيترة)
    private fun evaluateNitrationTest(compound: ChemicalCompound): ObservationResult {
        return if (compound.isAromatic) {
            ObservationResult(
                titleAr = "إيجابي (+Ve): لون أصفر - برتقالي - أحمر - راسب - قطرات زيتية",
                descriptionAr = "عند صب محتويات الأنبوبة في الماء يظهر لون أصفر/برتقالي زاهٍ مع تكون راسب أو قطرات زيتية كثيفة لمشتقات النيترو",
                visualColorHex = 0xFFEA580C,
                precipitate = PrecipitateColor.YELLOW,
                oilyDroplets = true,
                conclusionClueAr = "مركبات أروماتية (+Ve)"
            )
        } else {
            ObservationResult(
                titleAr = "سالب (-Ve): لا يتكون راسب أو لون",
                descriptionAr = "المحلول يظل شفافاً وعديم اللون عند الصب في الماء دون أي تغير",
                visualColorHex = 0xFFF8FAFC,
                conclusionClueAr = "مركبات أليفاتية (-Ve)"
            )
        }
    }

    // 6. Acidity Test (اختبار الحموضة)
    private fun evaluateAcidityTest(compound: ChemicalCompound): ObservationResult {
        return if (compound.isAcidic || compound == CompoundCatalog.UREA) {
            ObservationResult(
                titleAr = "فوران مع تصاعد غاز CO₂",
                descriptionAr = "فوران فوري وتصاعد فقاعات غاز ثاني أكسيد الكربون بغزارة يعكر ماء الجير الرائق",
                gasBubbles = true,
                conclusionClueAr = "أحماض كربوكسيلية، أملاح أنيلين، أملاح يوريا، حمض سلفونيك"
            )
        } else {
            ObservationResult(
                titleAr = "سالب (-Ve)",
                descriptionAr = "لا يحدث أي فوران أو تصاعد للغاز",
                gasBubbles = false,
                conclusionClueAr = "ليست مركبات حمضية كربوكسيلية"
            )
        }
    }

    // 7. Solubility & Reprecipitation (الذوبانية وإعادة الترسيب)
    private fun evaluateSolubilityTest(compound: ChemicalCompound): ObservationResult {
        return when {
            compound.isAromatic && compound.isAcidic -> ObservationResult(
                titleAr = "يذاب في 5% Na₂CO₃ ويعاد ترسيبه بإضافة HCl مخفف",
                descriptionAr = "المادة لا تذوب في الماء، ولكنها تذوب في 5% كربونات صوديوم، وعند تحميض المحلول بحمض الهيدروكلوريك المخفف يترسب فوراً راسب أبيض ناصع",
                precipitate = PrecipitateColor.WHITE,
                conclusionClueAr = "أحماض أروماتية كربوكسيلية"
            )
            compound.isPhenolic && !compound.waterSoluble -> ObservationResult(
                titleAr = "يذوب في 5% NaOH ولا يذوب في Na₂CO₃ والماء ويعاد ترسيبه بـ HCl",
                descriptionAr = "يذوب في محلول الصودا الكاوية 5% ولا يذوب في الكربونات أو الماء، ويعاد ترسيبه كراسب بإضافة HCl مخفف",
                precipitate = PrecipitateColor.WHITE,
                conclusionClueAr = "فينولات غير ذائبة في الماء (مثل ألفا وبيتا نافثول)"
            )
            compound.isAmine -> ObservationResult(
                titleAr = "يذوب في HCl المخفف ولا يذوب في الماء ويعاد ترسيبه بواسطة NaOH",
                descriptionAr = "المادة كقاعدة عضوية تذوب في حمض الهيدروكلوريك المخفف ولا تذوب في الماء، وتترسب كزيت أو راسب عند إضافة القلوي NaOH",
                oilyDroplets = true,
                conclusionClueAr = "قواعد عضوية (أمينات أروماتية)"
            )
            else -> ObservationResult(
                titleAr = "ذوبانية عامة في الماء",
                descriptionAr = "المادة تذوب مباشرة في الماء العادي"
            )
        }
    }

    // 8. Neutral FeCl3 Test (المعالجة بمحلول كلوريد الحديديك المتعادل)
    private fun evaluateFeCl3Test(compound: ChemicalCompound): ObservationResult {
        return when (compound) {
            CompoundCatalog.SALICYLIC_ACID, CompoundCatalog.SODIUM_SALICYLATE, CompoundCatalog.AMMONIUM_SALICYLATE -> ObservationResult(
                titleAr = "لون بنفسجي قاطم شديد (Dark Violet)",
                descriptionAr = "ظهور لون بنفسجي غني وثابت بمجرد إضافة قطرات كلوريد الحديديك المتعادل",
                visualColorHex = 0xFF6B21A8,
                conclusionClueAr = "حمض الساليسيليك أو سلسلات (يعطي اختبار الحموضة واختبار الأسترة ولون بنفسجي)"
            )
            CompoundCatalog.BENZOIC_ACID, CompoundCatalog.SODIUM_BENZOATE, CompoundCatalog.AMMONIUM_BENZOATE,
            CompoundCatalog.PHTHALIC_ACID, CompoundCatalog.SODIUM_PHTHALATE, CompoundCatalog.AMMONIUM_PHTHALATE,
            CompoundCatalog.CINNAMIC_ACID, CompoundCatalog.PHENYLACETIC_ACID -> ObservationResult(
                titleAr = "راسب لحمي بني فاتح (Buff / Fleshy Precipitate)",
                descriptionAr = "تكون راسب لحمي مميز بلون بني فاتح / بيج معلق في المحلول",
                visualColorHex = 0xFFD97706,
                precipitate = PrecipitateColor.FLESHY_BUFF,
                conclusionClueAr = "حمض البنزويك، الفيثاليك، السيناميك، فينيل أسيتيك وأملاحهم"
            )
            CompoundCatalog.PHENOL -> ObservationResult(
                titleAr = "لون بنفسجي يختفي بإضافة HCl",
                descriptionAr = "ظهور لون بنفسجي زاهٍ يزول ويختفي تماماً عند إضافة بضع قطرات من حمض الهيدروكلوريك المخفف",
                visualColorHex = 0xFF7C3AED,
                conclusionClueAr = "فينول (Phenol)"
            )
            CompoundCatalog.RESORCINOL -> ObservationResult(
                titleAr = "لون بنفسجي يختفي بإضافة خلات الصوديوم",
                descriptionAr = "ظهور لون بنفسجي يختفي ويزول عند إضافة بلورات خلات الصوديوم",
                visualColorHex = 0xFF8B5CF6,
                conclusionClueAr = "ريزورسينول (Resorcinol)"
            )
            CompoundCatalog.CATECHOL -> ObservationResult(
                titleAr = "لون أخضر يتحول إلى أحمر بإضافة NaOH",
                descriptionAr = "ظهور لون أخضر مميز يتحول إلى اللون الأحمر القاني بمجرد إضافة قطرات من هيدروكسيد الصوديوم",
                visualColorHex = 0xFF059669,
                conclusionClueAr = "كاتيكول (Catechol)"
            )
            CompoundCatalog.HYDROQUINONE -> ObservationResult(
                titleAr = "بلورات خضراء (كين هيدرون) / يعطي لون أحمر يتحول لأخضر مع ماء البروم",
                descriptionAr = "ترسب بلورات خضراء لامعة ذات بريق معدني من الكين هيدرون",
                visualColorHex = 0xFF10B981,
                precipitate = PrecipitateColor.GREEN_CRYSTALS,
                conclusionClueAr = "هيدروكينون (كينول)"
            )
            CompoundCatalog.PYROGALLOL -> ObservationResult(
                titleAr = "لون محمر يتحول إلى بنفسجي بإضافة NaOH (يزيل لون ماء البروم)",
                descriptionAr = "ظهور لون بني محمر يتحول إلى بنفسجي داكن بإضافة القلوي",
                visualColorHex = 0xFFB91C1C,
                conclusionClueAr = "بيروجالول (Pyrogallol)"
            )
            CompoundCatalog.ALPHA_NAPHTHOL -> ObservationResult(
                titleAr = "لون مخضر يتحول إلى بنفسجي بزيادة محلول كلوريد الحديديك",
                descriptionAr = "ظهور لون مخضر يتحول تدريجياً إلى بنفسجي عند إضافة المزيد من كاشف FeCl₃",
                visualColorHex = 0xFF4D7C0F,
                conclusionClueAr = "ألفا-نافثول (يعطي في اختبار الدستزة مع الأنيلين صبغة بنية)"
            )
            CompoundCatalog.BETA_NAPHTHOL -> ObservationResult(
                titleAr = "لون أخضر باهت",
                descriptionAr = "ظهور لون أخضر باهت خفيف دون تكون راسب ملون معقد",
                visualColorHex = 0xFFA7F3D0,
                conclusionClueAr = "بيتا-نافثول"
            )
            CompoundCatalog.ALPHA_NAPHTHYLAMINE -> ObservationResult(
                titleAr = "لون أزرق",
                descriptionAr = "ظهور لون أزرق مميز في الوسط الحامضي المخفف",
                visualColorHex = 0xFF2563EB,
                conclusionClueAr = "ألفا-نافثيل أمين"
            )
            CompoundCatalog.OXALIC_ACID, CompoundCatalog.SODIUM_OXALATE, CompoundCatalog.AMMONIUM_OXALATE,
            CompoundCatalog.TARTARIC_ACID, CompoundCatalog.SODIUM_TARTRATE, CompoundCatalog.AMMONIUM_TARTRATE,
            CompoundCatalog.CITRIC_ACID, CompoundCatalog.SODIUM_CITRATE, CompoundCatalog.AMMONIUM_CITRATE -> ObservationResult(
                titleAr = "راسب أصفر باهت / سالب (-Ve)",
                descriptionAr = "محلول أصفر باهت لكلوريد الحديديك دون لون نوعي بنفسجي أو راسب لحمي",
                visualColorHex = 0xFFFEF08A,
                conclusionClueAr = "أحماض أليفاتية (سالب مع FeCl₃)"
            )
            else -> ObservationResult(
                titleAr = "سالب (-Ve) لا يعطي لوناً مميزاً",
                descriptionAr = "لا يتكون أي معقد ملون أو راسب",
                visualColorHex = 0xFFFDF08A
            )
        }
    }

    // 9. CaCl2 Timing Test (اختبار كلوريد الكالسيوم بالتوقيت)
    private fun evaluateCaCl2Test(compound: ChemicalCompound): ObservationResult {
        return when (compound) {
            CompoundCatalog.OXALIC_ACID, CompoundCatalog.SODIUM_OXALATE, CompoundCatalog.AMMONIUM_OXALATE -> ObservationResult(
                titleAr = "راسب أبيض في الحال (على الفور)",
                descriptionAr = "تكون راسب أبيض ناصع من أوكسالات الكالسيوم فوراً بمجرد إضافة CaCl₂ على البارد دون رج أو تدفئة",
                precipitate = PrecipitateColor.WHITE,
                timingNoteAr = "الترسيب فوري على الفور",
                conclusionClueAr = "حمض الأوكساليك / أوكسالات (راسب أبيض في الحال)"
            )
            CompoundCatalog.TARTARIC_ACID, CompoundCatalog.SODIUM_TARTRATE, CompoundCatalog.AMMONIUM_TARTRATE -> ObservationResult(
                titleAr = "راسب أبيض بعد الرج أو التدفئة",
                descriptionAr = "المحلول يظل رائقاً في البداية، وبمجرد رج الأنبوبة بقوة أو تدفئتها الخفيفة يتكون راسب أبيض من طرطرات الكالسيوم",
                precipitate = PrecipitateColor.WHITE,
                timingNoteAr = "الترسيب بعد الرج أو التدفئة",
                conclusionClueAr = "حمض الطرطريك / طرطرات (راسب أبيض بعد الرج أو التدفئة)"
            )
            CompoundCatalog.CITRIC_ACID, CompoundCatalog.SODIUM_CITRATE, CompoundCatalog.AMMONIUM_CITRATE -> ObservationResult(
                titleAr = "راسب أبيض بعد الغليان",
                descriptionAr = "لا يتكون أي راسب على البارد أو بعد الرج، ولكن عند تسخين الأنبوبة لدرجة الغليان يتكون راسب أبيض كثيف من سترات الكالسيوم",
                precipitate = PrecipitateColor.WHITE,
                timingNoteAr = "الترسيب بعد الغليان فقط",
                conclusionClueAr = "حمض الستريك / سترات (راسب أبيض بعد الغليان)"
            )
            else -> ObservationResult(
                titleAr = "سالب (-Ve)",
                descriptionAr = "لا يتكون أي راسب أبيض مع كلوريد الكالسيوم حتى بعد الغليان",
                conclusionClueAr = "ليس من فئة الأوكسالات أو الطرطرات أو السترات"
            )
        }
    }

    // 10. Fluorescein Test (اختبار الفلوروسين)
    private fun evaluateFluoresceinTest(compound: ChemicalCompound): ObservationResult {
        return if (compound == CompoundCatalog.PHTHALIC_ACID || compound == CompoundCatalog.SODIUM_PHTHALATE || compound == CompoundCatalog.AMMONIUM_PHTHALATE) {
            ObservationResult(
                titleAr = "لون أخضر فلوروسيني متوهج لامع (Green Fluorescein)",
                descriptionAr = "عند صهر المادة مع الريزورسينول وقطرتين H₂SO₄ والتسخين الشديد ثم الصب في بيكر به NaOH، يظهر توهج فلوروسيني أخضر فاقع ومبهر في المحلول القلوي",
                fluoresceinGlow = true,
                visualColorHex = 0xFF10B981,
                conclusionClueAr = "حمض الفيثاليك أو فيثالات (+Ve Fluorescein)"
            )
        } else {
            ObservationResult(
                titleAr = "سالب (-Ve) لا يعطي توهجاً فلوروسينياً",
                descriptionAr = "المحلول لا يعطي أي توهج فلوروسيني أخضر",
                fluoresceinGlow = false,
                conclusionClueAr = "ليس حمض الفيثاليك"
            )
        }
    }

    // 11. Unsaturation Test (اختبار عدم التشبع)
    private fun evaluateUnsaturationTest(compound: ChemicalCompound): ObservationResult {
        return if (compound == CompoundCatalog.CINNAMIC_ACID) {
            ObservationResult(
                titleAr = "يزيل لون ماء البروم / يتغير لونه مع كاشف دنجز (+Ve)",
                descriptionAr = "اختفاء فوري للون ماء البروم البرتقالي دلالة على وجود الرابطة الثنائية غير المشبعة",
                visualColorHex = 0xFFF8FAFC,
                conclusionClueAr = "حمض السيناميك (Cinnamic Acid)"
            )
        } else {
            ObservationResult(
                titleAr = "سالب (-Ve) لا يزيل لون ماء البروم",
                descriptionAr = "يبقى لون ماء البروم البرتقالي ثابتاً دون زوال",
                visualColorHex = 0xFFEA580C,
                conclusionClueAr = "مركب مشبع (ليس سيناميك)"
            )
        }
    }

    // 12. Boiling Water Test (الغليان مع الماء)
    private fun evaluateBoilingWaterTest(compound: ChemicalCompound): ObservationResult {
        return when (compound) {
            CompoundCatalog.PHENYLACETIC_ACID -> ObservationResult(
                titleAr = "تصاعد رائحة نفاذة مميزة لحمض فينيل أسيتيك",
                descriptionAr = "انبعاث رائحة مميزة قوية ونفاذة عند غلي المحلول مع الماء",
                odor = OdorType.PUNGENT_ACID,
                conclusionClueAr = "حمض فينيل أسيتيك (Phenylacetic Acid)"
            )
            CompoundCatalog.P_TOLUIDINE, CompoundCatalog.ALPHA_NAPHTHYLAMINE -> ObservationResult(
                titleAr = "ظهور قطرات زيتية طافية على السطح",
                descriptionAr = "تتجمع المادة على هيئة قطرات زيتية سائلة طافية فوق سطح الماء المغلي",
                oilyDroplets = true,
                conclusionClueAr = "بارا-تولويدين أو ألفا-نافثيل أمين"
            )
            CompoundCatalog.BETA_NAPHTHYLAMINE -> ObservationResult(
                titleAr = "سالب (-Ve) لا يعطي قطرات زيتية",
                descriptionAr = "لا تظهر أي قطرات زيتية عند الغليان مع الماء",
                conclusionClueAr = "بيتا-نافثيل أمين"
            )
            else -> ObservationResult(
                titleAr = "لا يحدث تغير مميز",
                descriptionAr = "المادة تذوب أو تبقى معلقة دون قطرات زيتية أو روائح نوعية"
            )
        }
    }

    // 13. Molisch Test (كشف السكريات)
    private fun evaluateMolischTest(compound: ChemicalCompound): ObservationResult {
        return if (compound.isSugar) {
            ObservationResult(
                titleAr = "حلقة حمراء بنفسجية تنتشر بالرج (Red-Purple Ring)",
                descriptionAr = "تكون حلقة بنفسجية محمرة واضحة عند السطح الفاصل بين الطبقتين، وتنتشر في المحلول بالكامل عند الرج",
                purpleRing = true,
                visualColorHex = 0xFF7C3AED,
                conclusionClueAr = "دليل قاطع على السكريات (كربوهيدرات)"
            )
        } else {
            ObservationResult(
                titleAr = "سالب (-Ve)",
                descriptionAr = "لا تتكون أي حلقة بنفسجية على السطح الفاصل",
                purpleRing = false,
                conclusionClueAr = "ليس من السكريات"
            )
        }
    }

    // 14. Barfoed Test (كاشف بارافويد بالتوقيت)
    private fun evaluateBarfoedTest(compound: ChemicalCompound): ObservationResult {
        return when (compound) {
            CompoundCatalog.GLUCOSE, CompoundCatalog.FRUCTOSE, CompoundCatalog.GALACTOSE -> ObservationResult(
                titleAr = "راسب أحمر على جدار الأنبوبة خلال 1 - 2 دقيقة",
                descriptionAr = "ظهور راسب أحمر طوبي رقيق يلتصق بجدار الأنبوبة الزجاجية بسرعة في غضون دقيقة إلى دقيقتين من الغليان في الحمام المائي",
                precipitate = PrecipitateColor.RED_COPPER,
                timingNoteAr = "الترسيب خلال 1 - 2 دقيقة",
                conclusionClueAr = "سكر أحادي (Monosaccharide: جلوكوز، فركتوز، جلاكتوز)"
            )
            CompoundCatalog.SUCROSE, CompoundCatalog.MALTOSE, CompoundCatalog.LACTOSE -> ObservationResult(
                titleAr = "راسب أحمر بعد أكثر من دقيقتين (Delayed > 2 min)",
                descriptionAr = "لا يظهر أي راسب خلال أول دقيقتين، ويتكون الراسب الأحمر فقط بعد استمرار الغليان لأكثر من دقيقتين",
                precipitate = PrecipitateColor.RED_COPPER,
                timingNoteAr = "الترسيب بعد أكثر من دقيقتين",
                conclusionClueAr = "سكر ثنائي (Disaccharide: سكروز، مالتوز، لاكتوز)"
            )
            else -> ObservationResult(
                titleAr = "سالب (-Ve) لا يتكون راسب أحمر",
                descriptionAr = "عدم تكون أي راسب أحمر على جدار الأنبوبة",
                conclusionClueAr = "سكريات عديدة (نشا) أو غير ذلك"
            )
        }
    }

    // 15. Fehling Test (كاشف فهلنج)
    private fun evaluateFehlingTest(compound: ChemicalCompound): ObservationResult {
        return when (compound) {
            CompoundCatalog.GLUCOSE, CompoundCatalog.FRUCTOSE, CompoundCatalog.MALTOSE, CompoundCatalog.LACTOSE, CompoundCatalog.GALACTOSE -> ObservationResult(
                titleAr = "راسب أصفر محمر من أكسيد النحاسوز (Cu₂O)",
                descriptionAr = "اختزال فهلنج وتحول اللون الأزرق إلى راسب كثيف أحمر طوبي/أصفر محمر",
                precipitate = PrecipitateColor.RED_COPPER,
                visualColorHex = 0xFFDC2626,
                conclusionClueAr = "سكريات مختزلة (أحادية وثنائية ما عدا السكروز)"
            )
            CompoundCatalog.SUCROSE -> ObservationResult(
                titleAr = "سالب (-Ve) لا يتكون راسب أحمر",
                descriptionAr = "يبقى المحلول أزرق رائقاً دون اختزال أو تكون راسب أحمر",
                visualColorHex = 0xFF0284C7,
                conclusionClueAr = "سكريات غير مختزلة (سكروز)"
            )
            else -> ObservationResult(
                titleAr = "سالب (-Ve)",
                descriptionAr = "يبقى لون محلول فهلنج أزرق رائقاً دون تكون راسب",
                visualColorHex = 0xFF0284C7
            )
        }
    }

    // 16. Rapid Furfural Test (الفورفورال السريع)
    private fun evaluateRapidFurfuralTest(compound: ChemicalCompound): ObservationResult {
        return when (compound) {
            CompoundCatalog.FRUCTOSE, CompoundCatalog.SUCROSE -> ObservationResult(
                titleAr = "لون بنفسجي في الحال (على الفور)",
                descriptionAr = "ظهور لون بنفسجي عميق فوراً بمجرد الغليان مع حمض HCl وألفا-نافثول",
                visualColorHex = 0xFF7C3AED,
                timingNoteAr = "ظهور فوري في الحال",
                conclusionClueAr = "فركتوز أو سكروز (Fructose or Sucrose)"
            )
            CompoundCatalog.GLUCOSE, CompoundCatalog.MALTOSE, CompoundCatalog.LACTOSE -> ObservationResult(
                titleAr = "لون بنفسجي بعد فترة وتسخين مستمر",
                descriptionAr = "يتأخر ظهور اللون البنفسجي ولا يتكون إلا بعد الغليان المستمر لفترة",
                visualColorHex = 0xFF8B5CF6,
                timingNoteAr = "ظهور متأخر بعد فترة",
                conclusionClueAr = "جلوكوز، مالتوز، لاكتوز"
            )
            CompoundCatalog.GALACTOSE -> ObservationResult(
                titleAr = "سالب (-Ve)",
                descriptionAr = "لا يعطي لوناً بنفسجياً",
                conclusionClueAr = "جلاكتوز (Galactose)"
            )
            else -> ObservationResult(
                titleAr = "سالب (-Ve)",
                descriptionAr = "لا يعطي تفاعل الفورفورال السريع"
            )
        }
    }

    // 17. Iodine Test (اختبار اليود للنشا)
    private fun evaluateIodineTest(compound: ChemicalCompound): ObservationResult {
        return if (compound == CompoundCatalog.STARCH) {
            ObservationResult(
                titleAr = "لون أزرق قاطم يزول عند التسخين ويعود بالتبريد",
                descriptionAr = "تكون مركب معقد بلون أزرق داكن/نيلي مميز يزول بالكامل عند تسخين الأنبوبة ويعود للظهور بمجرد تبريدها",
                visualColorHex = 0xFF1E3A8A,
                conclusionClueAr = "نشا (Starch)"
            )
        } else {
            ObservationResult(
                titleAr = "سالب (-Ve)",
                descriptionAr = "يبقى لون محلول اليود البني المصفر الخفيف دون ظهور أي لون أزرق",
                visualColorHex = 0xFFD97706,
                conclusionClueAr = "سكر أحادي أو ثنائي (ليس نشا)"
            )
        }
    }

    // 18. Azo Dye Coupling Test (صبغة الآزو)
    private fun evaluateAzoDyeTest(compound: ChemicalCompound): ObservationResult {
        return if (compound.isAmine) {
            ObservationResult(
                titleAr = "ظهور صبغة برتقالية حمراء زاهية (Azo Dye)",
                descriptionAr = "تكون فوري وسريع لصبغة آزوية قانية ذات لون برتقالي محمر كثيف ومستقر في الوسط القلوي على البارد",
                visualColorHex = 0xFFEA580C,
                precipitate = PrecipitateColor.ORANGE_RED_DYE,
                conclusionClueAr = "أمينات أروماتية أولية (+Ve Azo Dye Coupling)"
            )
        } else {
            ObservationResult(
                titleAr = "سالب (-Ve)",
                descriptionAr = "لا تتكون أي صبغة برتقالية حمراء",
                conclusionClueAr = "ليس أميناً أروماتياً أولياً"
            )
        }
    }

    // 19. Metallic Residue Test (اختبار البقايا المعدنية)
    private fun evaluateMetallicResidueTest(compound: ChemicalCompound): ObservationResult {
        return if (compound.category == CompoundCategory.SODIUM_SALT) {
            ObservationResult(
                titleAr = "فوران نشط عند إضافة HCl المخفف على البقايا",
                descriptionAr = "البقايا المعدنية البيضاء المتخلفة بعد الحرق تتفاعل بشدة وتحدث فوراناً فورياً مع حمض الهيدروكلوريك المخفف لتصاعد CO₂ من كربونات الصوديوم المتكونة",
                gasBubbles = true,
                conclusionClueAr = "أملاح صوديوم للمركبات العضوية (+Ve Sodium Salt)"
            )
        } else {
            ObservationResult(
                titleAr = "سالب (-Ve)",
                descriptionAr = "لا يحدث أي فوران مع الحمض المخفف",
                gasBubbles = false,
                conclusionClueAr = "ليست أملاح صوديوم"
            )
        }
    }

    // 20. Biuret & Urea Test (اليوريا والبيوريت)
    private fun evaluateBiuretTest(compound: ChemicalCompound): ObservationResult {
        return if (compound == CompoundCatalog.UREA) {
            ObservationResult(
                titleAr = "يتحول اللون إلى أرجواني/بنفسجي رائع (Biuret +Ve)",
                descriptionAr = "تسخين اليوريا يحولها لراسب أبيض من البيوريت مع تصاعد النشادر، وبإذابة الراسب في NaOH وإضافة قطرة من CuSO₄ يتحول المحلول إلى لون بنفسجي أرجواني خلاب",
                visualColorHex = 0xFF8B5CF6,
                gasBubbles = true,
                odor = OdorType.AMMONIA,
                conclusionClueAr = "تفاعل البيوريت المميز والخاص باليوريا"
            )
        } else {
            ObservationResult(
                titleAr = "سالب (-Ve)",
                descriptionAr = "لا يعطي تفاعل البيوريت البنفسجي",
                conclusionClueAr = "ليست يوريا"
            )
        }
    }

    /**
     * Comprehensive exam grading engine. Computes total score out of 10.
     */
    fun gradeExam(
        actualSample: ExamSample,
        studentCat: MixtureCategory,
        studentComp1: ChemicalCompound?,
        studentComp2: ChemicalCompound?,
        performedTests: List<PerformedTestRecord>,
        hintsUsedCount: Int,
        elapsedSeconds: Long
    ): ExamGradingReport {
        var comp1Score = 0f
        var comp2Score = 0f
        var separationScore = 0f
        var efficiencyScore = 2.0f
        val mistakes = mutableListOf<String>()
        val recommendations = mutableListOf<String>()

        // 1. Component 1 Identification check (Max 4.0 points)
        if (studentComp1?.id == actualSample.component1.id || studentComp1?.id == actualSample.component2?.id) {
            comp1Score = 4.0f
        } else if (studentComp1?.category == actualSample.component1.category) {
            comp1Score = 2.0f
            mistakes.add("حددت الفئة الصحيحة للمركب الأول (${studentComp1.category.titleAr}) ولكن أخطأت في تعيين المركب بالتحديد.")
        } else {
            mistakes.add("فشل في التعرف على المركب الأول: الإجابة الصحيحة هي (${actualSample.component1.nameAr}).")
        }

        // 2. Component 2 / Mixture check (Max 3.0 points)
        if (actualSample.isMixture) {
            val expectedC2 = actualSample.component2!!
            if (studentCat == actualSample.mixtureCategory) {
                separationScore += 1.0f
            } else {
                mistakes.add("تصنيف فئة الخليط غير صحيح: الفئة الفعلية هي (${actualSample.mixtureCategory.titleAr}).")
            }

            if (studentComp2?.id == expectedC2.id || (studentComp1?.id == expectedC2.id && studentComp2?.id == actualSample.component1.id)) {
                comp2Score = 2.0f
            } else if (studentComp2?.category == expectedC2.category) {
                comp2Score = 1.0f
                mistakes.add("حددت فئة المركب الثاني ولكن لم تعين المركب المحدد.")
            } else {
                mistakes.add("فشل في التعرف على المركب الثاني: الإجابة الصحيحة هي (${expectedC2.nameAr}).")
            }

            // Did student perform appropriate separation test?
            val performedSeparation = performedTests.any { it.testId.isSeparationStep }
            if (performedSeparation) {
                separationScore += 1.0f
            } else {
                mistakes.add("لم تقم بإجراء خطوة فصل وترشيح الخليط قبل الاختبارات التأكيدية.")
            }
        } else {
            // Single compound exam
            if (studentCat == MixtureCategory.SINGLE) {
                separationScore = 2.0f
            }
            if (studentComp2 != null) {
                mistakes.add("العينة مادة نقية فردية ولكنك اخترت خليطاً من مركبين.")
                comp2Score = 0f
            } else {
                comp2Score = 2.0f
            }
        }

        // 3. Efficiency and unnecessary/invalid tests penalties
        val performedIds = performedTests.map { it.testId }.toSet()
        val optimalTests = getOptimalPathForSample(actualSample)
        val optimalCount = optimalTests.size
        val actualCount = performedTests.size

        val unnecessary = performedTests.map { it.testId }.filter { it !in optimalTests }
        val missed = optimalTests.filter { it !in performedIds }

        if (actualCount > optimalCount + 5) {
            val penalty = ((actualCount - optimalCount - 5) * 0.2f).coerceAtMost(1.0f)
            efficiencyScore -= penalty
            mistakes.add("تم إجراء $actualCount اختبارات وهو أكثر من المسار القياسي المطلوب ($optimalCount اختبارات).")
        }

        // Hints penalty: 0.5 point per hint
        val hintPenalty = (hintsUsedCount * 0.5f).coerceAtMost(2.0f)
        if (hintsUsedCount > 0) {
            recommendations.add("تم خصم $hintPenalty درجات بسبب طلب $hintsUsedCount تلميحات.")
        }

        var rawTotal = comp1Score + comp2Score + separationScore + efficiencyScore - hintPenalty
        rawTotal = rawTotal.coerceIn(0.0f, 10.0f)

        if (missed.isNotEmpty()) {
            recommendations.add("الاختبارات القياسية الموصى بها لتأكيد العينة: " + missed.joinToString("، ") { it.titleAr })
        }
        recommendations.add("راجع مخطط 'البفه الكسبانة' الخاص بفئة: " + actualSample.component1.category.titleAr)

        return ExamGradingReport(
            totalScoreOutOf10 = (rawTotal * 10f).toInt() / 10f,
            component1Score = comp1Score,
            component2Score = comp2Score,
            separationScore = separationScore,
            efficiencyScore = efficiencyScore,
            penaltyForHints = hintPenalty,
            penaltyForInvalidTests = (unnecessary.size * 0.1f).coerceAtMost(1.0f),
            actualSample = actualSample,
            studentIdentifiedComp1 = studentComp1,
            studentIdentifiedComp2 = studentComp2,
            studentIdentifiedMixtureCategory = studentCat,
            performedTestsCount = actualCount,
            optimalTestsCount = optimalCount,
            correctTestsPerformed = performedTests.map { it.testId }.filter { it in optimalTests },
            unnecessaryTests = unnecessary,
            missedCriticalTests = missed,
            mistakesFeedbackAr = mistakes,
            recommendationsAr = recommendations,
            elapsedTimeSeconds = elapsedSeconds
        )
    }

    /**
     * Calculates the minimal optimal testing sequence according to "البفه الكسبانة" scheme.
     */
    fun getOptimalPathForSample(sample: ExamSample): List<TestId> {
        val list = mutableListOf<TestId>()
        list.add(TestId.HEAT_TEST)
        list.add(TestId.SODA_LIME_TEST)

        if (sample.isMixture) {
            when (sample.mixtureCategory) {
                MixtureCategory.A_PLUS_A -> {
                    list.add(TestId.SEPARATE_WATER)
                    list.add(TestId.ACIDITY_TEST)
                    list.add(TestId.CACL2_TEST)
                    list.add(TestId.NEUTRAL_FECL3_TEST)
                }
                MixtureCategory.A_PLUS_B -> {
                    list.add(TestId.SEPARATE_NA2CO3)
                    list.add(TestId.REPRECIPITATE_ACID)
                    list.add(TestId.AZO_DYE_TEST)
                    list.add(TestId.ACIDITY_TEST)
                }
                MixtureCategory.A_PLUS_PH -> {
                    list.add(TestId.SEPARATE_NA2CO3)
                    list.add(TestId.NEUTRAL_FECL3_TEST)
                    list.add(TestId.REPRECIPITATE_ACID)
                }
                MixtureCategory.B_PLUS_PH -> {
                    list.add(TestId.SEPARATE_NAOH5)
                    list.add(TestId.AZO_DYE_TEST)
                    list.add(TestId.REPRECIPITATE_ACID)
                    list.add(TestId.NEUTRAL_FECL3_TEST)
                }
                MixtureCategory.A_PLUS_N -> {
                    list.add(TestId.MOLISCH_TEST)
                    list.add(TestId.SEPARATE_NA2CO3)
                    list.add(TestId.REPRECIPITATE_ACID)
                    list.add(TestId.BARFOED_TEST)
                }
                MixtureCategory.N_PLUS_N -> {
                    list.add(TestId.MOLISCH_TEST)
                    list.add(TestId.SEPARATE_WATER)
                    list.add(TestId.IODINE_TEST)
                    list.add(TestId.FEHLING_TEST)
                }
                else -> {}
            }
            return list
        }

        val c = sample.component1
        when {
            c.isSugar -> {
                list.add(TestId.MOLISCH_TEST)
                if (c == CompoundCatalog.STARCH) {
                    list.add(TestId.IODINE_TEST)
                } else {
                    list.add(TestId.BARFOED_TEST)
                    list.add(TestId.FEHLING_TEST)
                    list.add(TestId.RAPID_FURFURAL_TEST)
                }
            }
            c == CompoundCatalog.UREA -> {
                list.add(TestId.NAOH_20_TEST)
                list.add(TestId.BIURET_UREA_TEST)
            }
            c.isAmine -> {
                list.add(TestId.SOLUBILITY_REPRECIPITATION)
                list.add(TestId.AZO_DYE_TEST)
                list.add(TestId.BOILING_WATER_TEST)
            }
            c.isPhenolic -> {
                list.add(TestId.SOLUBILITY_REPRECIPITATION)
                list.add(TestId.NEUTRAL_FECL3_TEST)
            }
            c.category == CompoundCategory.ALIPHATIC_ACID || c.category == CompoundCategory.SODIUM_SALT || c.category == CompoundCategory.AMMONIUM_SALT -> {
                list.add(TestId.ACIDITY_TEST)
                list.add(TestId.CONC_H2SO4_TEST)
                list.add(TestId.CACL2_TEST)
                if (c.category == CompoundCategory.SODIUM_SALT) {
                    list.add(TestId.METALLIC_RESIDUE_TEST)
                }
            }
            c.category == CompoundCategory.AROMATIC_ACID -> {
                list.add(TestId.NITRATION_TEST)
                list.add(TestId.ACIDITY_TEST)
                list.add(TestId.NEUTRAL_FECL3_TEST)
                if (c == CompoundCatalog.PHTHALIC_ACID) {
                    list.add(TestId.FLUORESCEIN_TEST)
                } else if (c == CompoundCatalog.CINNAMIC_ACID) {
                    list.add(TestId.UNSATURATION_TEST)
                } else if (c == CompoundCatalog.PHENYLACETIC_ACID) {
                    list.add(TestId.BOILING_WATER_TEST)
                }
            }
        }
        return list
    }

    /**
     * Multi-level contextual hints generator.
     */
    fun getHint(sample: ExamSample, performedTests: List<TestId>, level: Int): String {
        val optimal = getOptimalPathForSample(sample)
        val nextRecommended = optimal.firstOrNull { it !in performedTests } ?: optimal.first()

        return when (level) {
            1 -> {
                if (TestId.HEAT_TEST !in performedTests) {
                    "المستوى 1: ابدأ أولاً بالاختبارات المبدئية العامة (مثل إختبار الحرارة والتسخين مع الجير الصودي) لتحديد طبيعة العينة."
                } else if (sample.isMixture && performedTests.none { it.isSeparationStep }) {
                    "المستوى 1: العينة خليط من مركبين، يجب إجراء اختبارات الفرز والفصل بالترشيح قبل محاولة التعرف على المكونات المنفصلة."
                } else {
                    "المستوى 1: قم بإجراء اختبار لتحديد المجموعة الوظيفية الرئيسية (أحماض، سكريات، أمينات، فينولات)."
                }
            }
            2 -> {
                "المستوى 2: الاختبار القادم الموصى به ينتمي إلى فئة: (${nextRecommended.categoryAr})."
            }
            3 -> {
                "المستوى 3: الخطوة التالية الدقيقة هي إجراء: [${nextRecommended.titleAr}] وملاحظة النتيجة بعناية."
            }
            else -> "المستوى 1: قم باتباع مسارات مخطط 'البفه الكسبانة'."
        }
    }
}
