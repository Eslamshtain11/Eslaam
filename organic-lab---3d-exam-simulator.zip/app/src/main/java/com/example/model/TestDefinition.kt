package com.example.model

enum class TestId(
    val titleAr: String,
    val titleEn: String,
    val categoryAr: String,
    val requiredEquipment: GlasswareType,
    val requiresHeating: Boolean = false,
    val isSeparationStep: Boolean = false
) {
    HEAT_TEST("إختبار الحرارة (على الزجاجة)", "Dry Heat Test", "اختبارات عامة أولية", GlasswareType.SPATULA, true),
    SODA_LIME_TEST("التسخين مع الجير الصودي", "Soda Lime Test", "اختبارات عامة أولية", GlasswareType.TEST_TUBE, true),
    NAOH_20_TEST("المعالجة بهيدروكسيد الصوديوم 20%", "NaOH 20% Treatment", "اختبارات المجموعات الوظيفية", GlasswareType.TEST_TUBE, true),
    CONC_H2SO4_TEST("المعالجة بحمض الكبريتيك المركز", "Conc. H2SO4 Test", "اختبارات الأحماض والسكريات", GlasswareType.TEST_TUBE, true),
    NITRATION_TEST("اختبار النيترة (أروماتي / أليفاتي)", "Nitration Test", "تمييز الأروماتي والأليفاتي", GlasswareType.BEAKER, true),
    ACIDITY_TEST("اختبار الحموضة (فوران الكربونات)", "Acidity / Bicarbonate Test", "اختبارات الأحماض", GlasswareType.TEST_TUBE, false),
    SOLUBILITY_REPRECIPITATION("الذوبانية وإعادة الترسيب", "Solubility & Reprecipitation", "اختبارات الخواص والقواعد", GlasswareType.TEST_TUBE, false),
    NEUTRAL_FECL3_TEST("كلوريد الحديديك المتعادل", "Neutral FeCl3 Test", "تفرقة الأحماض والفينولات", GlasswareType.TEST_TUBE, false),
    CACL2_TEST("اختبار كلوريد الكالسيوم بالتوقيت", "CaCl2 Timing Test", "تفرقة الأحماض الأليفاتية", GlasswareType.TEST_TUBE, true),
    FLUORESCEIN_TEST("اختبار الفلوروسين (حمض الفيثاليك)", "Fluorescein Test", "تفرقة الأحماض الأروماتية", GlasswareType.BEAKER, true),
    UNSATURATION_TEST("اختبار عدم التشبع (ماء البروم)", "Unsaturation Test", "تفرقة الأحماض الأروماتية", GlasswareType.TEST_TUBE, false),
    BOILING_WATER_TEST("اختبار الغليان مع الماء", "Boiling with Water", "تفرقة الأحماض والأمينات", GlasswareType.BOILING_TUBE, true),
    MOLISCH_TEST("اختبار مولش (كشف السكريات)", "Molisch Sugar Test", "اختبارات السكريات", GlasswareType.TEST_TUBE, false),
    BARFOED_TEST("اختبار بارافويد (أحادي / ثنائي بالتوقيت)", "Barfoed Test", "اختبارات السكريات", GlasswareType.WATER_BATH, true),
    FEHLING_TEST("اختبار فهلنج (السكر المختزل)", "Fehling Test", "اختبارات السكريات", GlasswareType.WATER_BATH, true),
    RAPID_FURFURAL_TEST("اختبار الفورفورال السريع", "Rapid Furfural Test", "اختبارات السكريات", GlasswareType.BOILING_TUBE, true),
    IODINE_TEST("اختبار اليود للنشا", "Iodine Test", "اختبارات السكريات", GlasswareType.TEST_TUBE, false),
    AZO_DYE_TEST("اختبار صبغة الآزو (الدستزة للأمينات)", "Azo Dye Coupling", "اختبارات الأمينات", GlasswareType.BEAKER, false),
    METALLIC_RESIDUE_TEST("اختبار البقايا المعدنية (أملاح الصوديوم)", "Metallic Residue Test", "اختبارات الأملاح", GlasswareType.WATCH_GLASS, true),
    BIURET_UREA_TEST("تفكك اليوريا واختبار البيوريت", "Urea Decomposition & Biuret", "اختبارات خاصة", GlasswareType.TEST_TUBE, true),
    
    // Separation operations
    SEPARATE_WATER("فصل بالماء والترشيح (H2O)", "Water Separation", "عمليات الفصل والترشيح", GlasswareType.FILTER_FUNNEL, false, true),
    SEPARATE_NA2CO3("فصل بكربونات الصوديوم (Na2CO3)", "Carbonate Separation", "عمليات الفصل والترشيح", GlasswareType.FILTER_FUNNEL, false, true),
    SEPARATE_NAOH5("فصل بـ 5% هيدروكسيد صوديوم", "5% NaOH Separation", "عمليات الفصل والترشيح", GlasswareType.FILTER_FUNNEL, false, true),
    REPRECIPITATE_ACID("إعادة الترسيب بالحمض (Conc HCl)", "Acid Reprecipitation", "عمليات الفصل والترشيح", GlasswareType.BEAKER, false, true)
}

data class PerformedTestRecord(
    val id: String = java.util.UUID.randomUUID().toString(),
    val testId: TestId,
    val fraction: SampleFractionType,
    val timestampMs: Long = System.currentTimeMillis(),
    val observation: ObservationResult,
    val reagentsUsed: List<ReagentType> = emptyList(),
    val wasHeated: Boolean = false,
    val deductionUserNote: String = ""
)

enum class ExamMode(val titleAr: String, val descAr: String) {
    TRAINING("وضع التدريب والشرح", "تلميحات غير محدودة، كشف فوري للتعليلات الكيميائية، وممارسة حرة"),
    STRICT_EXAM("وضع الامتحان الرسمي", "عينة مجهولة، توقيت، تسجيل في كشكول المعمل، تقييم كامل من 10 درجات")
}

data class ExamGradingReport(
    val totalScoreOutOf10: Float,
    val component1Score: Float,
    val component2Score: Float,
    val separationScore: Float,
    val efficiencyScore: Float,
    val penaltyForHints: Float,
    val penaltyForInvalidTests: Float,
    val actualSample: ExamSample,
    val studentIdentifiedComp1: ChemicalCompound?,
    val studentIdentifiedComp2: ChemicalCompound?,
    val studentIdentifiedMixtureCategory: MixtureCategory,
    val performedTestsCount: Int,
    val optimalTestsCount: Int,
    val correctTestsPerformed: List<TestId>,
    val unnecessaryTests: List<TestId>,
    val missedCriticalTests: List<TestId>,
    val mistakesFeedbackAr: List<String>,
    val recommendationsAr: List<String>,
    val elapsedTimeSeconds: Long,
    val stepLogs: List<StudentStepLog> = emptyList()
)
