package com.example.model

enum class OdorType(val titleAr: String, val badgeColor: Long) {
    NONE("بدون رائحة مميزة", 0xFF64748B),
    BURNT_SUGAR("رائحة سكر محروق (كراميل)", 0xFFD97706),
    CHLOROFORM("رائحة كلوروفورم مميزة", 0xFF0284C7),
    AMMONIA("رائحة نشادر نفاذة (Ammonia)", 0xFF059669),
    PHENOL("رائحة فينول (Carbolic)", 0xFFE11D48),
    BENZENE("رائحة بنزين عطرية", 0xFF7C3AED),
    AROMATIC_AMINE("رائحة أمينات سمكية/أنيلين", 0xFFEA580C),
    PUNGENT_ACID("أبخرة حامضية خانقة", 0xFFDC2626)
}

enum class PrecipitateColor(val titleAr: String, val colorHex: Long) {
    NONE("لا يوجد راسب (محلول رائق)", 0x00000000),
    WHITE("راسب أبيض", 0xFFFFFFFF),
    FLESHY_BUFF("راسب لحمي (بني فاتح)", 0xFFE0A96D),
    RED_COPPER("راسب أحمر طوبي (أكسيد نحاسوز)", 0xFFDC2626),
    YELLOW("راسب أصفر", 0xFFFBBF24),
    BROWN("راسب بني", 0xFF78350F),
    ORANGE_RED_DYE("صبغة برتقالية حمراء", 0xFFEA580C),
    GREEN_CRYSTALS("بلورات خضراء", 0xFF10B981)
}

data class ObservationResult(
    val titleAr: String,
    val descriptionAr: String,
    val visualColorHex: Long = 0x00000000,
    val precipitate: PrecipitateColor = PrecipitateColor.NONE,
    val gasBubbles: Boolean = false,
    val hasFlame: Boolean = false,
    val isSmokyFlame: Boolean = false,
    val charring: Boolean = false,
    val melting: Boolean = false,
    val swelling: Boolean = false,
    val fluoresceinGlow: Boolean = false,
    val purpleRing: Boolean = false,
    val oilyDroplets: Boolean = false,
    val odor: OdorType = OdorType.NONE,
    val timingNoteAr: String = "",
    val conclusionClueAr: String = "" // Clue for training mode
)

enum class SampleFractionType(val titleAr: String, val badgeAr: String) {
    ORIGINAL("العينة الأصلية (المجهول)", "الكل"),
    RESIDUE("الراسب من ورقة الترشيح (Residue)", "راسب"),
    FILTRATE("الراشح في البيكر (Filtrate)", "راشح"),
    FRACTION_A("المركب الأول المفصول (A)", "مفصول 1"),
    FRACTION_B("المركب الثاني المفصول (B)", "مفصول 2")
}

data class SampleFraction(
    val type: SampleFractionType,
    val compound: ChemicalCompound?,
    val isSeparatedSolid: Boolean = false,
    val isSeparatedSolution: Boolean = false,
    val ph: String = "Neutral"
)

enum class MixtureCategory(
    val code: String,
    val titleAr: String,
    val descriptionAr: String,
    val separationProtocolAr: String
) {
    SINGLE(
        "Single",
        "مركب نقي فردي",
        "مادة عضوية نقية واحدة",
        "يتم اتباع مسار الكشف المباشر (حرارة -> جير صودي -> NaOH 20% -> اختبارات المجموعة الوظيفية)."
    ),
    A_PLUS_A(
        "A+A",
        "حمض أليفاتي + حمض أروماتي",
        "فصل بالماء: الراسب حمض أروماتي، الراشح حمض أليفاتي",
        "1. يضاف ماء مقطر ويرشح على البارد.\n2. الراسب (Residue) على ورقة الترشيح: حمض أروماتي غير ذائب (بنزويك/ساليسيليك/فيثالك).\n3. الراشح (Filtrate) في البيكر: حمض أليفاتي ذائب (أوكساليك/طرطريك/ستريك)."
    ),
    A_PLUS_B(
        "A+B",
        "حمض + قاعدة عضوية (أمين)",
        "فصل بـ Na2CO3: الراسب قاعدة، والراشح ملح حمض يرسب بـ HCl",
        "1. يضاف محلول كربونات الصوديوم Na2CO3 ويرشح.\n2. الراسب: القاعدة العضوية (أمين أروماتي).\n3. الراشح: ملح الصوديوم للحمض، يحمض بـ Conc. HCl حتى ظهور راسب الحمض النقي."
    ),
    A_PLUS_PH(
        "A+Ph",
        "حمض + فينول",
        "فصل بـ Na2CO3: الراشح ملح حمض يرسب بـ HCl، الراسب فينول",
        "1. يضاف محلول كربونات الصوديوم Na2CO3 المخفف.\n2. يتفاعل الحمض فقط مع الكربونات ويكون ملحاً ذائباً بينما لا يتفاعل الفينول.\n3. يرشح: الراسب فينول، والراشح يحمض بـ HCl لترسيب الحمض."
    ),
    B_PLUS_PH(
        "B+Ph",
        "قاعدة عضوية + فينول",
        "فصل بـ 5% NaOH: الراسب قاعدة عضوية، الراشح فينولات ترسب بـ HCl",
        "1. يضاف محلول 5% هيدروكسيد صوديوم NaOH على البارد.\n2. يذوب الفينول مكوناً فينوكسيد الصوديوم، بينما لا تذوب القاعدة العضوية.\n3. يرشح: الراسب قاعدة عضوية، والراشح يحمض بـ Conc. HCl لترسيب الفينول."
    ),
    A_PLUS_N(
        "A+N",
        "حمض + مادة متعادلة (أو سكر)",
        "مولش ثم فصل بـ Na2CO3: الراسب سكر/متعادل، الراشح ملح حمض",
        "1. اختبار مولش موجب لوجود السكر أو المادة المتعادلة.\n2. يضاف كربونات الصوديوم Na2CO3 ويرشح.\n3. الراسب: المادة المتعادلة/السكر، والراشح: ملح الحمض يعاد ترسيبه بالحمض."
    ),
    N_PLUS_N(
        "N+N",
        "مادة متعادلة + مادة متعادلة (سكريات)",
        "مولش ثم فصل بالماء: ترشيح وفحص كل جزء مستقلاً",
        "1. اختبار مولش موجب بشدة.\n2. يضاف ماء بارد ويرشح: الراسب (مثل النشا)، والراشح (مثل الجلوكوز أو السكروز).\n3. يفحص كل جزء على حدة بكواشف بارافويد واليود وفهلنج."
    )
}

data class ExamSample(
    val id: String,
    val mixtureCategory: MixtureCategory,
    val component1: ChemicalCompound,
    val component2: ChemicalCompound? = null,
    val isMixture: Boolean = component2 != null
)
