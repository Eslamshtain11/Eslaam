package com.example.model

enum class CompoundCategory(val titleAr: String, val titleEn: String) {
    ALIPHATIC_ACID("أحماض أليفاتية", "Aliphatic Acids"),
    AROMATIC_ACID("أحماض أروماتية", "Aromatic Acids"),
    PHENOL("فينولات", "Phenols"),
    AROMATIC_AMINE("أمينات أروماتية", "Aromatic Amines"),
    SUGAR("سكريات وكربوهيدرات", "Carbohydrates & Sugars"),
    SODIUM_SALT("أملاح صوديوم", "Sodium Salts"),
    AMMONIUM_SALT("أملاح أمونيوم", "Ammonium Salts"),
    SPECIAL("مركبات خاصة", "Special Compounds")
}

data class ChemicalCompound(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val formula: String,
    val category: CompoundCategory,
    val physicalStateAr: String, // صلب أبيض، سائل زيتي، إلخ
    val waterSoluble: Boolean,
    val isAromatic: Boolean,
    val isAcidic: Boolean,
    val isPhenolic: Boolean,
    val isAmine: Boolean,
    val isSugar: Boolean,
    val isSalt: Boolean,
    val molarMass: String = "100",
    val typicalOdor: OdorType = OdorType.NONE,
    val identificationPathAr: String = "كشف مباشر",
    val notes: String = ""
)

object CompoundCatalog {
    // 1. Aliphatic Acids
    val OXALIC_ACID = ChemicalCompound(
        id = "oxalic_acid",
        nameAr = "حمض الأوكساليك",
        nameEn = "Oxalic Acid",
        formula = "(COOH)₂ · 2H₂O",
        category = CompoundCategory.ALIPHATIC_ACID,
        physicalStateAr = "بلورات صلبة بيضاء",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = true,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val TARTARIC_ACID = ChemicalCompound(
        id = "tartaric_acid",
        nameAr = "حمض الطرطريك",
        nameEn = "Tartaric Acid",
        formula = "C₄H₆O₆",
        category = CompoundCategory.ALIPHATIC_ACID,
        physicalStateAr = "بلورات صلبة بيضاء عديمة الرائحة",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = true,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val CITRIC_ACID = ChemicalCompound(
        id = "citric_acid",
        nameAr = "حمض الستريك",
        nameEn = "Citric Acid",
        formula = "C₆H₈O₇",
        category = CompoundCategory.ALIPHATIC_ACID,
        physicalStateAr = "مسحوق بلوري أبيض",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = true,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    // 2. Aromatic Acids
    val BENZOIC_ACID = ChemicalCompound(
        id = "benzoic_acid",
        nameAr = "حمض البنزويك",
        nameEn = "Benzoic Acid",
        formula = "C₆H₅COOH",
        category = CompoundCategory.AROMATIC_ACID,
        physicalStateAr = "قشور أو إبر بلورية بيضاء لامعة",
        waterSoluble = false,
        isAromatic = true,
        isAcidic = true,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val SALICYLIC_ACID = ChemicalCompound(
        id = "salicylic_acid",
        nameAr = "حمض الساليسيليك",
        nameEn = "Salicylic Acid",
        formula = "C₆H₄(OH)COOH",
        category = CompoundCategory.AROMATIC_ACID,
        physicalStateAr = "إبر بلورية بيضاء أو مسحوق أبيض",
        waterSoluble = false,
        isAromatic = true,
        isAcidic = true,
        isPhenolic = true,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val PHTHALIC_ACID = ChemicalCompound(
        id = "phthalic_acid",
        nameAr = "حمض الفيثاليك",
        nameEn = "Phthalic Acid",
        formula = "C₆H₄(COOH)₂",
        category = CompoundCategory.AROMATIC_ACID,
        physicalStateAr = "بلورات بيضاء",
        waterSoluble = false,
        isAromatic = true,
        isAcidic = true,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val CINNAMIC_ACID = ChemicalCompound(
        id = "cinnamic_acid",
        nameAr = "حمض السيناميك",
        nameEn = "Cinnamic Acid",
        formula = "C₆H₅CH=CHCOOH",
        category = CompoundCategory.AROMATIC_ACID,
        physicalStateAr = "بلورات بيضاء ذات رائحة خفيفة عطرية",
        waterSoluble = false,
        isAromatic = true,
        isAcidic = true,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val PHENYLACETIC_ACID = ChemicalCompound(
        id = "phenylacetic_acid",
        nameAr = "حمض فينيل أسيتيك",
        nameEn = "Phenylacetic Acid",
        formula = "C₆H₅CH₂COOH",
        category = CompoundCategory.AROMATIC_ACID,
        physicalStateAr = "بلورات بيضاء لامعة برائحة نفاذة",
        waterSoluble = false,
        isAromatic = true,
        isAcidic = true,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    // 3. Phenols
    val PHENOL = ChemicalCompound(
        id = "phenol",
        nameAr = "فينول (حمض الكربوليك)",
        nameEn = "Phenol",
        formula = "C₆H₅OH",
        category = CompoundCategory.PHENOL,
        physicalStateAr = "بلورات إبرية وردية إلى بيضاء متميعة برائحة مميزة",
        waterSoluble = true,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = true,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val RESORCINOL = ChemicalCompound(
        id = "resorcinol",
        nameAr = "ريزورسينول",
        nameEn = "Resorcinol",
        formula = "C₆H₄(OH)₂ [1,3]",
        category = CompoundCategory.PHENOL,
        physicalStateAr = "بلورات بيضاء تتحول إلى وردية بالضوء",
        waterSoluble = true,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = true,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val CATECHOL = ChemicalCompound(
        id = "catechol",
        nameAr = "كاتيكول",
        nameEn = "Catechol",
        formula = "C₆H₄(OH)₂ [1,2]",
        category = CompoundCategory.PHENOL,
        physicalStateAr = "قشور بلورية بيضاء مائلة للبني",
        waterSoluble = true,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = true,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val HYDROQUINONE = ChemicalCompound(
        id = "hydroquinone",
        nameAr = "هيدروكينون (كينول)",
        nameEn = "Hydroquinone",
        formula = "C₆H₄(OH)₂ [1,4]",
        category = CompoundCategory.PHENOL,
        physicalStateAr = "إبر بلورية بيضاء رمادية",
        waterSoluble = true,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = true,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val PYROGALLOL = ChemicalCompound(
        id = "pyrogallol",
        nameAr = "بيروجالول",
        nameEn = "Pyrogallol",
        formula = "C₆H₃(OH)₃ [1,2,3]",
        category = CompoundCategory.PHENOL,
        physicalStateAr = "بلورات بيضاء دقيقة شديدة الامتصاص للأكسجين",
        waterSoluble = true,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = true,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val ALPHA_NAPHTHOL = ChemicalCompound(
        id = "alpha_naphthol",
        nameAr = "ألفا-نافثول (1-نافثول)",
        nameEn = "1-Naphthol",
        formula = "C₁₀H₇OH",
        category = CompoundCategory.PHENOL,
        physicalStateAr = "بلورات صفراء باهتة أو رمادية برائحة الفينول",
        waterSoluble = false,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = true,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val BETA_NAPHTHOL = ChemicalCompound(
        id = "beta_naphthol",
        nameAr = "بيتا-نافثول (2-نافثول)",
        nameEn = "2-Naphthol",
        formula = "C₁₀H₇OH",
        category = CompoundCategory.PHENOL,
        physicalStateAr = "قشور أو صفائح بلورية بيضاء لامعة",
        waterSoluble = false,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = true,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    // 4. Aromatic Amines
    val ANILINE = ChemicalCompound(
        id = "aniline",
        nameAr = "أنيلين (أمينوبنزين)",
        nameEn = "Aniline",
        formula = "C₆H₅NH₂",
        category = CompoundCategory.AROMATIC_AMINE,
        physicalStateAr = "سائل زيتي بني مصفر برائحة أمينية مميزة",
        waterSoluble = false,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = false,
        isAmine = true,
        isSugar = false,
        isSalt = false
    )

    val P_TOLUIDINE = ChemicalCompound(
        id = "p_toluidine",
        nameAr = "بارا-تولويدين",
        nameEn = "p-Toluidine",
        formula = "CH₃C₆H₄NH₂",
        category = CompoundCategory.AROMATIC_AMINE,
        physicalStateAr = "بلورات صلبة قشرية بنية مصفرة",
        waterSoluble = false,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = false,
        isAmine = true,
        isSugar = false,
        isSalt = false
    )

    val ALPHA_NAPHTHYLAMINE = ChemicalCompound(
        id = "alpha_naphthylamine",
        nameAr = "ألفا-نافثيل أمين",
        nameEn = "1-Naphthylamine",
        formula = "C₁₀H₇NH₂",
        category = CompoundCategory.AROMATIC_AMINE,
        physicalStateAr = "إبر بلورية بنية محمرة برائحة قوية",
        waterSoluble = false,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = false,
        isAmine = true,
        isSugar = false,
        isSalt = false
    )

    val BETA_NAPHTHYLAMINE = ChemicalCompound(
        id = "beta_naphthylamine",
        nameAr = "بيتا-نافثيل أمين",
        nameEn = "2-Naphthylamine",
        formula = "C₁₀H₇NH₂",
        category = CompoundCategory.AROMATIC_AMINE,
        physicalStateAr = "صفائح بلورية وردية أو بيضاء",
        waterSoluble = false,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = false,
        isAmine = true,
        isSugar = false,
        isSalt = false
    )

    // 5. Carbohydrates & Sugars
    val GLUCOSE = ChemicalCompound(
        id = "glucose",
        nameAr = "جلوكوز (سكر العنب)",
        nameEn = "D-Glucose",
        formula = "C₆H₁₂O₆",
        category = CompoundCategory.SUGAR,
        physicalStateAr = "مسحوق بلوري أبيض حلو المذاق",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = true,
        isSalt = false
    )

    val FRUCTOSE = ChemicalCompound(
        id = "fructose",
        nameAr = "فركتوز (سكر الفاكهة)",
        nameEn = "D-Fructose",
        formula = "C₆H₁₂O₆",
        category = CompoundCategory.SUGAR,
        physicalStateAr = "بلورات بيضاء شديدة الحلاوة",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = true,
        isSalt = false
    )

    val SUCROSE = ChemicalCompound(
        id = "sucrose",
        nameAr = "سكروز (سكر القصب)",
        nameEn = "Sucrose",
        formula = "C₁₂H₂₂O₁₁",
        category = CompoundCategory.SUGAR,
        physicalStateAr = "حبيبات أو بلورات صلبة بيضاء",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = true,
        isSalt = false
    )

    val MALTOSE = ChemicalCompound(
        id = "maltose",
        nameAr = "مالتوز (سكر الشعير)",
        nameEn = "Maltose",
        formula = "C₁₂H₂₂O₁₁ · H₂O",
        category = CompoundCategory.SUGAR,
        physicalStateAr = "مسحوق بلوري أبيض متميع",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = true,
        isSalt = false
    )

    val LACTOSE = ChemicalCompound(
        id = "lactose",
        nameAr = "لاكتوز (سكر الحليب)",
        nameEn = "Lactose",
        formula = "C₁₂H₂₂O₁₁ · H₂O",
        category = CompoundCategory.SUGAR,
        physicalStateAr = "مسحوق بلوري أبيض قليل الحلاوة",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = true,
        isSalt = false
    )

    val GALACTOSE = ChemicalCompound(
        id = "galactose",
        nameAr = "جلاكتوز",
        nameEn = "Galactose",
        formula = "C₆H₁₂O₆",
        category = CompoundCategory.SUGAR,
        physicalStateAr = "بلورات بيضاء",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = true,
        isSalt = false
    )

    val STARCH = ChemicalCompound(
        id = "starch",
        nameAr = "نشا (سكر عديد)",
        nameEn = "Starch",
        formula = "(C₆H₁₀O₅)ₙ",
        category = CompoundCategory.SUGAR,
        physicalStateAr = "مسحوق أبيض ناعم جداً عديم الطعم",
        waterSoluble = false,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = true,
        isSalt = false
    )

    // 6. Sodium Salts
    val SODIUM_OXALATE = ChemicalCompound(
        id = "sodium_oxalate",
        nameAr = "أوكسالات صوديوم",
        nameEn = "Sodium Oxalate",
        formula = "Na₂C₂O₄",
        category = CompoundCategory.SODIUM_SALT,
        physicalStateAr = "مسحوق بلوري أبيض",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    val SODIUM_TARTRATE = ChemicalCompound(
        id = "sodium_tartrate",
        nameAr = "طرطرات صوديوم",
        nameEn = "Sodium Tartrate",
        formula = "Na₂C₄H₄O₆ · 2H₂O",
        category = CompoundCategory.SODIUM_SALT,
        physicalStateAr = "بلورات بيضاء منشورية",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    val SODIUM_CITRATE = ChemicalCompound(
        id = "sodium_citrate",
        nameAr = "سترات صوديوم",
        nameEn = "Sodium Citrate",
        formula = "Na₃C₆H₅O₇ · 2H₂O",
        category = CompoundCategory.SODIUM_SALT,
        physicalStateAr = "حبيبات بيضاء بلورية",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    val SODIUM_BENZOATE = ChemicalCompound(
        id = "sodium_benzoate",
        nameAr = "بنزوات صوديوم",
        nameEn = "Sodium Benzoate",
        formula = "C₆H₅COONa",
        category = CompoundCategory.SODIUM_SALT,
        physicalStateAr = "مسحوق أو حبيبات بيضاء",
        waterSoluble = true,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    val SODIUM_SALICYLATE = ChemicalCompound(
        id = "sodium_salicylate",
        nameAr = "سلسلات صوديوم",
        nameEn = "Sodium Salicylate",
        formula = "C₆H₄(OH)COONa",
        category = CompoundCategory.SODIUM_SALT,
        physicalStateAr = "قشور بيضاء متبلورة",
        waterSoluble = true,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = true,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    val SODIUM_PHTHALATE = ChemicalCompound(
        id = "sodium_phthalate",
        nameAr = "فيثالات صوديوم",
        nameEn = "Sodium Phthalate",
        formula = "C₆H₄(COONa)₂",
        category = CompoundCategory.SODIUM_SALT,
        physicalStateAr = "بلورات بيضاء",
        waterSoluble = true,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    // 7. Ammonium Salts
    val AMMONIUM_OXALATE = ChemicalCompound(
        id = "ammonium_oxalate",
        nameAr = "أوكسالات أمونيوم",
        nameEn = "Ammonium Oxalate",
        formula = "(NH₄)₂C₂O₄ · H₂O",
        category = CompoundCategory.AMMONIUM_SALT,
        physicalStateAr = "بلورات منشورية عديمة اللون",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    val AMMONIUM_TARTRATE = ChemicalCompound(
        id = "ammonium_tartrate",
        nameAr = "طرطرات أمونيوم",
        nameEn = "Ammonium Tartrate",
        formula = "(NH₄)₂C₄H₄O₆",
        category = CompoundCategory.AMMONIUM_SALT,
        physicalStateAr = "بلورات بيضاء",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    val AMMONIUM_CITRATE = ChemicalCompound(
        id = "ammonium_citrate",
        nameAr = "سترات أمونيوم",
        nameEn = "Ammonium Citrate",
        formula = "(NH₄)₃C₆H₅O₇",
        category = CompoundCategory.AMMONIUM_SALT,
        physicalStateAr = "مسحوق أبيض متميع",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    val AMMONIUM_BENZOATE = ChemicalCompound(
        id = "ammonium_benzoate",
        nameAr = "بنزوات أمونيوم",
        nameEn = "Ammonium Benzoate",
        formula = "C₆H₅COONH₄",
        category = CompoundCategory.AMMONIUM_SALT,
        physicalStateAr = "بلورات أو مسحوق أبيض برائحة أمونيا خفيفة",
        waterSoluble = true,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    val AMMONIUM_SALICYLATE = ChemicalCompound(
        id = "ammonium_salicylate",
        nameAr = "سلسلات أمونيوم",
        nameEn = "Ammonium Salicylate",
        formula = "C₆H₄(OH)COONH₄",
        category = CompoundCategory.AMMONIUM_SALT,
        physicalStateAr = "بلورات عديمة اللون مائلة للوردي",
        waterSoluble = true,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = true,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    val AMMONIUM_PHTHALATE = ChemicalCompound(
        id = "ammonium_phthalate",
        nameAr = "فيثالات أمونيوم",
        nameEn = "Ammonium Phthalate",
        formula = "C₆H₄(COONH₄)₂",
        category = CompoundCategory.AMMONIUM_SALT,
        physicalStateAr = "بلورات بيضاء",
        waterSoluble = true,
        isAromatic = true,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = true
    )

    // 8. Special Compounds
    val UREA = ChemicalCompound(
        id = "urea",
        nameAr = "يوريا (كارباميد)",
        nameEn = "Urea",
        formula = "(NH₂)₂CO",
        category = CompoundCategory.SPECIAL,
        physicalStateAr = "بلورات منشورية بيضاء عديمة الرائحة",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val CHLORAL_HYDRATE = ChemicalCompound(
        id = "chloral_hydrate",
        nameAr = "هيدرات الكلورال",
        nameEn = "Chloral Hydrate",
        formula = "CCl₃CH(OH)₂",
        category = CompoundCategory.SPECIAL,
        physicalStateAr = "بلورات شفافة نفاذة الرائحة",
        waterSoluble = true,
        isAromatic = false,
        isAcidic = false,
        isPhenolic = false,
        isAmine = false,
        isSugar = false,
        isSalt = false
    )

    val allCompounds: List<ChemicalCompound> = listOf(
        OXALIC_ACID, TARTARIC_ACID, CITRIC_ACID,
        BENZOIC_ACID, SALICYLIC_ACID, PHTHALIC_ACID, CINNAMIC_ACID, PHENYLACETIC_ACID,
        PHENOL, RESORCINOL, CATECHOL, HYDROQUINONE, PYROGALLOL, ALPHA_NAPHTHOL, BETA_NAPHTHOL,
        ANILINE, P_TOLUIDINE, ALPHA_NAPHTHYLAMINE, BETA_NAPHTHYLAMINE,
        GLUCOSE, FRUCTOSE, SUCROSE, MALTOSE, LACTOSE, GALACTOSE, STARCH,
        SODIUM_OXALATE, SODIUM_TARTRATE, SODIUM_CITRATE, SODIUM_BENZOATE, SODIUM_SALICYLATE, SODIUM_PHTHALATE,
        AMMONIUM_OXALATE, AMMONIUM_TARTRATE, AMMONIUM_CITRATE, AMMONIUM_BENZOATE, AMMONIUM_SALICYLATE, AMMONIUM_PHTHALATE,
        UREA, CHLORAL_HYDRATE
    )

    // Frequent examination target pool according to PDF page 16
    val frequentExamPool: List<ChemicalCompound> = listOf(
        BENZOIC_ACID,
        TARTARIC_ACID,
        OXALIC_ACID,
        PHTHALIC_ACID,
        GLUCOSE,
        SALICYLIC_ACID,
        SUCROSE,
        SODIUM_TARTRATE,
        UREA,
        CITRIC_ACID,
        PHENOL,
        RESORCINOL,
        ANILINE,
        SODIUM_BENZOATE
    )

    fun findById(id: String): ChemicalCompound? = allCompounds.find { it.id == id }
}
