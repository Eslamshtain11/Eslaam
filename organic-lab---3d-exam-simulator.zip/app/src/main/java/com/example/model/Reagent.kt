package com.example.model

enum class ReagentType(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val formula: String,
    val colorHex: Long, // Color for liquid simulation
    val opacity: Float = 0.85f,
    val isSolid: Boolean = false,
    val descriptionAr: String = ""
) {
    DISTILLED_WATER("h2o", "ماء مقطر", "Distilled Water", "H₂O", 0xFFE0F2FE, 0.4f, false, "مذيب عام لغسل وإذابة المركبات"),
    SODA_LIME("soda_lime", "جير صودي", "Soda Lime", "NaOH + CaO", 0xFFF1F5F9, 1.0f, true, "خليط صلب لنزع الكربوكسيل واختبار الرائحة"),
    NAOH_20("naoh_20", "هيدروكسيد صوديوم 20%", "Sodium Hydroxide 20%", "20% NaOH", 0xFFE2E8F0, 0.6f, false, "قلوي قوي للتفاعلات القاعدية وتصاعد النشادر"),
    NAOH_5("naoh_5", "هيدروكسيد صوديوم 5%", "Sodium Hydroxide 5%", "5% NaOH", 0xFFE2E8F0, 0.5f, false, "قلوي لفصل الفينولات عن القواعد"),
    CONC_H2SO4("conc_h2so4", "حمض كبريتيك مركز", "Conc. Sulfuric Acid", "Conc. H₂SO₄", 0xFFFEF08A, 0.7f, false, "حمض مركز للتفحم واختبارات الحلقات والنيترة"),
    CONC_HNO3("conc_hno3", "حمض نيتريك مركز", "Conc. Nitric Acid", "Conc. HNO₃", 0xFFFDE047, 0.75f, false, "حمض نيتريك مركز لاختبار النيترة"),
    DILUTE_HCL("dil_hcl", "حمض هيدروكلوريك مخفف", "Dilute Hydrochloric Acid", "Dil. HCl", 0xFFF8FAFC, 0.45f, false, "حمض مخفف لإعادة الترسيب وإذابة القواعد"),
    CONC_HCL("conc_hcl", "حمض هيدروكلوريك مركز", "Conc. Hydrochloric Acid", "Conc. HCl", 0xFFF8FAFC, 0.55f, false, "حمض مركز لفصل أملاح الأحماض"),
    NA2CO3_SOL("na2co3", "كربونات صوديوم (محلول)", "Sodium Carbonate Sol.", "5% Na₂CO₃", 0xFFF1F5F9, 0.5f, false, "محلول قلوي ضعيف لاختبار الحموضة والفصل"),
    NAHCO3_SOLID("nahco3_solid", "بيكربونات صوديوم صلبة", "Sodium Bicarbonate Solid", "NaHCO₃", 0xFFFFFFFF, 1.0f, true, "صلب لاختبار الفوران الحامضي"),
    NEUTRAL_FECL3("neutral_fecl3", "كلوريد حديديك متعادل", "Neutral Ferric Chloride", "FeCl₃ (Neutral)", 0xFFF59E0B, 0.85f, false, "كاشف نوعي للأحماض الأروماتية والفينولات"),
    CACL2_SOL("cacl2", "كلوريد كالسيوم", "Calcium Chloride", "CaCl₂", 0xFFF1F5F9, 0.45f, false, "كاشف نوعي بالتوقيت للأوكسالات والطرطرات والسترات"),
    RESORCINOL_CRYSTALS("resorcinol_cryst", "بلورات ريزورسينول", "Resorcinol Crystals", "C₆H₄(OH)₂", 0xFFFED7AA, 1.0f, true, "بلورات لاختبار الفلوروسين لحمض الفيثاليك"),
    ALPHA_NAPHTHOL("alpha_naphthol_sol", "ألفا-نافثول", "Alpha-Naphthol", "α-Naphthol", 0xFFE0E7FF, 0.7f, false, "كاشف لمولش وللفورفورال السريع"),
    BETA_NAPHTHOL_NAOH("beta_naphthol", "بيتا-نافثول في قلوي", "Beta-Naphthol in NaOH", "β-Naphthol", 0xFFFEF3C7, 0.65f, false, "محلول لاختبار ازدواج صبغة الآزو"),
    NANO2_SOL("nano2", "نتريت صوديوم", "Sodium Nitrite", "NaNO₂", 0xFFF8FAFC, 0.4f, false, "محلول لتفاعل الدستزة للأمينات"),
    FEHLING_A("fehling_a", "فهلنج (أ)", "Fehling's Solution A", "CuSO₄", 0xFF38BDF8, 0.9f, false, "محلول كبريتات نحاس زرقاء"),
    FEHLING_B("fehling_b", "فهلنج (ب)", "Fehling's Solution B", "K-Na Tartrate + NaOH", 0xFFF8FAFC, 0.5f, false, "محلول طرطرات قلوي"),
    BARFOED_REAGENT("barfoed", "كاشف بارافويد", "Barfoed's Reagent", "Cu(CH₃COO)₂", 0xFF0284C7, 0.85f, false, "كاشف خلات نحاس لتمييز السكر الأحادي والثنائي"),
    IODINE_SOL("iodine", "محلول يود", "Iodine Solution", "I₂ / KI", 0xFF92400E, 0.9f, false, "محلول بني داكن لاختبار النشا"),
    BROMINE_WATER("bromine_water", "ماء البروم", "Bromine Water", "Br₂ / H₂O", 0xFFEA580C, 0.8f, false, "ماء البروم البرتقالي لاختبار عدم التشبع والفينولات"),
    AMMONIUM_HYDROXIDE("nh4oh", "هيدروكسيد أمونيوم", "Ammonium Hydroxide", "NH₄OH", 0xFFF1F5F9, 0.4f, false, "لتحضير محاليل الأملاح المتعادلة"),
    COPPER_SULFATE_SOL("cuso4", "كبريتات نحاس (قطرة)", "Copper Sulfate", "1% CuSO₄", 0xFF0284C7, 0.85f, false, "لاختبار البيوريت لليوريا"),
    SODIUM_ACETATE("sodium_acetate", "خلات صوديوم", "Sodium Acetate", "CH₃COONa", 0xFFF8FAFC, 0.5f, false, "لتثبيت التفاعل وتمييز الريزورسينول مع FeCl₃"),
    MERCURIC_CHLORIDE("hgcl2", "كلوريد زئبقيك", "Mercuric Chloride", "HgCl₂", 0xFFF1F5F9, 0.5f, false, "لإعطاء راسب أبيض مع الفورمات")
}

enum class GlasswareType(val titleAr: String, val titleEn: String, val capacityMl: Float) {
    TEST_TUBE("أنبوبة اختبار", "Test Tube", 25f),
    BOILING_TUBE("أنبوبة غليان كبيرة", "Boiling Tube", 50f),
    BEAKER("بيكر زجاجي", "Beaker", 100f),
    ERLENMEYER_FLASK("دورق مخروطي", "Erlenmeyer Flask", 150f),
    WATCH_GLASS("زجاجة ساعة", "Watch Glass", 10f),
    FILTER_FUNNEL("قمع ترشيح مع ورقة ترشيح", "Filter Funnel & Paper", 50f),
    SPATULA("ملعقة كيميائية", "Chemical Spatula", 5f),
    BUNSEN_BURNER("موقد بنزن", "Bunsen Burner", 0f),
    WATER_BATH("حمام مائي ساخن", "Hot Water Bath", 0f)
}
