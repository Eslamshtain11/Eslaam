package com.example.model

/**
 * Represents a node in the qualitative analysis scheme decision tree.
 */
data class SchemeStepNode(
    val stepId: String,
    val stepTitleAr: String,
    val stepTitleEn: String,
    val objectiveDescriptionAr: String,
    val suggestedEquipment: GlasswareType,
    val suggestedReagents: List<ReagentType>,
    val requiresHeating: Boolean = false,
    val questionPromptAr: String,
    val options: List<SchemeDecisionOption>
)

data class SchemeDecisionOption(
    val optionId: String,
    val textAr: String,
    val descriptionAr: String,
    val isCorrectForCompound: (ChemicalCompound) -> Boolean,
    val nextStepId: String?, // null if this option leads directly to final compound identification
    val candidateCompounds: List<ChemicalCompound> = emptyList(),
    val errorExplanationAr: String = ""
)

/**
 * Record of a step performed by the student during the exam.
 */
data class StudentStepLog(
    val stepNode: SchemeStepNode,
    val chosenOption: SchemeDecisionOption,
    val isCorrect: Boolean,
    val equipmentUsed: GlasswareType,
    val reagentsUsed: List<ReagentType>,
    val wasHeated: Boolean,
    val wasShaken: Boolean,
    val actualObservation: ObservationResult,
    val errorDetailsAr: String
)
