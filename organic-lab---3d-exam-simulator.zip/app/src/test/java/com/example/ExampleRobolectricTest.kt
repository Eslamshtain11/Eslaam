package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.OrganicExamEngine
import com.example.model.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("معمل الكيمياء العضوية", appName)
    }

    @Test
    fun `test qualitative analysis engine for benzoic acid`() {
        val sample = ExamSample(
            id = "test_benzoic",
            mixtureCategory = MixtureCategory.SINGLE,
            component1 = CompoundCatalog.BENZOIC_ACID
        )

        // 1. Dry Heat test on benzoic acid -> Smoky flame & benzene vapors
        val heatObs = OrganicExamEngine.performTest(
            sample = sample,
            fraction = SampleFractionType.ORIGINAL,
            testId = TestId.HEAT_TEST
        )
        assertTrue("Benzoic acid burns with smoky flame", heatObs.isSmokyFlame)
        assertEquals(OdorType.BENZENE, heatObs.odor)

        // 2. Acidity test -> Effervescence CO2 bubbles
        val acidObs = OrganicExamEngine.performTest(
            sample = sample,
            fraction = SampleFractionType.ORIGINAL,
            testId = TestId.ACIDITY_TEST
        )
        assertTrue("Acidity test gives gas bubbles", acidObs.gasBubbles)

        // 3. Neutral FeCl3 -> Fleshy Buff Precipitate
        val fecl3Obs = OrganicExamEngine.performTest(
            sample = sample,
            fraction = SampleFractionType.ORIGINAL,
            testId = TestId.NEUTRAL_FECL3_TEST
        )
        assertEquals(PrecipitateColor.FLESHY_BUFF, fecl3Obs.precipitate)
    }

    @Test
    fun `test qualitative analysis engine for glucose and sugars`() {
        val sample = ExamSample(
            id = "test_glucose",
            mixtureCategory = MixtureCategory.SINGLE,
            component1 = CompoundCatalog.GLUCOSE
        )

        // 1. Molisch test -> Purple ring
        val molischObs = OrganicExamEngine.performTest(
            sample = sample,
            fraction = SampleFractionType.ORIGINAL,
            testId = TestId.MOLISCH_TEST
        )
        assertTrue("Molisch test gives purple ring", molischObs.purpleRing)

        // 2. Barfoed test -> Red precipitate in 3 mins (monosaccharide)
        val barfoedObs = OrganicExamEngine.performTest(
            sample = sample,
            fraction = SampleFractionType.ORIGINAL,
            testId = TestId.BARFOED_TEST
        )
        assertEquals(PrecipitateColor.RED_COPPER, barfoedObs.precipitate)
        assertTrue(barfoedObs.timingNoteAr.contains("3"))
    }

    @Test
    fun `test qualitative analysis engine for aniline azo dye coupling`() {
        val sample = ExamSample(
            id = "test_aniline",
            mixtureCategory = MixtureCategory.SINGLE,
            component1 = CompoundCatalog.ANILINE
        )

        val azoObs = OrganicExamEngine.performTest(
            sample = sample,
            fraction = SampleFractionType.ORIGINAL,
            testId = TestId.AZO_DYE_TEST
        )
        assertEquals(PrecipitateColor.ORANGE_RED_DYE, azoObs.precipitate)
    }

    @Test
    fun `test exam grading logic for correct identification`() {
        val sample = ExamSample(
            id = "test_salicylic",
            mixtureCategory = MixtureCategory.SINGLE,
            component1 = CompoundCatalog.SALICYLIC_ACID
        )

        val tests = listOf(
            PerformedTestRecord(
                testId = TestId.HEAT_TEST,
                fraction = SampleFractionType.ORIGINAL,
                observation = OrganicExamEngine.performTest(sample, SampleFractionType.ORIGINAL, TestId.HEAT_TEST)
            ),
            PerformedTestRecord(
                testId = TestId.ACIDITY_TEST,
                fraction = SampleFractionType.ORIGINAL,
                observation = OrganicExamEngine.performTest(sample, SampleFractionType.ORIGINAL, TestId.ACIDITY_TEST)
            ),
            PerformedTestRecord(
                testId = TestId.NEUTRAL_FECL3_TEST,
                fraction = SampleFractionType.ORIGINAL,
                observation = OrganicExamEngine.performTest(sample, SampleFractionType.ORIGINAL, TestId.NEUTRAL_FECL3_TEST)
            )
        )

        val report = OrganicExamEngine.gradeExam(
            actualSample = sample,
            studentCat = MixtureCategory.SINGLE,
            studentComp1 = CompoundCatalog.SALICYLIC_ACID,
            studentComp2 = null,
            performedTests = tests,
            hintsUsedCount = 0,
            elapsedSeconds = 95
        )

        assertEquals(10.0f, report.totalScoreOutOf10, 0.01f)
        assertEquals(CompoundCatalog.SALICYLIC_ACID.id, report.studentIdentifiedComp1?.id)
    }
}
